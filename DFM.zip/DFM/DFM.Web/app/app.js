(function () {
  "use strict";
  angular
    .module("dfmApp", [])
    .directive("falconSelect2", function ($timeout) {
      return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, element, attributes, ngModel) {
          $timeout(function () {
            element.select2({ width: "100%", placeholder: attributes.placeholder || "Select an option", allowClear: true });
          }, 0, false);
          // Angular's own select/ngOptions directive already listens for native "change" and updates
          // ngModel (translating ng-options "as" values correctly); do not also set the view value
          // from element.val() here - for ng-options selects that raw DOM value is an internal index,
          // not the real bound value, and overwriting ngModel with it corrupted budgetSourceId.
          scope.$on("$destroy", function () { if (element.data("select2")) element.select2("destroy"); });
        },
      };
    })
    .directive("fileChange", function () {
      return {
        restrict: "A",
        link: function (scope, element, attrs) {
          element.on("change", function () {
            var files = element[0].files;
            var file = files && files[0];
            scope.$apply(function () { scope.$eval(attrs.fileChange, { $file: file, $files: files }); });
          });
        },
      };
    })
    .controller("PortfolioController", function ($http, $timeout, $q) {
      var vm = this;
      vm.session = null;
      var rememberedEmail = rememberedLoginEmail();
      var rememberedPassword = rememberedLoginPassword();
      vm.auth = { mode: "login", email: rememberedEmail, password: rememberedPassword, rememberMe: !!rememberedEmail };
      vm.questions = [
        { securityQuestionId: 1, question: "What was the name of your first school?" },
        { securityQuestionId: 2, question: "In which city were you born?" },
        { securityQuestionId: 3, question: "What is the name of your childhood best friend?" },
      ];
      vm.today = new Date();
      vm.tab = "portfolio";
      vm.demo = true;
      vm.search = "";
      vm.statusFilter = "";
      vm.viewFilter = "all";
      vm.page = 1;
      vm.pageSize = 10;
      vm.pageCount = 1;
      vm.filteredCount = 0;
      vm.visibleProjects = [];
      vm.approvalItems = [];
      vm.approvalSearch = "";
      vm.approvalPage = 1;
      vm.approvalPageSize = 10;
      vm.approvalPageCount = 1;
      vm.approvalFilteredCount = 0;
      vm.visibleApprovalItems = [];
      vm.approvalSelection = {};
      vm.bulkDecisionItems = [];
      vm.decisionPetRows = [];
      vm.decisionSelection = {};
      vm.budgetLineSpendDetails = [];
      vm.budgetLineVendorOptions = [];
      vm.budgetLineSelectedSpendItems = {};
      vm.budgetLineDocumentTypes = [
        { key: "cam", label: "CAM", entityType: "BudgetLineCAM" },
        { key: "lpo", label: "LPO", entityType: "BudgetLineLPO" },
      ];
      vm.budgetLineDocumentFiles = {};
      vm.invoiceDocumentFile = null;
      var maxUploadBytes = 50 * 1024 * 1024;
      vm.budgetSearch = "";
      vm.budgetPage = 1;
      vm.budgetPageSize = 10;
      vm.budgetPageCount = 1;
      vm.budgetFilteredCount = 0;
      vm.visibleBudgets = [];
      vm.selectedBudgetUsageSource = null;
      vm.selectedBudgetUsageRows = [];
      vm.reportProjectId = "";
      vm.reportProjectSearch = "";
      vm.reportProjectStatusFilter = "";
      vm.reportProjectBudgetTypeFilter = "";
      vm.reportProjectPage = 1;
      vm.reportProjectPageSize = 10;
      vm.reportProjectPageCount = 1;
      vm.reportProjectFilteredCount = 0;
      vm.visibleReportProjects = [];
      vm.reportMetrics = angular.copy(vm.metrics || {});
      vm.reportBudgetUsage = [];
      vm.reportSummary = {};
      vm.reportDetailProject = null;
      vm.reportDetailBudgetUsage = [];
      vm.reportDetailSummary = {};
      vm.approvalMonitorSource = [];
      vm.approvalMonitorLoading = false;
      vm.approvalMonitorLoaded = false;
      vm.approvalMonitorError = "";
      vm.approvalMonitorSummary = {};
      vm.approvalMonitorFilter = "";
      vm.approvalMonitorSearch = "";
      vm.approvalMonitorPage = 1;
      vm.approvalMonitorPageSize = 10;
      vm.approvalMonitorPageCount = 1;
      vm.approvalMonitorFilteredCount = 0;
      vm.approvalMonitorFilteredTotal = 0;
      vm.visibleApprovalMonitorRows = [];
      vm.vendor360LineSource = [];
      vm.vendor360LinesLoaded = false;
      vm.vendor360LineError = "";
      vm.vendorInvoiceSource = [];
      vm.vendorInvoicesLoaded = false;
      vm.vendorInvoiceError = "";
      vm.vendorSpendRows = [];
      vm.vendorSpendSummary = {};
      vm.vendorSpendSearch = "";
      vm.vendorPendingFilter = "";
      vm.vendorSort = { key: "rank", desc: false };
      vm.vendorSpendPage = 1;
      vm.vendorSpendPageSize = 10;
      vm.vendorSpendPageCount = 1;
      vm.vendorSpendFilteredCount = 0;
      vm.visibleVendorSpendRows = [];
      vm.selectedVendorKey = "";
      vm.vendor360 = null;
      vm.vendor360Tab = "projects";
      vm.roleUsers = [];
      vm.roleSearch = "";
      vm.roleFilter = "";
      vm.roleStatusFilter = "";
      vm.roleSort = { key: "displayName", desc: false };
      vm.rolePage = 1;
      vm.rolePageSize = 20;
      vm.rolePageCount = 1;
      vm.roleFilteredCount = 0;
      vm.visibleRoleUsers = [];
      vm.roleSummary = { reviewer: 0, approver: 0, admin: 0 };
      vm.availableManagedRoles = ["Reviewer", "Approver", "Admin"];
      vm.currencySearch = "";
      vm.currencyPage = 1;
      vm.currencyPageSize = 20;
      vm.currencyPageCount = 1;
      vm.currencyFilteredCount = 0;
      vm.visibleCurrencies = [];
      vm.vendorSearch = "";
      vm.vendorPage = 1;
      vm.vendorPageSize = 20;
      vm.vendorPageCount = 1;
      vm.vendorFilteredCount = 0;
      vm.visibleVendors = [];
      vm.glFunds = [];
      vm.nonProjectOpex = [];
      vm.glSearch = "";
      vm.glPage = 1;
      vm.glPageSize = 20;
      vm.glPageCount = 1;
      vm.glFilteredCount = 0;
      vm.visibleGlFunds = [];
      vm.glUtilizationRows = [];
      vm.selectedGlUtilization = null;
      vm.departmentOptions = ["Business", "CET", "CIO Office", "Core", "CRM", "CTO", "Data", "EA&I", "EIS", "Governance", "Risk", "RTB", "Test Gov."];
      vm.unitTypeOptions = ["Nos", "Man Days", "Man Months", "Calender Months", "Fixed Scope"];
      vm.costTypeOptions = [
        "Hardware Purchase", "Hardware Rental", "Hardware AMC", "Software License Purchase", "Software License Subscription", "Software License AMC", "Escrow Agreement",
        "Project Management Services", "Business Analysis", "Architecture /Design", "SME Consulting Services", "Training", "in Months", "Application/Interface Development",
        "Software Customization", "Software Installation & Configuration", "Hardware Installation & Configuration", "Annual Support Operations", "QA Functional Testing",
        "QA Integration Testing", "QA Performance Testing", "QA Load Testing", "QA Test Automation", "SEC Penetration Testing", "UAT Functional Testing",
        "Professional Certification", "Quality Assurance (External)", "Travel & Accommodation", "Premises Rent", "Premises Fit out",
      ];
      vm.projectSizingLevels = [
        { key: "low", label: "Low", score: 1 },
        { key: "medium", label: "Medium", score: 3 },
        { key: "high", label: "High", score: 5 },
      ];
      vm.projectSizingCriteria = [
        { key: "technical", label: "Technical / Service Complexity", weight: 20, low: "Existing Platform, Proven Tech", medium: "Some custom design, novelty", high: "New / Unproven tech, Complex Integration" },
        { key: "regulatory", label: "Regulatory / Compliance / Security", weight: 20, low: "No regulated data, Standard Security", medium: "Compliance, Privacy Requirement", high: "High Regulatory, Audit Exposure" },
        { key: "stakeholder", label: "Stakeholder Complexity", weight: 15, low: "Single Business Owner, Aligned", medium: "Multiple BUs, Competing Priorities", high: "Many Stakeholders, Divergent Interests" },
        { key: "resource", label: "Resource / Capability Dependency", weight: 15, low: "Skills available internally", medium: "Some External Specialist", high: "Critical niche skills, Major hiring" },
        { key: "scale", label: "Scale / Reliability / Performance", weight: 15, low: "Non critical, Degradation acceptable", medium: "Normal Production SLAs", high: "Mission-critical, Strict HA/SLA" },
        { key: "interdependencies", label: "Interdependencies / Portfolio", weight: 10, low: "Standalone, Few Dependencies", medium: "Some Upstream/Downstream deps", high: "Foundational, Impact many initiatives, Strict HA/SLA" },
        { key: "budget", label: "Budget / Contract Complexity", weight: 5, low: "Small Budget, Simple Procurement", medium: "Multi-Phase funding, Complex terms", high: "Large Capital, Strategic supplier" },
      ];
      vm.yearlyRecurrenceOptions = [1, 2, 3, 4, 5];
      vm.tabs = [
        { id: "portfolio", label: "Portfolio", icon: "layout-dashboard", roles: ["Requestor", "Reviewer", "Approver", "Admin", "Master"] },
        { id: "approvals", label: "Approvals", icon: "stamp", roles: ["Reviewer", "Approver"] },
        { id: "budgets", label: "CAPEX / OPEX", icon: "landmark", roles: ["Admin", "Master"] },
        { id: "currencies", label: "Currency", icon: "coins", roles: ["Admin", "Master"] },
        { id: "vendors", label: "Vendors", icon: "store", roles: ["Admin", "Master"] },
        { id: "gl", label: "GL Management", icon: "badge-dollar-sign", roles: ["Admin", "Master"] },
        { id: "roles", label: "User management", icon: "users", roles: ["Admin", "Master"] },
        {
          id: "reports",
          label: "Management report",
          icon: "chart-no-axes-combined",
          roles: ["Requestor", "Reviewer", "Approver", "Admin", "Master"],
        },
      ];
      vm.navTabs = [];
      vm.stages = ["ITA", "Design", "Develop", "UAT", "Staging", "Live"];
      vm.metrics = {
        projectsRegistered: 0,
        activeProjects: 0,
        petsApproved: 0,
        petsOnTrack: 0,
        petsRejected: 0,
        invoicesRaised: 0,
        invoicesOutstanding: 0,
        invoicesSettled: 0,
        capexBudget: 0,
        capexUtilized: 0,
        opexBudget: 0,
        opexUtilized: 0,
      };
      vm.budgets = [];
      vm.currencies = [];
      vm.vendors = [];
      vm.jira = [];
      vm.projects = [];

      vm.pageTitle = function () {
        return {
          portfolio: "Projects & financial workflow",
          approvals: "PET review & approval queue",
          budgets: "Budget source control",
          currencies: "Currency maintenance",
          vendors: "Vendor maintenance",
          roles: "User management",
          reports: "Management reporting",
        }[vm.tab];
      };
      vm.authTitle = function () { return vm.auth.mode === "setup" && vm.auth.requiredSetup ? "Complete required reset" : { login: "Sign in", setup: "Create your password", reset: "Verify your identity", complete: "Choose a new password" }[vm.auth.mode]; };
      vm.authHelp = function () { return vm.auth.mode === "login" ? "Use your synchronized Active Directory email ID." : vm.auth.mode === "setup" && vm.auth.requiredSetup ? "Set a new password and recovery question before entering the portal." : "This anonymous step is protected by your stored security challenge."; };
      vm.authAction = function () { return vm.auth.mode === "setup" && vm.auth.requiredSetup ? "Save credentials" : { login: "Sign in", setup: "Activate account", reset: "Verify answer", complete: "Reset password" }[vm.auth.mode]; };
      vm.enterPreview = function () { vm.session = { displayName: "Preview User", email: "cards.requestor@dfm.ae", initials: "PU", roles: ["Requestor", "Reviewer", "Approver", "Admin"] }; vm.demo = true; vm.roleUsers = previewRoleUsers(); updateNavigation(); vm.updateRoleView(); vm.updateVendorView(); vm.updateGlView(); prepareProjects(); vm.updateView(); redraw(); };
      vm.signOut = function () { vm.session = null; vm.demo = true; resetLoginAuth(); sessionStorage.removeItem("dfmToken"); sessionStorage.removeItem("dfmSession"); delete $http.defaults.headers.common.Authorization; redraw(); };
      function normalizeAuthEmail(value) {
        return String(value || "").trim().replace(/[;,]+$/g, "").trim().toLowerCase();
      }
      vm.authenticate = function () {
        vm.auth.error = "";
        vm.auth.email = normalizeAuthEmail(vm.auth.email);
        if (!vm.auth.email || vm.auth.email.indexOf("@") < 1 || vm.auth.email.indexOf("@") === vm.auth.email.length - 1) { vm.auth.error = "Enter a valid email ID."; return; }
        var mode = vm.auth.mode;
        if (mode === "setup" || mode === "reset") {
          vm.auth.securityQuestionId = Number(vm.auth.securityQuestionId) || null;
          if (!vm.auth.securityQuestionId) { vm.auth.error = "Select a security question."; return; }
          if (!String(vm.auth.securityAnswer || "").trim()) { vm.auth.error = "Enter the security answer."; return; }
        }
        var route = vm.auth.mode === "login" ? "login" : vm.auth.mode === "setup" ? (vm.auth.requiredSetup ? "required-setup" : "first-time-setup") : vm.auth.mode === "reset" ? "reset/challenge" : "reset/complete";
        $http.post("api/auth/" + route, vm.auth).then(function (response) {
          if (mode === "login") {
            if (response.data.requiresPasswordSetup) {
              vm.auth.mode = "setup";
              vm.auth.password = "";
              vm.auth.requiredSetup = !!response.data.token;
              if (response.data.token) $http.defaults.headers.common.Authorization = "Bearer " + response.data.token;
              return;
            }
            saveRememberedLogin();
            applySession(response.data, response.data.token);
            rememberSession(response.data);
            updateNavigation();
            loadDashboard();
            loadCurrencies(false);
            loadVendors(false);
            loadGlFunds(false);
            loadRoles(false);
          } else if (mode === "reset") { vm.auth.resetToken = response.data.resetToken; vm.auth.mode = "complete"; }
          else {
            var requiredSetup = mode === "setup" && vm.auth.requiredSetup;
            if (requiredSetup) delete $http.defaults.headers.common.Authorization;
            vm.auth = { mode: "login", email: vm.auth.email, rememberMe: vm.auth.rememberMe };
            notice(requiredSetup ? "Password and recovery question updated. Sign in with your new password." : mode === "complete" ? "Password reset. Sign in to continue." : "Password saved. Sign in to continue.");
          }
          redraw();
        }, function (response) { vm.auth.error = authResponseMessage(response, "Unable to complete this request."); });
      };
      function rememberedLoginEmail() {
        try { return localStorage.getItem("dfmRememberedEmail") || ""; }
        catch (ignore) { return ""; }
      }
      function rememberedLoginPassword() {
        try { return localStorage.getItem("dfmRememberedPassword") || ""; }
        catch (ignore) { return ""; }
      }
      function saveRememberedLogin() {
        try {
          if (vm.auth.rememberMe && vm.auth.email) {
            localStorage.setItem("dfmRememberedEmail", normalizeAuthEmail(vm.auth.email));
            localStorage.setItem("dfmRememberedPassword", vm.auth.password || "");
          } else {
            localStorage.removeItem("dfmRememberedEmail");
            localStorage.removeItem("dfmRememberedPassword");
          }
        } catch (ignore) { }
      }
      function resetLoginAuth() {
        var email = rememberedLoginEmail();
        vm.auth = { mode: "login", email: email, password: rememberedLoginPassword(), rememberMe: !!email };
      }
      function applySession(session, token) {
        vm.session = session || {};
        // Drop preview sample projects so their PETs/budget lines never merge into real projects with the same id.
        if (vm.demo) vm.projects = [];
        vm.demo = false;
        vm.session.roles = vm.session.roles || [];
        vm.session.initials = (vm.session.displayName || vm.session.email || "U").split(/\s+/).slice(0,2).map(function (part) { return part.charAt(0); }).join("").toUpperCase();
        if (token) {
          sessionStorage.setItem("dfmToken", token);
          $http.defaults.headers.common.Authorization = "Bearer " + token;
        }
      }
      function rememberSession(session) {
        try {
          var copy = angular.copy(session || {});
          delete copy.token;
          sessionStorage.setItem("dfmSession", angular.toJson(copy));
        } catch (ignore) { }
      }
      function restoreSession() {
        var token = sessionStorage.getItem("dfmToken");
        if (!token) return false;
        $http.defaults.headers.common.Authorization = "Bearer " + token;
        var loadedFromCache = false;
        try {
          var cached = angular.fromJson(sessionStorage.getItem("dfmSession") || "null");
          if (cached && cached.email) { loadedFromCache = true; applySession(cached, token); updateNavigation(); loadDashboard(); loadCurrencies(false); loadVendors(false); loadGlFunds(false); loadRoles(false); }
        } catch (ignore) { }
        $http.get("api/auth/session").then(function (response) {
          applySession(response.data, token);
          rememberSession(response.data);
          updateNavigation();
          if (loadedFromCache) vm.updateView(true);
          else { loadDashboard(); loadCurrencies(false); loadVendors(false); loadGlFunds(false); loadRoles(false); }
          redraw();
        }, function () { vm.signOut(); });
        return true;
      }
      vm.hasRole = function (role) {
        var roles = vm.session && vm.session.roles || [];
        return roles.some(function (item) {
          return String(item).toLowerCase() === role.toLowerCase() ||
            (role === "Requestor" && String(item).toLowerCase() === "master") ||
            (role === "Requestor" && String(item).toLowerCase() === "admin") ||
            (role === "Admin" && String(item).toLowerCase() === "master") ||
            (role === "Master" && String(item).toLowerCase() === "admin");
        });
      };
      vm.can = function (action) {
        return action === "request" ? vm.hasRole("Requestor") && !vm.isApproverOnly() : false;
      };
      vm.isApproverOnly = function () {
        return vm.hasRole("Approver") && !vm.hasRole("Reviewer") && !vm.hasRole("Admin") && !vm.hasRole("Master");
      };
      function updateNavigation() {
        vm.navTabs = vm.tabs.filter(function (tab) { return !tab.roles || tab.roles.some(vm.hasRole); });
        if (!vm.navTabs.some(function (tab) { return tab.id === vm.tab; })) vm.tab = "portfolio";
      }
      vm.setTab = function (tabId) {
        vm.tab = tabId;
        if (tabId === "currencies") loadCurrencies(true);
        if (tabId === "vendors") loadVendors(true);
        if (tabId === "gl") loadGlFunds(true);
        if (tabId === "roles") loadRoles(true);
        vm.updateView(true);
        redraw();
      };
      vm.money = function (value) {
        var amount = Number(value) || 0;
        var formatted = new Intl.NumberFormat("en-AE", {
          maximumFractionDigits: 0,
        }).format(Math.abs(amount));
        return "AED " + (amount < 0 ? "-" : "") + formatted;
      };
      vm.amount = function (value) {
        return new Intl.NumberFormat("en-AE", {
          maximumFractionDigits: 2,
        }).format(Number(value) || 0);
      };
      vm.projectDisplayId = function (project) { return project && project.jiraKey ? project.jiraKey : project.projectCode; };
      vm.selectNonProjectOpexSource = function () {
        var source = (vm.budgets || []).filter(function (b) {
          return b.budgetType === "OPEX" && b.externalId === vm.form.opexReference;
        })[0];
        if (source && vm.form.budgetApprovedAed == null) vm.form.budgetApprovedAed = source.budget;
      };
      vm.selectedBudgetSource = function () {
        return (vm.budgets || []).filter(function (b) {
          return b.budgetSourceId === vm.form.budgetSourceId;
        })[0];
      };
      vm.setProjectSizingScore = function (criterion, level) {
        if (!vm.form) return;
        vm.form.projectSizingScores = vm.form.projectSizingScores || {};
        vm.form.projectSizingScores[criterion.key] = level.score;
        updateProjectSizeFromScores();
      };
      vm.projectSizingScore = function (criterion) {
        return vm.form && vm.form.projectSizingScores && Number(vm.form.projectSizingScores[criterion.key]) || 0;
      };
      vm.projectSizingComplete = function () {
        return !!vm.form && vm.projectSizingCriteria.every(function (criterion) { return vm.projectSizingScore(criterion) > 0; });
      };
      vm.projectSizingWeightedTotal = function () {
        if (!vm.form || !vm.form.projectSizingScores) return 0;
        return Math.round(vm.projectSizingCriteria.reduce(function (total, criterion) {
          return total + (Number(vm.form.projectSizingScores[criterion.key]) || 0) * criterion.weight / 100;
        }, 0) * 100) / 100;
      };
      function projectSizeFromScore(score) {
        if (score <= 0) return "";
        if (score <= 1.5) return "XS";
        if (score <= 2.3) return "S";
        if (score <= 3.5) return "M";
        if (score <= 4.1) return "L";
        return "XL";
      }
      function updateProjectSizeFromScores() {
        var size = projectSizeFromScore(vm.projectSizingWeightedTotal());
        if (size) vm.form.projectSize = size;
      }
      function projectSizingTotal(scores) {
        return Math.round(vm.projectSizingCriteria.reduce(function (total, criterion) {
          return total + (Number(scores && scores[criterion.key]) || 0) * criterion.weight / 100;
        }, 0) * 100) / 100;
      }
      function parseProjectSizingScores(value) {
        if (!value) return {};
        if (angular.isObject(value)) return angular.copy(value);
        try { return JSON.parse(value); }
        catch (ignore) {
          var parts = String(value || "").split(",");
          if (parts.length < 2) return {};
          var scores = {};
          parts.forEach(function (score, index) {
            var criterion = vm.projectSizingCriteria[index];
            var numericScore = Number(score) || 0;
            if (criterion && numericScore) scores[criterion.key] = numericScore;
          });
          return scores;
        }
      }
      function splitStoredProjectSize(value) {
        var parts = String(value || "").split("|");
        return { size: parts[0] || "", scores: parts[1] || "" };
      }
      function scoresFromStoredProjectSize(value) {
        var encoded = splitStoredProjectSize(value).scores;
        if (!encoded) return {};
        var scores = {};
        encoded.split(",").forEach(function (score, index) {
          var criterion = vm.projectSizingCriteria[index];
          var numericScore = Number(score) || 0;
          if (criterion && numericScore) scores[criterion.key] = numericScore;
        });
        return scores;
      }
      function storedProjectSizeValue() {
        var size = vm.form && vm.form.projectSize || "";
        var scores = vm.projectSizingCriteria.map(function (criterion) {
          return Number(vm.form && vm.form.projectSizingScores && vm.form.projectSizingScores[criterion.key]) || 0;
        });
        return scores.some(function (score) { return score > 0; }) ? size + "|" + scores.join(",") : size;
      }
      vm.projectSizingLabel = function (project) {
        var scores = parseProjectSizingScores(project && (project.projectSizingScores || project.ProjectSizingScores));
        if (!Object.keys(scores).length) scores = scoresFromStoredProjectSize(project && (project.projectSize || project.ProjectSize));
        var size = projectSizeFromScore(projectSizingTotal(scores)) || splitStoredProjectSize(project && (project.projectSize || project.ProjectSize)).size;
        return size || "Not supplied";
      };
      function projectSizingLevel(project, criterion) {
        if (!criterion) return null;
        var scores = parseProjectSizingScores(project && (project.projectSizingScores || project.ProjectSizingScores));
        if (!Object.keys(scores).length) scores = scoresFromStoredProjectSize(project && (project.projectSize || project.ProjectSize));
        var score = Number(scores[criterion.key]) || 0;
        return vm.projectSizingLevels.filter(function (level) { return level.score === score; })[0] || null;
      }
      vm.projectSizingSelectedLevel = function (project, criterion) {
        var level = projectSizingLevel(project, criterion);
        return level ? level.label + " (" + level.score + ")" : "Not selected";
      };
      vm.projectSizingSelectedText = function (project, criterion) {
        var level = projectSizingLevel(project, criterion);
        return level ? criterion[level.key] : "No saved value";
      };
      function normalizeProjectSizing(project) {
        if (!project) return project;
        var rawSize = project.projectSize || project.ProjectSize || "";
        var storedSize = splitStoredProjectSize(rawSize);
        project.projectSizingScores = parseProjectSizingScores(project.projectSizingScores || project.ProjectSizingScores);
        if (!Object.keys(project.projectSizingScores).length) project.projectSizingScores = scoresFromStoredProjectSize(rawSize);
        project.projectSize = projectSizeFromScore(projectSizingTotal(project.projectSizingScores)) || storedSize.size;
        return project;
      }
      function projectSizingPayload() {
        return JSON.stringify(vm.form && vm.form.projectSizingScores || {});
      }
      vm.decisionCapexEditable = function () {
        return vm.form && vm.form.decision === "Approve" && vm.modal && (vm.modal.stage === "review" || vm.modal.stage === "approve");
      };
      vm.pendingWithName = function (project) {
        if (project.status === "Pending Review") return project.accountableExecLead;
        if (project.status === "Pending Approval") return project.accountableExec;
        return "";
      };
      function sameName(a, b) {
        return !!a && !!b && String(a).trim().toLowerCase() === String(b).trim().toLowerCase();
      }
      function sameEmail(a, b) {
        return !!a && !!b && String(a).trim().toLowerCase() === String(b).trim().toLowerCase();
      }
      function sameStatus(a, b) {
        return !!a && !!b && String(a).trim().toLowerCase() === String(b).trim().toLowerCase();
      }
      function existingPetVendor(pet) {
        if (!pet) return "";
        if (pet.spendItems && pet.spendItems.length) return pet.spendItems[0].vendor || pet.spendItems[0].Vendor || "";
        if (pet.budgetLines && pet.budgetLines.length) return pet.budgetLines[0].vendor || pet.budgetLines[0].Vendor || "";
        return "";
      }
      vm.petVendor = existingPetVendor;
      function splitVendorNames(text) {
        var values = [];
        var value = String(text || "").trim();
        function addVendor(part) {
          var vendor = String(part || "").trim();
          if (vendor && values.map(function (item) { return item.toLowerCase(); }).indexOf(vendor.toLowerCase()) < 0) values.push(vendor);
        }
        addVendor(value);
        if (value.indexOf(",") >= 0) value.split(",").forEach(addVendor);
        return values;
      }
      vm.petVendorOptions = function (pet) {
        var values = [];
        function addVendor(text) {
          splitVendorNames(text).forEach(function (value) {
            if (values.map(function (v) { return v.toLowerCase(); }).indexOf(value.toLowerCase()) < 0) values.push(value);
          });
        }
        ((pet && pet.spendItems) || []).forEach(function (item) {
          addVendor(item.vendor || item.Vendor);
        });
        return values;
      };
      vm.activeVendorOptions = function () {
        var values = [];
        (vm.vendors || []).forEach(function (vendor) {
          var name = String(vendor && (vendor.name || vendor.Name) || "").trim();
          if (!name || vendor.isActive === false || vendor.IsActive === false) return;
          if (values.map(function (value) { return value.toLowerCase(); }).indexOf(name.toLowerCase()) < 0) values.push(name);
        });
        return values.sort(function (left, right) { return left.localeCompare(right); });
      };
      function spendItemValue(item, names) {
        for (var index = 0; index < names.length; index++) {
          var value = item && item[names[index]];
          if (value) return value;
        }
        return null;
      }
      function uniqueSpendValues(items, names) {
        var values = [];
        (items || []).forEach(function (item) {
          var value = spendItemValue(item, names);
          value = value === null || angular.isUndefined(value) ? "" : String(value).trim();
          if (value && values.map(function (v) { return v.toLowerCase(); }).indexOf(value.toLowerCase()) < 0) values.push(value);
        });
        return values;
      }
      function normalizeBudgetLineSourceIds(value) {
        var values = [];
        function add(value) {
          var id = parseInt(value, 10);
          if (id > 0 && values.indexOf(id) < 0) values.push(id);
        }
        if (angular.isArray(value)) value.forEach(add);
        else if (typeof value === "string") value.split(",").forEach(add);
        else add(value);
        return values;
      }
      function budgetLineSpendItemId(item) {
        return parseInt(item && (item.spendItemId || item.SpendItemId), 10) || 0;
      }
      function refreshBudgetLineSpendDetails() {
        var selectedIds = normalizeBudgetLineSourceIds(vm.form && (vm.form.sourceSpendItemIds || vm.form.SourceSpendItemIds || vm.form.spendItemIds || vm.form.SpendItemIds || vm.form.sourceSpendItemId || vm.form.SourceSpendItemId || vm.form.spendItemId || vm.form.SpendItemId));
        if (selectedIds.length > 1) selectedIds = selectedIds.slice(0, 1);
        var items = ((vm.selectedPet && vm.selectedPet.spendItems) || []).map(normalizeSpendItem);
        if (!selectedIds.length && !vm.form.budgetLineId && items.length === 1) selectedIds.push(budgetLineSpendItemId(items[0]));
        vm.budgetLineSelectedSpendItems = {};
        items.forEach(function (item) {
          var id = budgetLineSpendItemId(item);
          item.budgetLineSelected = selectedIds.indexOf(id) >= 0;
          item.budgetLineVendor = item.vendor || item.Vendor || item.budgetLineVendor || "";
          item.budgetLineMatches = budgetLinesForSpendItemId(id);
          if (item.budgetLineSelected) vm.budgetLineSelectedSpendItems[id] = true;
        });
        vm.form.sourceSpendItemIds = collectSelectedBudgetLineSpendItemIds(items);
        vm.budgetLineSpendDetails = items;
        refreshBudgetLineVendorOptions();
      }
      function collectSelectedBudgetLineSpendItemIds(items) {
        return (items || vm.budgetLineSpendDetails || []).filter(function (item) { return item.budgetLineSelected; }).map(budgetLineSpendItemId).filter(function (id) { return id > 0; });
      }
      function selectedBudgetLineSpendItems() {
        return (vm.budgetLineSpendDetails || []).filter(function (item) { return item.budgetLineSelected; });
      }
      function selectedBudgetLineSpendItem() {
        var selectedId = selectedBudgetLineSpendItemId();
        if (selectedId) return ((vm.budgetLineSpendDetails || []).concat((vm.selectedPet && vm.selectedPet.spendItems) || [])).filter(function (item) { return budgetLineSpendItemId(item) === selectedId; })[0] || null;
        return selectedBudgetLineSpendItems()[0] || null;
      }
      function selectedBudgetLineSpendItemId() {
        var sourceIds = normalizeBudgetLineSourceIds(vm.form && vm.form.sourceSpendItemIds);
        if (sourceIds.length) return sourceIds[0];
        return budgetLineSpendItemId(selectedBudgetLineSpendItems()[0]);
      }
      function budgetLineSpendItemVendor(item) {
        return String(item && (item.vendor || item.Vendor || item.budgetLineVendor) || "").trim();
      }
      function splitBudgetLineVendorParts(text) {
        var values = [];
        String(text || "").split(",").forEach(function (part) {
          var vendor = String(part || "").trim();
          if (vendor && values.map(function (value) { return value.toLowerCase(); }).indexOf(vendor.toLowerCase()) < 0) values.push(vendor);
        });
        return values;
      }
      function budgetLineVendorChoices(item) {
        var vendors = splitBudgetLineVendorParts(budgetLineSpendItemVendor(item));
        var choices = [];
        function addChoices(start, selected, size) {
          if (selected.length === size) { choices.push(selected.join(", ")); return; }
          for (var index = start; index < vendors.length; index++) addChoices(index + 1, selected.concat(vendors[index]), size);
        }
        for (var length = 1; length <= vendors.length; length++) addChoices(0, [], length);
        return choices;
      }
      function refreshBudgetLineVendorOptions() {
        vm.budgetLineVendorOptions = budgetLineVendorChoices(selectedBudgetLineSpendItem());
        return vm.budgetLineVendorOptions;
      }
      function selectedBudgetLineSpendItemFinalAed() {
        return spendItemApprovedAmount(selectedBudgetLineSpendItem());
      }
      function budgetLinesForSpendItemId(selectedId) {
        if (!selectedId) return [];
        return ((vm.selectedPet && vm.selectedPet.budgetLines) || []).filter(function (line) {
          return normalizeBudgetLineSourceIds(line.sourceSpendItemIds || line.SourceSpendItemIds || line.spendItemIds || line.SpendItemIds || line.sourceSpendItemId || line.SourceSpendItemId || line.spendItemId || line.SpendItemId).indexOf(selectedId) >= 0;
        });
      }
      vm.selectedPetLineBudgetLines = function () {
        var selectedId = selectedBudgetLineSpendItemId();
        return budgetLinesForSpendItemId(selectedId);
      };
      function applySelectedBudgetLineVendor() {
        var options = refreshBudgetLineVendorOptions();
        vm.form.vendor = options.length ? options[options.length - 1] : "";
      }
      function budgetLineDocumentType(key) {
        return vm.budgetLineDocumentTypes.filter(function (type) { return type.key === key; })[0];
      }
      function budgetLineDocumentEntityTypes() {
        return vm.budgetLineDocumentTypes.map(function (type) { return type.entityType.toLowerCase(); });
      }
      function budgetLineDocuments(line, key) {
        var type = budgetLineDocumentType(key);
        if (!line || !type) return [];
        return (line.attachments || []).filter(function (attachment) { return String(attachment.entityType || "").toLowerCase() === type.entityType.toLowerCase(); });
      }
      vm.budgetLineDocuments = budgetLineDocuments;
      vm.budgetLineHasDocuments = function (line) { return !!(line && line.attachments && line.attachments.length); };
      vm.setBudgetLineDocumentFile = function (key, file) {
        if (file && !validateUploadFileSize(file)) file = null;
        vm.budgetLineDocumentFiles = vm.budgetLineDocumentFiles || {};
        vm.budgetLineDocumentFiles[key] = file || null;
        redraw();
      };
      vm.invoiceDocuments = function (invoice) {
        return (invoice && invoice.attachments) || [];
      };
      vm.setInvoiceDocumentFile = function (file) {
        if (file && !validateUploadFileSize(file)) file = null;
        vm.invoiceDocumentFile = file || null;
        redraw();
      };
      function setBudgetLineDate(field, items, names) {
        var value = spendItemValue((items || []).filter(function (item) { return spendItemValue(item, names); })[0], names);
        vm.form[field] = value ? new Date(value) : null;
      }
      function budgetLineApprovedPetAmount(pet) {
        var selectedLineAmount = selectedBudgetLineSpendItemFinalAed();
        return selectedLineAmount > 0 ? selectedLineAmount : vm.petFinalAed(pet);
      }
      vm.budgetLineApprovedPetAmount = function () {
        return budgetLineApprovedPetAmount(vm.selectedPet);
      };
      function budgetLineAllocatedAmount(pet, excludeBudgetLineId) {
        var selectedId = selectedBudgetLineSpendItemId();
        var lines = selectedId ? budgetLinesForSpendItemId(selectedId) : ((pet && pet.budgetLines) || []);
        return lines.reduce(function (total, line) {
          if (excludeBudgetLineId && String(line.budgetLineId) === String(excludeBudgetLineId)) return total;
          return total + parseNumericInput(line.cost);
        }, 0);
      }
      function budgetLineAvailablePetAmount(pet, excludeBudgetLineId) {
        return Math.max(budgetLineApprovedPetAmount(pet) - budgetLineAllocatedAmount(pet, excludeBudgetLineId), 0);
      }
      vm.budgetLineAvailablePetAmount = function (excludeBudgetLineId) {
        return budgetLineAvailablePetAmount(vm.selectedPet, excludeBudgetLineId);
      };
      function defaultBudgetLineCost() {
        return Math.round(budgetLineAvailablePetAmount(vm.selectedPet, vm.form && vm.form.budgetLineId) * 100) / 100;
      }
      function applyBudgetLinePetValues() {
        if (!vm.form) return;
        refreshBudgetLineSpendDetails();
        var items = selectedBudgetLineSpendItems();
        if (vm.form.budgetLineId) {
          return;
        }
        vm.form.cost = defaultBudgetLineCost();
        vm.form.justification = "";
        vm.form.glNumber = "";
        vm.form.camId = "";
        vm.form.camStatus = "Raised to Vendor";
        vm.form.camComments = "";
        vm.form.lpoRequest = "";
        vm.form.lpoComments = "";
        vm.form.camCreatedDate = null;
        vm.form.camApprovedDate = null;
        vm.form.lpoIssueDate = null;
        vm.form.currency = "AED";
        applySelectedBudgetLineVendor();
        var currencies = uniqueSpendValues(items, ["currency", "Currency"]);
        if (currencies.length === 1) vm.form.currency = currencies[0];
        var descriptions = uniqueSpendValues(items, ["description", "Description"]);
        if (descriptions.length) vm.form.justification = descriptions.join(" | ");
        var glNumbers = uniqueSpendValues(items, ["glNumber", "GlNumber", "GLNumber"]);
        if (glNumbers.length) vm.form.glNumber = glNumbers.join(" | ");
        var camIds = uniqueSpendValues(items, ["camId", "CamId", "CAMId"]);
        if (camIds.length) vm.form.camId = camIds[0];
        var statuses = uniqueSpendValues(items, ["camStatus", "CamStatus", "status", "Status"]);
        if (statuses.length) vm.form.camStatus = statuses[0];
        var camComments = uniqueSpendValues(items, ["camComments", "CamComments"]);
        if (camComments.length) vm.form.camComments = camComments.join(" | ");
        var lpoRequests = uniqueSpendValues(items, ["lpoRequest", "LpoRequest", "lpoNumber", "LpoNumber"]);
        if (lpoRequests.length) vm.form.lpoRequest = lpoRequests[0];
        var lpoComments = uniqueSpendValues(items, ["lpoComments", "LpoComments"]);
        if (lpoComments.length) vm.form.lpoComments = lpoComments.join(" | ");
        setBudgetLineDate("camCreatedDate", items, ["camCreatedDate", "CamCreatedDate"]);
        setBudgetLineDate("camApprovedDate", items, ["camApprovedDate", "CamApprovedDate"]);
        setBudgetLineDate("lpoIssueDate", items, ["lpoIssueDate", "LpoIssueDate"]);
      }
      vm.onBudgetLineSpendSelectionChange = function (selectedItem) {
        (vm.budgetLineSpendDetails || []).forEach(function (item) {
          if (item !== selectedItem) item.budgetLineSelected = false;
        });
        vm.form.sourceSpendItemIds = collectSelectedBudgetLineSpendItemIds();
        applySelectedBudgetLineVendor();
        applyBudgetLinePetValues();
      };
      vm.onBudgetLineGridVendorChange = function (item) {
        if (item && item.budgetLineSelected) applySelectedBudgetLineVendor();
      };
      function validateBudgetLineVendorSelection() {
        var items = selectedBudgetLineSpendItems();
        if (vm.budgetLineSpendDetails.length && items.length !== 1) { noticeError("Select one PET line for this Budget Line."); return false; }
        vm.form.vendor = String(vm.form.vendor || "").trim();
        if (!vm.form.vendor) { noticeError("Vendor Name is required."); return false; }
        var allowedVendors = refreshBudgetLineVendorOptions();
        if (allowedVendors.length) {
          var allowedParts = splitBudgetLineVendorParts(budgetLineSpendItemVendor(selectedBudgetLineSpendItem()));
          var selectedParts = splitBudgetLineVendorParts(vm.form.vendor);
          var allowedKeys = allowedParts.map(function (vendor) { return vendor.toLowerCase(); });
          var isAllowedSubset = selectedParts.length > 0 && selectedParts.every(function (vendor) { return allowedKeys.indexOf(vendor.toLowerCase()) >= 0; });
          if (!isAllowedSubset) { noticeError("Select Vendor Name from the selected PET line."); return false; }
        }
        return true;
      }
      vm.petSpendField = function (pet, field) {
        var values = [];
        ((pet && pet.spendItems) || []).forEach(function (item) {
          var value = item[field];
          if (value && values.indexOf(value) < 0) values.push(value);
        });
        return values.join(" | ") || "Not supplied";
      };
      // Login is by email, but JIRA only records the reviewer/approver's display name against
      // the project (AccountableExecLead/AccountableExec) - so match on Users.DisplayName, not email.
      vm.isReviewerFor = function (project) { return sameName(vm.session && vm.session.displayName, project.accountableExecLead); };
      vm.isApproverFor = function (project) { return sameName(vm.session && vm.session.displayName, project.accountableExec); };
      vm.isReviewerForPet = function (project, pet) { return sameEmail(vm.session && vm.session.email, pet && pet.reviewerEmail) || vm.isReviewerFor(project); };
      vm.isApproverForPet = function (project, pet) { return sameEmail(vm.session && vm.session.email, pet && pet.approverEmail) || vm.isApproverFor(project); };
      vm.setUploadFile = function (file) {
        if (file && !validateUploadFileSize(file)) { vm.uploadFile = null; vm.uploadFiles = []; redraw(); return; }
        vm.uploadFile = file;
        vm.uploadFiles = file ? [file] : [];
        if (vm.modal && vm.modal.type === "pet") { redraw(); return; }
        vm.uploadPreview = [];
        vm.petUploadTotal = 0;
        if (!file || !vm.modal || vm.modal.type !== "upload" || vm.modal.kind !== "pet") { redraw(); return; }
        var projectId = vm.form.item && vm.form.item.projectId;
        if (!projectId) { noticeError("Unable to determine which project should receive these PET rows."); return; }
        var formData = new FormData();
        formData.append("file", file);
        $http.post("api/portfolio/bulk/pet/" + projectId + "/preview", formData, { transformRequest: angular.identity, headers: { "Content-Type": undefined } }).then(function (response) {
          vm.uploadPreview = preparePetUploadRows(response.data.rows || []);
          recalculatePetUploadTotal();
          redraw();
        }, function (response) {
          noticeError(responseMessage(response, "Unable to read PET upload file."));
          redraw();
        });
      };
      vm.setUploadFiles = function (files) {
        var selectedFiles = Array.prototype.slice.call(files || []);
        if (!validateUploadFiles(selectedFiles)) { vm.uploadFiles = []; vm.uploadFile = null; redraw(); return; }
        vm.uploadFiles = selectedFiles;
        vm.uploadFile = vm.uploadFiles[0] || null;
        redraw();
      };
      vm.setNonProjectSupportingFile = function (file) {
        if (file && !validateUploadFileSize(file)) { vm.nonProjectSupportingFile = null; redraw(); return; }
        vm.nonProjectSupportingFile = file || null;
        redraw();
      };
      vm.importPetLines = function (file) {
        vm.petLineUploadFile = file;
        if (!file || !vm.selectedProject) { redraw(); return; }
        var formData = new FormData();
        formData.append("file", file);
        $http.post("api/portfolio/bulk/pet/" + vm.selectedProject.projectId + "/preview", formData, { transformRequest: angular.identity, headers: { "Content-Type": undefined } }).then(function (response) {
          var rows = preparePetUploadRows(response.data.rows || []);
          vm.uploadPreview = (vm.uploadPreview || []).concat(rows);
          vm.recalculateUploadPreview();
          notice(rows.length + " PET line row(s) imported for editing.");
          redraw();
        }, function (response) {
          noticeError(responseMessage(response, "Unable to import the PET Excel file."));
          redraw();
        });
      };
      vm.addPetUploadRow = function () {
        vm.openPetUploadRow();
      };
      vm.openPetUploadRow = function (row) {
        vm.petRowEditor = {
          original: row || null,
          row: preparePetUploadRow(row ? angular.copy(row) : {}, !row),
          isEdit: !!row,
        };
        if (!row) {
          assignUniquePetReference(vm.petRowEditor.row);
          vm.petRowEditor.row.serialNo = (vm.uploadPreview || []).length + 1;
        }
        calculatePetUploadRow(vm.petRowEditor.row, false);
        redraw();
      };
      vm.closePetUploadRow = function () {
        vm.petRowEditor = null;
        redraw();
      };
      vm.recalculatePetRowEditor = function (deriveForeignAmount) {
        if (!vm.petRowEditor) return;
        calculatePetUploadRow(vm.petRowEditor.row, deriveForeignAmount);
        redraw();
      };
      vm.submitPetUploadRow = function () {
        if (!vm.petRowEditor) return;
        var row = vm.petRowEditor.row;
        assignUniquePetReference(row, vm.petRowEditor.original);
        assignUniqueLineId(row, vm.petRowEditor.original);
        if (!validatePetUploadRow(row, "popup", true, vm.petRowEditor.original)) return;
        if (vm.petRowEditor.original) angular.extend(vm.petRowEditor.original, row);
        else {
          vm.uploadPreview = vm.uploadPreview || [];
          vm.uploadPreview.push(row);
        }
        vm.petRowEditor = null;
        vm.recalculateUploadPreview();
        redraw();
      };
      vm.removePetUploadRow = function (row) {
        vm.uploadPreview = (vm.uploadPreview || []).filter(function (item) { return item !== row; });
        vm.recalculateUploadPreview();
        redraw();
      };
      vm.recalculatePetUploadRow = function (row, deriveForeignAmount) {
        calculatePetUploadRow(row, deriveForeignAmount);
        vm.recalculateUploadPreview();
      };
      vm.recalculateUploadPreview = function () {
        var sum = 0;
        assignPetLineSerialNumbers();
        (vm.uploadPreview || []).forEach(function (row) { calculatePetUploadRow(row, false); sum += parseNumericInput(row.finalAed); });
        vm.petUploadTotal = Math.round(sum * 100) / 100;
        vm.form.requestedAmount = Math.round(sum * 100) / 100;
      };
      function assignPetLineSerialNumbers() {
        (vm.uploadPreview || []).forEach(function (row, index) {
          row.serialNo = index + 1;
        });
      }
      function petReferenceExists(reference, excludeRow, extraRows) {
        var normalized = String(reference || "").trim().toLowerCase();
        if (!normalized) return false;
        var rows = (vm.uploadPreview || []).concat(extraRows || []);
        return rows.some(function (row) { return row !== excludeRow && String(row.petReference || "").trim().toLowerCase() === normalized; });
      }
      function normalizeSpendItem(item) {
        if (!item) return item;
        item.serialNo = item.serialNo || item.srNo || item.SrNo || item.SerialNo || item.serialNumber || item.SerialNumber || "";
        if (item.lineDate && !angular.isDate(item.lineDate)) item.lineDate = new Date(item.lineDate);
        return item;
      }
      function generatedPetReference(excludeRow, extraRows) {
        var year = new Date().getFullYear();
        var reference;
        do {
          vm.petReferenceSequence = (vm.petReferenceSequence || 0) + 1;
          reference = "PET-" + year + "-" + String(Date.now()).slice(-5) + "-" + ("00" + vm.petReferenceSequence).slice(-3);
        } while (petReferenceExists(reference, excludeRow, extraRows));
        return reference;
      }
      function lineIdExists(lineId, excludeRow, extraRows) {
        var normalized = String(lineId || "").trim().toLowerCase();
        if (!normalized) return false;
        var rows = (vm.uploadPreview || []).concat(vm.selectedPet && vm.selectedPet.spendItems || [], extraRows || []);
        return rows.some(function (row) { return row !== excludeRow && String(row.lineId || row.LineId || "").trim().toLowerCase() === normalized; });
      }
      function generatedLineId(excludeRow, extraRows) {
        var lineId;
        do {
          vm.petLineIdSequence = (vm.petLineIdSequence || 0) + 1;
          lineId = "LINE-" + String(Date.now()).slice(-8) + "-" + ("000" + vm.petLineIdSequence).slice(-4);
        } while (lineIdExists(lineId, excludeRow, extraRows));
        return lineId;
      }
      function assignUniqueLineId(row, excludeRow, extraRows, forceNew) {
        if (!row) return;
        var current = String(row.lineId || row.LineId || "").trim();
        if (!forceNew && current && !lineIdExists(current, excludeRow || row, extraRows)) {
          row.lineId = current;
          return;
        }
        row.lineId = generatedLineId(excludeRow || row, extraRows);
      }
      function ensurePetReferenceNo() {
        vm.form = vm.form || {};
        var reference = String(vm.form.code || "").trim();
        if (!reference) {
          reference = generatedPetReference();
          vm.form.code = reference;
        }
        return reference;
      }
      function assignUniquePetReference(row) {
        row.petReference = ensurePetReferenceNo();
      }
      function petProjectExpenseHead(project) {
        return String(project && (project.budgetType || project.BudgetType) || vm.form && vm.form.budgetType || "").toUpperCase();
      }
      vm.petProjectExpenseHead = function (project) {
        return petProjectExpenseHead(project || vm.selectedProject || (vm.form && vm.form.item)) || "Not supplied";
      };
      function applyPetProjectDefaults(row, project) {
        var head = petProjectExpenseHead(project || vm.selectedProject || (vm.form && vm.form.item));
        if (head) row.head = head;
        return row;
      }
      function preparePetUploadRows(rows) {
        var preparedRows = [];
        (rows || []).forEach(function (row) {
          var prepared = preparePetUploadRow(row, false);
          if (!hasPetUploadData(prepared)) return;
          assignUniquePetReference(prepared);
          assignUniqueLineId(prepared, null, preparedRows, true);
          preparedRows.push(prepared);
        });
        preparedRows.forEach(function (row, index) { row.serialNo = index + 1; });
        return preparedRows;
      }
      function preparePetUploadRow(row, generateReference) {
        var project = vm.form.item || vm.selectedProject || {};
        var prepared = angular.extend({ projectId: vm.projectDisplayId(project), petReference: ensurePetReferenceNo(), serialNo: "", lineDate: null, lineId: "", department: "", currency: "AED", head: "", topic: "", vendor: "", description: "", costType: "", unitType: "", units: 1, unitPrice: 0, foreignAmount: 0, exchangeRate: 1, aedAmount: 0, contingencyPercent: 0, finalAed: 0, yearlyRecurrence: null, glNumber: "" }, normalizeSpendItem(row || {}));
        prepared.petReference = ensurePetReferenceNo();
        if (prepared.lineDate && !angular.isDate(prepared.lineDate)) prepared.lineDate = new Date(prepared.lineDate);
        applyPetProjectDefaults(prepared, project);
        prepared.department = normalizeDepartmentOption(prepared.department);
        prepared.unitType = normalizeOption(prepared.unitType, vm.unitTypeOptions);
        prepared.costType = normalizeOption(prepared.costType, vm.costTypeOptions);
        if (!validOption(prepared.yearlyRecurrence, vm.yearlyRecurrenceOptions)) prepared.yearlyRecurrence = null;
        if (!prepared.lineId) assignUniqueLineId(prepared, row);
        if (!prepared.projectId) prepared.projectId = vm.projectDisplayId(project);
        if (prepared.spendItemId && prepared.unitPrice) {
          if ((prepared.currency || "AED").toUpperCase() === "AED") prepared.aedAmount = prepared.unitPrice;
          else prepared.foreignAmount = prepared.unitPrice;
        }
        if (generateReference) assignUniquePetReference(prepared);
        calculatePetUploadRow(prepared, !prepared.foreignAmount && !prepared.aedAmount);
        return prepared;
      }
      function validateNumericInput(value, label, allowBlank) {
        if (blankNumericInput(value)) {
          if (allowBlank) return true;
          noticeError(label + " is required.");
          return false;
        }
        if (/^-?(?:\d+\.?\d*|\.\d+)$/.test(String(value).replace(/,/g, "").trim())) return true;
        noticeError(label + " must be a numeric value.");
        return false;
      }
      function validOption(value, options) {
        var key = optionKey(value);
        return options.some(function (option) { return optionKey(option) === key; });
      }
      function normalizeOption(value, options) {
        var key = optionKey(value);
        return options.filter(function (option) { return optionKey(option) === key; })[0] || value;
      }
      function normalizeDepartmentOption(value) {
        var department = normalizeOption(value, vm.departmentOptions);
        var text = String(department || "").trim();
        if (!text) return "";
        if (!validOption(text, vm.departmentOptions)) vm.departmentOptions.push(text);
        return normalizeOption(text, vm.departmentOptions);
      }
      function optionKey(value) {
        var key = String(value || "").trim().toLowerCase().replace(/[^a-z0-9]/g, "");
        return key === "eal" ? "eai" : key;
      }
      function validatePetRequiredDropdowns(row, rowLabel) {
        if (!validOption(row && row.department, vm.departmentOptions)) { noticeError("Department is required on " + rowLabel + "."); return false; }
        if (!validOption(row && row.unitType, vm.unitTypeOptions)) { noticeError("Unit Type is required on " + rowLabel + "."); return false; }
        if (!validOption(row && row.costType, vm.costTypeOptions)) { noticeError("Cost Type is required on " + rowLabel + "."); return false; }
        row.department = normalizeDepartmentOption(row.department);
        row.unitType = normalizeOption(row.unitType, vm.unitTypeOptions);
        row.costType = normalizeOption(row.costType, vm.costTypeOptions);
        row.yearlyRecurrence = validOption(row.yearlyRecurrence, vm.yearlyRecurrenceOptions) ? parseNumericInput(row.yearlyRecurrence) : null;
        return true;
      }
      function calculatePetUploadRow(row, deriveForeignAmount) {
        row.currency = (row.currency || "AED").toUpperCase();
        var units = parseNumericInput(row.units);
        var unitPrice = parseNumericInput(row.unitPrice);
        var lineAmount = Math.round(units * unitPrice * 100) / 100;
        var rate = currencyRateToLocal(row.currency, row.exchangeRate);
        var localAmount = Math.round(lineAmount * rate * 100) / 100;
        row.exchangeRate = rate;
        row.foreignAmount = lineAmount || "";
        row.aedAmount = localAmount || "";
        row.finalAed = Math.round(localAmount * (1 + parseNumericInput(row.contingencyPercent) / 100) * 100) / 100;
      }
      function recalculatePetUploadTotal() {
        var total = 0;
        (vm.uploadPreview || []).forEach(function (row) { total += parseNumericInput(row.finalAed); });
        vm.petUploadTotal = Math.round(total * 100) / 100;
      }
      function validatePetUploadRow(row, rowLabel, requirePetReference, excludeRow) {
        applyPetProjectDefaults(row);
        assignUniquePetReference(row);
        calculatePetUploadRow(row, false);
        if (requirePetReference && !String(row.petReference || "").trim()) { noticeError("PET Reference No is required on " + rowLabel + "."); return false; }
        if (!String(row.vendor || "").trim()) { noticeError("Vendor is required on " + rowLabel + "."); return false; }
        if (!validatePetRequiredDropdowns(row, rowLabel)) return false;
        if (!validateNumericInput(row.units, "Units on " + rowLabel, false)) return false;
        if (!validateNumericInput(row.unitPrice, "Unit Price on " + rowLabel, false)) return false;
        if (!validateNumericInput(row.foreignAmount, "Amt. FCY on " + rowLabel, true)) return false;
        if (!validateNumericInput(row.aedAmount, "Amt. LCY on " + rowLabel, true)) return false;
        if (!validateNumericInput(row.contingencyPercent, "Contingency % on " + rowLabel, true)) return false;
        if (!(parseNumericInput(row.unitPrice) > 0)) { noticeError("Unit Price is required on " + rowLabel + "."); return false; }
        return true;
      }
      function hasPetUploadData(row) {
        return !!String(row && (row.topic || row.vendor || row.description || row.glNumber) || "").trim() || parseNumericInput(row && row.unitPrice) > 0 || parseNumericInput(row && row.foreignAmount) > 0 || parseNumericInput(row && row.aedAmount) > 0 || parseNumericInput(row && row.finalAed) > 0;
      }
      function removeBlankPetUploadRows() {
        vm.uploadPreview = (vm.uploadPreview || []).filter(hasPetUploadData);
        vm.uploadPreview.forEach(function (row, index) { row.serialNo = index + 1; });
      }
      function validatePetUploadRows(requirePetReference) {
        removeBlankPetUploadRows();
        if (!(vm.uploadPreview || []).length) { noticeError("Upload Excel/CSV rows or add a PET row before saving."); return false; }
        for (var rowIndex = 0; rowIndex < vm.uploadPreview.length; rowIndex++) {
          var row = vm.uploadPreview[rowIndex];
          if (requirePetReference) assignUniquePetReference(row);
          if (!validatePetUploadRow(row, "row " + (rowIndex + 1), requirePetReference, row)) return false;
        }
        recalculatePetUploadTotal();
        return true;
      }
      function petLinePayloads(petId) {
        return (vm.uploadPreview || []).map(function (row) {
          applyPetProjectDefaults(row);
          assignUniqueLineId(row, row);
          calculatePetUploadRow(row, false);
          return {
            spendItemId: row.spendItemId || null,
            petId: petId || row.petId || 0,
            serialNo: row.serialNo,
            lineDate: row.lineDate,
            lineId: row.lineId,
            department: row.department,
            head: row.head,
            topic: row.topic,
            vendor: row.vendor,
            description: row.description,
            costType: row.costType,
            unitType: row.unitType,
            units: parseNumericInput(row.units),
            unitPrice: parseNumericInput(row.unitPrice),
            currency: row.currency,
            foreignAmount: parseNumericInput(row.foreignAmount),
            exchangeRate: currencyRateToLocal(row.currency, row.exchangeRate),
            aedAmount: parseNumericInput(row.aedAmount),
            contingencyPercent: parseNumericInput(row.contingencyPercent),
            finalAed: parseNumericInput(row.finalAed),
            yearlyRecurrence: blankNumericInput(row.yearlyRecurrence) ? null : parseNumericInput(row.yearlyRecurrence),
            glNumber: row.glNumber,
          };
        });
      }
      function petLineVendorPayloads(petId) {
        return (vm.uploadPreview || []).map(function (row) {
          return { spendItemId: row.spendItemId || null, petId: petId || row.petId || 0, vendor: row.vendor };
        });
      }
      function validatePetLineVendors() {
        for (var rowIndex = 0; rowIndex < (vm.uploadPreview || []).length; rowIndex++) {
          if (!String(vm.uploadPreview[rowIndex].vendor || "").trim()) { noticeError("Vendor is required on PET line " + (rowIndex + 1) + "."); return false; }
        }
        return true;
      }
      function savePetUploadRows(projectId, onDone, reviewRequired) {
        if (!validatePetUploadRows(true)) return;
        var rows = (vm.uploadPreview || []).map(function (row) {
          assignUniqueLineId(row, row);
          var payload = angular.copy(row);
          payload.petReference = ensurePetReferenceNo();
          payload.serialNo = row.serialNo;
          payload.lineDate = row.lineDate;
          payload.lineId = row.lineId;
          payload.units = parseNumericInput(payload.units);
          payload.unitPrice = parseNumericInput(payload.unitPrice);
          payload.foreignAmount = parseNumericInput(payload.foreignAmount);
          payload.exchangeRate = parseNumericInput(payload.exchangeRate) || 1;
          payload.aedAmount = parseNumericInput(payload.aedAmount);
          payload.contingencyPercent = parseNumericInput(payload.contingencyPercent);
          payload.finalAed = parseNumericInput(payload.finalAed);
          payload.yearlyRecurrence = blankNumericInput(payload.yearlyRecurrence) ? null : parseNumericInput(payload.yearlyRecurrence);
          if (angular.isDefined(reviewRequired)) payload.reviewRequired = !!reviewRequired;
          return payload;
        });
        $http.post("api/portfolio/bulk/pet/" + projectId + "/rows", rows).then(function (response) {
          notice((response.data.imported || 0) + " PET row(s) saved.");
          vm.uploadFile = null;
          vm.close();
          loadVendors(false);
          loadDashboard().then(function () { if (onDone) onDone(); });
        }, function (response) {
          noticeError(responseMessage(response, "Unable to save PET rows."));
        });
      }
      vm.deleteProject = function (project) {
        if (!window.confirm("Delete project " + project.projectCode + "? This cannot be undone.")) return;
        $http.post("api/portfolio/projects/" + project.projectId + "/delete").then(function () {
          notice("Project deleted");
          loadDashboard();
        }, function (response) { noticeError(responseMessage(response, "Unable to delete this project.")); });
      };
      vm.deletePet = function (project, pet) {
        if (!window.confirm("Delete PET " + pet.code + "? This cannot be undone.")) return;
        $http.post("api/portfolio/pets/" + pet.petId + "/delete").then(function () {
          notice("PET deleted");
          refreshProjectPets(project.projectId, true);
          loadDashboard();
        }, function (response) { noticeError(responseMessage(response, "Unable to delete this PET.")); });
      };
      vm.deleteBudgetLine = function (project, line) {
        if ((line.invoices || []).length) { noticeError("Budget Line cannot be deleted because it has Invoice(s). Delete the Invoice(s) first."); return; }
        if (!window.confirm("Delete Budget Line " + (line.petReference || line.camId || line.budgetLineId) + "? This cannot be undone.")) return;
        $http.post("api/portfolio/budget-lines/" + line.budgetLineId + "/delete").then(function () {
          notice("Budget line deleted");
          refreshProjectPets(project.projectId, true);
          loadDashboard();
        }, function (response) { noticeError(responseMessage(response, "Unable to delete this Budget Line.")); });
      };
      vm.canDeleteInvoice = function (invoice) {
        var status = String(invoice && invoice.invoiceStatus || "").trim().toLowerCase();
        return status !== "settled" && status !== "paid";
      };
      vm.deleteInvoice = function (invoice) {
        if (!vm.canDeleteInvoice(invoice)) { noticeError("Settled or Paid invoices cannot be deleted."); return; }
        if (!window.confirm("Delete Invoice " + (invoice.invoiceNumber || invoice.invoiceId) + "? This cannot be undone.")) return;
        var projectId = vm.selectedProject && vm.selectedProject.projectId;
        var budgetLineId = vm.selectedLine && vm.selectedLine.budgetLineId;
        $http.post("api/portfolio/invoices/" + invoice.invoiceId + "/delete").then(function () {
          notice("Invoice deleted");
          vm.invoices = (vm.invoices || []).filter(function (item) { return Number(item.invoiceId) !== Number(invoice.invoiceId); });
          if (vm.selectedLine && vm.selectedLine.invoices) vm.selectedLine.invoices = vm.invoices;
          loadDashboard().then(function () {
            if (!projectId) return;
            refreshProjectPets(projectId, true).then(function () {
              var refreshedLine = null;
              ((vm.selectedProject && vm.selectedProject.budgetLines) || []).forEach(function (line) {
                if (Number(line.budgetLineId) === Number(budgetLineId)) refreshedLine = line;
              });
              if (refreshedLine) {
                vm.selectedLine = refreshedLine;
                vm.invoices = refreshedLine.invoices || [];
              }
            });
          });
        }, function (response) { noticeError(responseMessage(response, "Unable to delete this Invoice.")); });
      };
      function refreshProjectPets(projectId, expandRegardless, keepExpandedState) {
        var project = vm.projects.filter(function (p) { return p.projectId === projectId; })[0];
        if (!project) return $q.when();
        project.petsLoaded = false;
        return loadProjectPets(project, expandRegardless, keepExpandedState);
      }
      function refreshProjectsFromDatabase(projectIds) {
        var ids = [];
        (projectIds || []).forEach(function (projectId) {
          if (projectId && ids.indexOf(projectId) < 0) ids.push(projectId);
        });
        return loadDashboard().then(function () {
          return $q.all(ids.map(function (projectId) { return refreshProjectPets(projectId, true); }));
        });
      }
      // Computed once whenever jira/jiraPlan change (not called from the template) - calling this
      // from ng-repeat would rebuild new arrays/objects every digest and trigger an infinite digest loop.
      function computePlanGroups() {
        var byParent = {};
        (vm.jiraPlan || []).forEach(function (activity) {
          var key = activity.parentJiraID || "Unassigned";
          if (!byParent[key]) byParent[key] = [];
          byParent[key].push(activity);
        });
        return Object.keys(byParent).map(function (parentKey) {
          var parent = (vm.jira || []).filter(function (j) { return j.jiraKey === parentKey; })[0];
          return {
            parentKey: parentKey,
            parentName: parent ? parent.summary : parentKey,
            activities: byParent[parentKey],
          };
        });
      }
      vm.activityDuration = function (activity) {
        var start = activity.activityPlannedStartDate || activity.baselineStartDate;
        var end = activity.activityPlannedEndDate || activity.baselineEndDate;
        if (!start || !end) return "";
        var days = Math.round((new Date(end) - new Date(start)) / 86400000);
        return days >= 0 ? days + " days" : "";
      };
      vm.percent = function (value, total) {
        return total ? Math.round(((Number(value) || 0) * 100) / total) : 0;
      };
      function blankNumericInput(value) {
        return value === null || angular.isUndefined(value) || String(value).trim() === "";
      }
      function parseNumericInput(value) {
        if (blankNumericInput(value)) return 0;
        return Number(String(value).replace(/,/g, "")) || 0;
      }
      function currencyRateToLocal(code, fallbackRate) {
        var currencyCode = String(code || "AED").toUpperCase();
        var match = (vm.currencies || []).filter(function (currency) { return String(currency.code || "").toUpperCase() === currencyCode; })[0];
        var rate = parseNumericInput(match && match.rateToLocal);
        if (rate > 0) return rate;
        rate = parseNumericInput(fallbackRate);
        return rate > 0 ? rate : 1;
      }
      vm.currencyOptions = function () {
        var options = [];
        (vm.currencies || []).forEach(function (currency) {
          var code = String(currency.code || "").toUpperCase();
          if (code && currency.isActive !== false && options.indexOf(code) < 0) options.push(code);
        });
        if (options.indexOf("AED") < 0) options.unshift("AED");
        return options;
      };
      vm.statusClass = function (status) {
        var text = (status || "").toLowerCase();
        if (/approved|paid|settled|issued|active|live/.test(text))
          return "approved";
        if (/reject|blocked/.test(text)) return "rejected";
        if (/pending|outstanding|received|review|approval|sent back/.test(text))
          return "pending";
        return "neutral";
      };
      vm.pendingPet = function (project, status) {
        for (var index = 0; index < project.pets.length; index++) if (project.pets[index].status === status) return project.pets[index];
        return null;
      };
      vm.canAddBudgetLine = function (pet) { return pet && pet.status === "Approved"; };
      vm.canMaintainPet = function (pet) { return pet && (pet.status === "Pending Review" || pet.status === "Sent Back"); };
      vm.petForNewBudgetLine = function (project) {
        var pets = project && project.pets || [];
        for (var index = 0; index < pets.length; index++) if (vm.canAddBudgetLine(pets[index])) return pets[index];
        return null;
      };
      vm.petFinalAed = function (pet) {
        if (!pet.spendItems || !pet.spendItems.length) return parseNumericInput(pet.requestedAmount);
        return pet.spendItems.reduce(function (total, item) { return total + spendItemApprovedAmount(item); }, 0);
      };
      vm.projectPetRequestTotal = function (project) {
        return ((project && project.pets) || []).reduce(function (total, pet) { return total + parseNumericInput(pet.requestedAmount); }, 0);
      };
      function petBudgetLineTotal(pet, excludeBudgetLineId) {
        return ((pet && pet.budgetLines) || []).reduce(function (total, line) {
          if (excludeBudgetLineId && String(line.budgetLineId) === String(excludeBudgetLineId)) return total;
          return total + parseNumericInput(line.cost);
        }, 0);
      }
      vm.petBudgetLineAvailable = function (pet, excludeBudgetLineId) {
        return Math.max(vm.petFinalAed(pet) - petBudgetLineTotal(pet, excludeBudgetLineId), 0);
      };
      function spendItemApprovedAmount(item) {
        if (!item) return 0;
        var finalAedAmount = !blankNumericInput(item.finalAedAmount) ? item.finalAedAmount : item.FinalAedAmount;
        var finalAed = !blankNumericInput(item.finalAed) ? item.finalAed : item.FinalAed;
        if (!blankNumericInput(finalAedAmount)) return parseNumericInput(finalAedAmount);
        if (!blankNumericInput(finalAed)) return parseNumericInput(finalAed);
        return spendItemFinalAed(item);
      }
      vm.budgetLineSpendItemApprovedAmount = spendItemApprovedAmount;
      function spendItemFinalAed(item) {
        var foreignAmount = spendForeignAmount(item);
        var aedAmount = spendAedAmount(item);
        return aedAmount * (1 + parseNumericInput(item.contingencyPercent) / 100);
      }
      vm.spendFinalAed = spendItemFinalAed;
      function spendForeignAmount(item) {
        if (!blankNumericInput(item && item.units) || !blankNumericInput(item && item.unitPrice)) return parseNumericInput(item && item.units) * parseNumericInput(item && item.unitPrice);
        return parseNumericInput(item && item.foreignAmount);
      }
      function spendAedAmount(item) {
        var foreignAmount = spendForeignAmount(item);
        var rate = currencyRateToLocal(item && item.currency, item && item.exchangeRate);
        return foreignAmount * rate;
      }
      vm.recalculateSpendForm = function () {
        if (!vm.form) return;
        vm.form.currency = String(vm.form.currency || "AED").toUpperCase();
        var rate = currencyRateToLocal(vm.form.currency, vm.form.exchangeRate);
        var foreignAmount = spendForeignAmount(vm.form);
        vm.form.exchangeRate = rate;
        vm.form.foreignAmount = foreignAmount ? Math.round(foreignAmount * 100) / 100 : "";
        vm.form.aedAmount = foreignAmount ? Math.round(foreignAmount * rate * 100) / 100 : "";
      };
      function petFinalAedWithSpend(pet, item) {
        var spendItemId = item && item.spendItemId;
        var existing = ((pet && pet.spendItems) || []).reduce(function (total, current) {
          if (spendItemId && String(current.spendItemId) === String(spendItemId)) return total;
          return total + spendItemFinalAed(current);
        }, 0);
        return existing + spendItemFinalAed(item || {});
      }
      function projectBudgetAmount(project) {
        return parseNumericInput(project && project.budget) || parseNumericInput(project && project.availableBudget);
      }
      vm.projectBudgetAmount = projectBudgetAmount;
      function validatePetRequestAmount(project, pet, requestedAmount) {
        requestedAmount = parseNumericInput(requestedAmount);
        var projectBudget = projectBudgetAmount(project);
        if (projectBudget > 0 && requestedAmount > projectBudget) {
          noticeError("PET Request amount exceeds the Project Budget. Project Budget: " + vm.money(projectBudget) + "; entered amount: " + vm.money(requestedAmount) + ".");
          return false;
        }
        var budgetLineTotal = petBudgetLineTotal(pet);
        if (pet && budgetLineTotal > requestedAmount) {
          noticeError("PET Request amount is below the existing Budget Line total for this PET Reference. Existing Budget Lines total: " + vm.money(budgetLineTotal) + "; entered PET amount: " + vm.money(requestedAmount) + ".");
          return false;
        }
        return true;
      }
      function validateBudgetLineAmount() {
        if (!validateNumericInput(vm.form && vm.form.cost, "Budget Line amount", false)) return false;
        var cost = parseNumericInput(vm.form && vm.form.cost);
        if (cost <= 0) { noticeError("A positive Budget Line amount is required."); return false; }
        vm.form.cost = cost;
        if (vm.form && vm.form.glNumber === "__NO_GL__") vm.form.glNumber = "";
        var available = budgetLineAvailablePetAmount(vm.selectedPet, vm.form && vm.form.budgetLineId);
        if (cost > available) {
          noticeError("Budget Line amount exceeds the Available PET Amount for PET Reference " + (vm.selectedPet && vm.selectedPet.code || "") + ". Available PET Amount: " + vm.money(Math.max(available, 0)) + "; entered amount: " + vm.money(cost) + ".");
          return false;
        }
        if (String(vm.form && vm.form.glNumber || "").trim()) {
          var gl = vm.selectedGlFund();
          if (!gl || !gl.isActive) { noticeError("Selected GL is not active or was not found."); return false; }
          var currentLine = (vm.selectedPet && vm.form && vm.form.budgetLineId && (vm.selectedPet.budgetLines || []).filter(function (line) { return Number(line.budgetLineId) === Number(vm.form.budgetLineId); })[0]) || null;
          var availableGl = parseNumericInput(gl.availableBalance);
          if (currentLine && normalizedGlNumber(currentLine.glNumber) === normalizedGlNumber(gl.glNumber)) availableGl += parseNumericInput(currentLine.cost);
          if (cost > availableGl) {
            noticeError("Budget Line amount exceeds the available GL balance for " + gl.glNumber + ". Available GL balance: " + vm.money(Math.max(availableGl, 0)) + "; entered amount: " + vm.money(cost) + ".");
            return false;
          }
        }
        return true;
      }
      function validateSpendFormAmounts(form) {
        var currency = String(form && form.currency || "AED").toUpperCase();
        if (!validatePetRequiredDropdowns(form, "PET line item")) return false;
        if (!validateNumericInput(form && form.units, "Units", false)) return false;
        if (!validateNumericInput(form && form.unitPrice, "Unit price", false)) return false;
        if (!validateNumericInput(form && form.foreignAmount, "FCY amount", true)) return false;
        if (!validateNumericInput(form && form.exchangeRate, "Exchange rate", currency === "AED")) return false;
        if (!validateNumericInput(form && form.contingencyPercent, "Contingency %", true)) return false;
        return true;
      }
      function validateBudgetSourceAmounts(form) {
        if (!validateNumericInput(form && form.budget, "Budget", false)) return false;
        if (!validateNumericInput(form && form.utilization, "Utilization", false)) return false;
        if (!validateNumericInput(form && form.availableBudget, "Available budget", false)) return false;
        return true;
      }
      function projectNeedsBudgetSelection(project) {
        return project && project.requiresPet !== false && (!project.budgetType || !project.budgetSourceId);
      }
      function validatePetBudgetSelection(project) {
        if (!projectNeedsBudgetSelection(project || vm.selectedProject)) return true;
        if (!vm.form || !vm.form.budgetType || !vm.form.budgetSourceId) {
          noticeError("Select CAPEX or OPEX and a budget source before adding PET for this project.");
          return false;
        }
        return true;
      }
      function applyProjectBudgetSelection(project) {
        if (!project || !vm.form || !vm.form.budgetType || !vm.form.budgetSourceId) return;
        var budget = vm.selectedBudgetSource();
        project.budgetType = vm.form.budgetType;
        project.budgetSourceId = vm.form.budgetSourceId;
        project.budgetSource = budget ? budget.externalId : project.budgetSource;
        project.availableBudget = budget ? budget.availableBudget : project.availableBudget;
        project.budget = budget ? budget.budget : project.budget;
      }
      function saveProjectBudgetSelectionIfNeeded(project) {
        if (!projectNeedsBudgetSelection(project)) return $q.when();
        if (!validatePetBudgetSelection(project)) return $q.reject({ handled: true });
        var payload = {
          projectId: project.projectId,
          isJira: !!project.jiraKey,
          jiraKey: project.jiraKey,
          projectName: project.projectName,
          projectType: project.projectType,
          accountableExecLead: project.accountableExecLead,
          accountableExec: project.accountableExec,
          smeLead: project.smeLead,
          projectSize: project.projectSize,
          projectSizingScores: JSON.stringify(project.projectSizingScores || {}),
          projectManager: project.projectManager,
          budgetType: vm.form.budgetType,
          budgetSourceId: vm.form.budgetSourceId,
        };
        return $http.post("api/portfolio/projects", payload).then(function () { applyProjectBudgetSelection(project); });
      }
      function selectedReportProject() {
        if (!vm.reportProjectId) return null;
        return (vm.projects || []).filter(function (project) { return String(project.projectId) === String(vm.reportProjectId); })[0] || null;
      }
      function emptyReportMetrics() {
        return { projectsRegistered: 0, activeProjects: 0, petsApproved: 0, petsOnTrack: 0, petsRejected: 0, invoicesRaised: 0, invoicesOutstanding: 0, invoicesSettled: 0, capexBudget: 0, capexUtilized: 0, opexBudget: 0, opexUtilized: 0 };
      }
      function projectIsActive(project) {
        return project && ["PET Rejected", "Rejected", "Cancelled", "Closed"].indexOf(String(project.status || "")) < 0;
      }
      function addProjectReportMetrics(metrics, project) {
        var pets = (project && project.petsLoaded && project.pets) || [];
        var invoices = [];
        metrics.projectsRegistered += project ? 1 : 0;
        metrics.activeProjects += projectIsActive(project) ? 1 : 0;
        if (pets.length) {
          metrics.petsApproved += pets.filter(function (pet) { return sameStatus(pet.status, "Approved"); }).length;
          metrics.petsOnTrack += pets.filter(function (pet) { return sameStatus(pet.status, "Pending Review") || sameStatus(pet.status, "Pending Approval"); }).length;
          metrics.petsRejected += pets.filter(function (pet) { return sameStatus(pet.status, "Rejected"); }).length;
          pets.forEach(function (pet) { (pet.budgetLines || []).forEach(function (line) { invoices = invoices.concat(line.invoices || []); }); });
        } else {
          metrics.petsApproved += Number(project && project.approvedPetCount) || 0;
          metrics.petsOnTrack += (Number(project && project.pendingReviewPetCount) || 0) + (Number(project && project.pendingApprovalPetCount) || 0);
          metrics.petsRejected += Number(project && project.rejectedPetCount) || 0;
        }
        metrics.invoicesRaised += invoices.length || Number(project && project.invoiceCount) || 0;
        metrics.invoicesOutstanding += invoices.filter(function (invoice) { return ["raised", "outstanding", "received"].indexOf(String(invoice.invoiceStatus || "").toLowerCase()) >= 0; }).length;
        metrics.invoicesSettled += invoices.filter(function (invoice) { return ["settled", "paid"].indexOf(String(invoice.invoiceStatus || "").toLowerCase()) >= 0; }).length;
        var budget = projectBudgetAmount(project);
        var approvedAmount = pets.filter(function (pet) { return sameStatus(pet.status, "Approved"); }).reduce(function (total, pet) { return total + parseNumericInput(pet.requestedAmount); }, 0);
        if (String(project && project.budgetType || "").toUpperCase() === "OPEX") {
          metrics.opexBudget += budget;
          metrics.opexUtilized += approvedAmount;
        } else {
          metrics.capexBudget += budget;
          metrics.capexUtilized += approvedAmount;
        }
      }
      function buildReportSummary(project, metrics, rows) {
        var budgetType = petProjectExpenseHead(project);
        var approvedBudget = project ? (budgetType === "OPEX" ? metrics.opexBudget : metrics.capexBudget) : metrics.capexBudget + metrics.opexBudget;
        var summary = {
          projectName: project ? project.projectName : "All Projects",
          demandId: project ? vm.projectDisplayId(project) : "All",
          budgetType: budgetType || "All",
          approvedBudget: approvedBudget,
          capexId: project ? project.budgetSource || "Not supplied" : "All budget sources",
          totalCommitted: 0,
          totalInvoiced: 0,
          remainingBudget: 0,
          utilization: 0,
          lpoIssued: 0,
          pendingCamLpo: 0,
        };
        var lineMap = {};
        var invoiceMap = {};
        (rows || []).forEach(function (row, index) {
          var countInTotals = sameStatus(row.petStatus || row.PetStatus, "Approved");
          var lineKey = row.budgetLineId || row.BudgetLineId || "row-" + index;
          if (countInTotals && (row.budgetLineId || row.BudgetLineId) && !lineMap[lineKey]) {
            lineMap[lineKey] = row;
            summary.totalCommitted += parseNumericInput(row.cost || row.Cost);
            if (sameStatus(row.lpoStatus || row.LpoStatus, "Issued")) summary.lpoIssued++;
            if (!sameStatus(row.camStatus || row.CamStatus, "Approved") || !sameStatus(row.lpoStatus || row.LpoStatus, "Issued")) summary.pendingCamLpo++;
          } else if (countInTotals && !(row.budgetLineId || row.BudgetLineId) && row.cost != null) {
            summary.totalCommitted += parseNumericInput(row.cost || row.Cost);
          }
          var invoiceId = row.invoiceId || row.InvoiceId;
          var invoiceKey = invoiceId || ((row.invoiceNo || row.InvoiceNo) ? "invoice-" + index : "");
          if (countInTotals && invoiceKey && !invoiceMap[invoiceKey]) {
            invoiceMap[invoiceKey] = true;
            summary.totalInvoiced += parseNumericInput(row.invoiceAmount || row.InvoiceAmount);
          }
        });
        summary.remainingBudget = summary.approvedBudget - summary.totalCommitted;
        summary.utilization = vm.percent(summary.totalCommitted, summary.approvedBudget);
        return summary;
      }
      vm.updateReportView = function () {
        var project = selectedReportProject();
        if (!project) {
          vm.reportMetrics = angular.copy(vm.metrics || emptyReportMetrics());
          if (!vm.reportMetrics.activeProjects) vm.reportMetrics.activeProjects = (vm.projects || []).filter(projectIsActive).length;
          vm.reportBudgetUsage = vm.budgetUsage || [];
          vm.reportSummary = buildReportSummary(null, vm.reportMetrics, vm.reportBudgetUsage);
          return;
        }
        var metrics = emptyReportMetrics();
        addProjectReportMetrics(metrics, project);
        vm.reportMetrics = metrics;
        vm.reportBudgetUsage = (vm.budgetUsage || []).filter(function (row) { return String(row.projectId) === String(project.projectId); });
        vm.reportSummary = buildReportSummary(project, vm.reportMetrics, vm.reportBudgetUsage);
      };
      vm.onReportProjectChange = function () {
        var project = selectedReportProject();
        if (project && !vm.demo && !project.petsLoaded) return refreshProjectPets(project.projectId, true, true).then(function () { vm.updateReportView(); redraw(); });
        vm.updateReportView();
        redraw();
      };
      vm.updateReportProjectView = function (keepPage) {
        var query = (vm.reportProjectSearch || "").toLowerCase();
        var filtered = (vm.projects || []).filter(function (project) {
          var statusMatch = projectHasStatus(project, project.pets || [], vm.reportProjectStatusFilter);
          var budgetTypeMatch = !vm.reportProjectBudgetTypeFilter || String(project.budgetType || "").toUpperCase() === vm.reportProjectBudgetTypeFilter;
          var queryMatch = !query || [vm.projectDisplayId(project), project.projectCode, project.jiraKey, project.projectName, project.projectType, project.budgetType, project.accountableExecLead, project.smeLead, project.projectManager, project.requestorName, project.requestorEmail, project.budgetSource, project.status].join(" ").toLowerCase().indexOf(query) >= 0;
          return statusMatch && budgetTypeMatch && queryMatch;
        });
        vm.reportProjectFilteredCount = filtered.length;
        vm.reportProjectPageCount = Math.max(1, Math.ceil(filtered.length / vm.reportProjectPageSize));
        if (!keepPage || vm.reportProjectPage > vm.reportProjectPageCount) vm.reportProjectPage = 1;
        var start = (vm.reportProjectPage - 1) * vm.reportProjectPageSize;
        vm.visibleReportProjects = filtered.slice(start, start + vm.reportProjectPageSize);
      };
      // Budget line Status (stored in BudgetLines.CamStatus) lifecycle: Raised to Vendor > Memo in Progress > Memo Approved > LPO in Progress > LPO Approved > Completed.
      vm.approvalMonitorStages = {
        cam: { key: "cam", label: "CAM Pending", statuses: ["Raised to Vendor", "Memo in Progress"], dateField: "camCreatedDate", dateLabel: "CAM created" },
        lpo: { key: "lpo", label: "LPO Pending", statuses: ["Memo Approved", "LPO in Progress"], dateField: "camApprovedDate", dateLabel: "CAM approved" },
      };
      function approvalMonitorStageFor(status) {
        return ["cam", "lpo"].filter(function (key) {
          return vm.approvalMonitorStages[key].statuses.some(function (item) { return sameStatus(status, item); });
        })[0] || "";
      }
      function localDateOnly(value) {
        if (!value) return null;
        if (angular.isDate(value)) return isNaN(value.getTime()) ? null : new Date(value.getFullYear(), value.getMonth(), value.getDate());
        var match = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(value));
        if (match) return new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
        var parsed = new Date(value);
        return isNaN(parsed.getTime()) ? null : new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
      }
      function approvalMonitorSourceLines() {
        if (!vm.demo) return vm.approvalMonitorSource || [];
        var lines = [];
        (vm.projects || []).forEach(function (project) {
          (project.pets || []).forEach(function (pet) {
            if (!sameStatus(pet.status, "Approved")) return;
            (pet.budgetLines || []).forEach(function (line) {
              lines.push(angular.extend({}, line, { projectId: project.projectId, petId: pet.petId, petCode: pet.code, petStatus: pet.status, petAmount: pet.requestedAmount }));
            });
          });
        });
        return lines;
      }
      function vendor360SourceLines() {
        if (!vm.demo) return vm.vendor360LineSource || [];
        var lines = [];
        (vm.projects || []).forEach(function (project) {
          (project.pets || []).forEach(function (pet) {
            (pet.budgetLines || []).forEach(function (line) {
              lines.push(angular.extend({}, line, { projectId: project.projectId, petId: pet.petId, petCode: pet.code, petStatus: pet.status, petAmount: pet.requestedAmount }));
            });
          });
        });
        return lines;
      }
      function buildApprovalMonitorRows() {
        var projectsById = {};
        var seen = {};
        var today = localDateOnly(new Date());
        (vm.projects || []).forEach(function (project) { projectsById[String(project.projectId)] = project; });
        return approvalMonitorSourceLines().reduce(function (rows, line) {
          var stageKey = approvalMonitorStageFor(line.camStatus);
          var project = projectsById[String(line.projectId)];
          var key = String(line.budgetLineId);
          if (!stageKey || !project || !sameStatus(line.petStatus, "Approved") || seen[key]) return rows;
          seen[key] = true;
          var stage = vm.approvalMonitorStages[stageKey];
          var stageDate = localDateOnly(line[stage.dateField]);
          var pendingSince = stageDate || localDateOnly(line.createdUtc);
          rows.push({
            stage: stageKey,
            line: line,
            project: project,
            amount: parseNumericInput(line.cost),
            pendingSince: pendingSince,
            pendingSinceLabel: stageDate ? stage.dateLabel : "Budget line created",
            pendingDays: pendingSince ? Math.max(0, Math.round((today - pendingSince) / 86400000)) : null,
          });
          return rows;
        }, []);
      }
      vm.updateApprovalMonitorView = function (keepPage) {
        var rows = buildApprovalMonitorRows();
        var summary = {};
        Object.keys(vm.approvalMonitorStages).forEach(function (key) {
          var stageRows = rows.filter(function (row) { return row.stage === key; });
          var ages = stageRows.map(function (row) { return row.pendingDays; }).filter(function (days) { return days !== null; });
          summary[key] = {
            count: stageRows.length,
            total: stageRows.reduce(function (total, row) { return total + row.amount; }, 0),
            oldestDays: ages.length ? Math.max.apply(null, ages) : null,
          };
        });
        vm.approvalMonitorSummary = summary;
        var query = (vm.approvalMonitorSearch || "").toLowerCase();
        var filtered = rows.filter(function (row) {
          if (row.stage !== vm.approvalMonitorFilter) return false;
          var line = row.line;
          var project = row.project;
          return !query || [vm.projectDisplayId(project), project.projectName, project.projectType, project.budgetType, project.budgetSource, project.projectManager, line.petCode, line.petReference, line.vendor, line.justification, line.glNumber, line.camId, line.camStatus, line.lpoRequest].join(" ").toLowerCase().indexOf(query) >= 0;
        }).sort(function (a, b) { return (b.pendingDays || 0) - (a.pendingDays || 0) || Number(a.line.budgetLineId) - Number(b.line.budgetLineId); });
        vm.approvalMonitorFilteredCount = filtered.length;
        vm.approvalMonitorFilteredTotal = filtered.reduce(function (total, row) { return total + row.amount; }, 0);
        vm.approvalMonitorPageCount = Math.max(1, Math.ceil(filtered.length / vm.approvalMonitorPageSize));
        if (!keepPage || vm.approvalMonitorPage > vm.approvalMonitorPageCount) vm.approvalMonitorPage = 1;
        var start = (vm.approvalMonitorPage - 1) * vm.approvalMonitorPageSize;
        vm.visibleApprovalMonitorRows = filtered.slice(start, start + vm.approvalMonitorPageSize);
      };
      vm.approvalMonitorReady = function () { return vm.demo || (vm.approvalMonitorLoaded && !vm.approvalMonitorError); };
      vm.changeApprovalMonitorPage = function (page) { vm.approvalMonitorPage = Math.max(1, Math.min(vm.approvalMonitorPageCount, page)); vm.updateApprovalMonitorView(true); redraw(); };
      function scrollToReportElement(id) {
        $timeout(function () {
          var element = document.getElementById(id);
          if (element && element.scrollIntoView) element.scrollIntoView({ behavior: "smooth", block: "start" });
        }, 0, false);
      }
      vm.openApprovalMonitor = function (stageKey) {
        if (!vm.approvalMonitorStages[stageKey]) return;
        if (vm.approvalMonitorFilter !== stageKey) vm.approvalMonitorSearch = "";
        vm.approvalMonitorFilter = stageKey;
        vm.updateApprovalMonitorView();
        redraw();
        scrollToReportElement("approval-monitor-list");
      };
      vm.closeApprovalMonitor = function () {
        vm.approvalMonitorFilter = "";
        vm.updateApprovalMonitorView();
        redraw();
        scrollToReportElement("approval-monitoring");
      };
      vm.editApprovalMonitorLine = function (row) {
        if (!row || !vm.can("request")) return;
        function openLine() {
          var pet = projectPetById(row.project, row.line.petId);
          var line = pet && (pet.budgetLines || []).filter(function (item) { return Number(item.budgetLineId) === Number(row.line.budgetLineId); })[0];
          if (!line) { noticeError("This budget line is no longer available. Refresh to see the latest records."); return; }
          vm.openBudgetLine(pet, line);
        }
        if (!vm.demo) return refreshProjectPets(row.project.projectId, false, true).then(openLine);
        openLine();
      };
      function loadApprovalMonitoring() {
        vm.approvalMonitorLoading = true;
        return $http.get("api/portfolio/approval-monitoring", { params: { _: Date.now() } }).then(function (response) {
          vm.approvalMonitorSource = angular.isArray(response.data) ? response.data : [];
          vm.approvalMonitorError = "";
        }, function (response) {
          vm.approvalMonitorSource = [];
          vm.approvalMonitorError = responseMessage(response, "Unable to load approval monitoring.");
        }).then(function () {
          vm.approvalMonitorLoading = false;
          vm.approvalMonitorLoaded = true;
          vm.updateApprovalMonitorView(true);
          redraw();
        });
      }
      // Existing business statuses: invoice "outstanding" set (vw_ManagementDashboard), GL exclusions (sp_SaveBudgetLine), budget line Status dropdown.
      var pendingInvoiceStatuses = ["Raised", "Received", "Outstanding"];
      var excludedBudgetLineStatuses = ["Rejected", "Cancelled"];
      var lpoStageStatuses = ["LPO in Progress", "LPO Approved", "Completed"];
      function statusIn(status, list) {
        return list.some(function (item) { return sameStatus(status, item); });
      }
      function daysSince(value) {
        var date = localDateOnly(value);
        return date ? Math.max(0, Math.round((localDateOnly(new Date()) - date) / 86400000)) : null;
      }
      function vendorKey(name) {
        return String(name || "").trim().replace(/\s+/g, " ").toLowerCase();
      }
      function vendorInvoiceSourceRows() {
        if (!vm.demo) return vm.vendorInvoiceSource || [];
        var rows = [];
        vendor360SourceLines().forEach(function (line) {
          (line.invoices || []).forEach(function (invoice) { rows.push(angular.extend({}, invoice, { budgetLineId: line.budgetLineId })); });
        });
        return rows;
      }
      function notePendingItem(target, item) {
        if (item.days === null) return;
        if (!target.oldest || item.days > target.oldest.days) target.oldest = item;
      }
      function buildVendorSpendRows() {
        var projectsById = {};
        var pendingByLine = {};
        var vendors = {};
        var lineIndex = {};
        var seenInvoices = {};
        (vm.projects || []).forEach(function (project) { projectsById[String(project.projectId)] = project; });
        buildApprovalMonitorRows().forEach(function (row) { pendingByLine[String(row.line.budgetLineId)] = row; });
        vendor360SourceLines().forEach(function (line) {
          var id = String(line.budgetLineId);
          var project = projectsById[String(line.projectId)];
          if (!project || lineIndex[id]) return;
          var key = vendorKey(line.vendor);
          var vendor = vendors[key] || (vendors[key] = { key: key, name: String(line.vendor || "").trim() || "Not supplied", lines: [], invoices: [], projectMap: {}, projects: [], awarded: 0, utilized: 0, camPendingCount: 0, lpoPendingCount: 0, invoicePendingCount: 0, pendingValue: 0, oldest: null });
          var pending = pendingByLine[id] || null;
          var countsInSummary = sameStatus(line.petStatus, "Approved") && !statusIn(line.camStatus, excludedBudgetLineStatuses);
          var entry = {
            line: line,
            project: project,
            vendor: vendor,
            amount: parseNumericInput(line.cost),
            invoiced: 0,
            pending: pending,
            countsInSummary: countsInSummary,
            camPending: approvalMonitorStageFor(line.camStatus) === "cam",
            lpoPending: approvalMonitorStageFor(line.camStatus) === "lpo",
            camPendingDays: daysSince(line.camCreatedDate || line.createdUtc),
            lpoPendingDays: daysSince(line.camApprovedDate || line.createdUtc),
            isLpo: !!String(line.lpoRequest || "").trim() || !!String(line.lpoStatus || "").trim() || !!line.lpoIssueDate || statusIn(line.camStatus, lpoStageStatuses) || !!(pending && pending.stage === "lpo"),
            isActiveContract: !sameStatus(line.camStatus, "Completed") && (sameStatus(line.camStatus, "LPO Approved") || sameStatus(line.lpoStatus, "Issued")),
          };
          lineIndex[id] = entry;
          vendor.lines.push(entry);
          var projectKey = String(project.projectId);
          var projectEntry = vendor.projectMap[projectKey];
          if (!projectEntry) {
            projectEntry = vendor.projectMap[projectKey] = { project: project, lineCount: 0, awarded: 0, utilized: 0, pendingValue: 0 };
            vendor.projects.push(projectEntry);
          }
          projectEntry.lineCount++;
          if (countsInSummary) {
            vendor.hasAwardedLine = true;
            vendor.awarded += entry.amount;
            projectEntry.awarded += entry.amount;
          }
          if (!pending) return;
          if (pending.stage === "cam") vendor.camPendingCount++;
          else vendor.lpoPendingCount++;
          vendor.pendingValue += pending.amount;
          projectEntry.pendingValue += pending.amount;
          notePendingItem(vendor, { type: pending.stage === "cam" ? "CAM" : "LPO", reference: line.camId || line.petReference || line.petCode, days: pending.pendingDays });
        });
        vendorInvoiceSourceRows().forEach(function (invoice) {
          var entry = lineIndex[String(invoice.budgetLineId)];
          var invoiceKey = invoice.invoiceId != null ? String(invoice.invoiceId) : "";
          if (!entry || (invoiceKey && seenInvoices[invoiceKey])) return;
          if (invoiceKey) seenInvoices[invoiceKey] = true;
          var vendor = entry.vendor;
          var projectEntry = vendor.projectMap[String(entry.project.projectId)];
          var isPending = statusIn(invoice.invoiceStatus, pendingInvoiceStatuses);
          var item = { invoice: invoice, entry: entry, amount: parseNumericInput(invoice.invoiceAmount), isPending: isPending, days: isPending ? daysSince(invoice.createdUtc) : null };
          vendor.invoices.push(item);
          entry.invoiced += item.amount;
          if (entry.countsInSummary) {
            vendor.utilized += item.amount;
            projectEntry.utilized += item.amount;
          }
          if (!entry.countsInSummary || !isPending) return;
          vendor.invoicePendingCount++;
          vendor.pendingValue += item.amount;
          projectEntry.pendingValue += item.amount;
          notePendingItem(vendor, { type: "Invoice", reference: invoice.invoiceNumber, days: item.days });
        });
        var rows = Object.keys(vendors).filter(function (key) { return vendors[key].hasAwardedLine; }).map(function (key) {
          var vendor = vendors[key];
          vendor.outstanding = vendor.awarded - vendor.utilized;
          vendor.pendingCount = vendor.camPendingCount + vendor.lpoPendingCount + vendor.invoicePendingCount;
          vendor.utilizationPercent = vm.percent(vendor.utilized, vendor.awarded);
          return vendor;
        }).sort(function (a, b) { return b.awarded - a.awarded || b.utilized - a.utilized || a.name.localeCompare(b.name); });
        rows.forEach(function (vendor, index) { vendor.rank = index + 1; });
        return rows;
      }
      vm.vendorSpendReady = function () {
        return vm.demo || (vm.approvalMonitorLoaded && vm.vendor360LinesLoaded && vm.vendorInvoicesLoaded && !vm.approvalMonitorError && !vm.vendor360LineError && !vm.vendorInvoiceError);
      };
      vm.vendorSpendError = function () {
        return vm.approvalMonitorError || vm.vendor360LineError || vm.vendorInvoiceError;
      };
      vm.updateVendorSpendView = function (keepPage) {
        var rows = buildVendorSpendRows();
        vm.vendorSpendRows = rows;
        vm.vendorSpendSummary = rows.reduce(function (summary, vendor) {
          summary.vendorCount++;
          summary.awarded += vendor.awarded;
          summary.utilized += vendor.utilized;
          summary.outstanding += vendor.outstanding;
          summary.pendingValue += vendor.pendingValue;
          if (vendor.pendingCount) summary.vendorsWithPending++;
          return summary;
        }, { vendorCount: 0, awarded: 0, utilized: 0, outstanding: 0, pendingValue: 0, vendorsWithPending: 0 });
        var query = vendorKey(vm.vendorSpendSearch);
        var sortKey = vm.vendorSort.key;
        var direction = vm.vendorSort.desc ? -1 : 1;
        var filtered = rows.filter(function (vendor) {
          return (!query || vendor.key.indexOf(query) >= 0) && (vm.vendorPendingFilter !== "pending" || vendor.pendingCount > 0);
        }).sort(function (a, b) {
          var left = sortKey === "name" ? a.name.toLowerCase() : sortKey === "oldest" ? (a.oldest ? a.oldest.days : -1) : a[sortKey];
          var right = sortKey === "name" ? b.name.toLowerCase() : sortKey === "oldest" ? (b.oldest ? b.oldest.days : -1) : b[sortKey];
          return (left < right ? -1 : left > right ? 1 : 0) * direction || a.rank - b.rank;
        });
        vm.vendorSpendFilteredCount = filtered.length;
        vm.vendorSpendPageCount = Math.max(1, Math.ceil(filtered.length / vm.vendorSpendPageSize));
        if (!keepPage || vm.vendorSpendPage > vm.vendorSpendPageCount) vm.vendorSpendPage = 1;
        var start = (vm.vendorSpendPage - 1) * vm.vendorSpendPageSize;
        vm.visibleVendorSpendRows = filtered.slice(start, start + vm.vendorSpendPageSize);
        refreshVendor360();
      };
      vm.sortVendorSpend = function (key) {
        vm.vendorSort = { key: key, desc: vm.vendorSort.key === key ? !vm.vendorSort.desc : key !== "name" && key !== "rank" };
        vm.updateVendorSpendView();
        redraw();
      };
      vm.vendorSortState = function (key) {
        if (vm.vendorSort.key !== key) return "none";
        return vm.vendorSort.desc ? "descending" : "ascending";
      };
      vm.changeVendorSpendPage = function (page) { vm.vendorSpendPage = Math.max(1, Math.min(vm.vendorSpendPageCount, page)); vm.updateVendorSpendView(true); redraw(); };
      function refreshVendor360() {
        var vendor = vm.selectedVendorKey ? vm.vendorSpendRows.filter(function (row) { return row.key === vm.selectedVendorKey; })[0] : null;
        if (!vendor) { vm.vendor360 = vm.selectedVendorKey ? { missing: true } : null; return; }
        vm.vendor360 = {
          vendor: vendor,
          projects: vendor.projects.slice().sort(function (a, b) { return b.awarded - a.awarded; }),
          cams: vendor.lines,
          pendingCams: vendor.lines.filter(function (entry) { return entry.camPending; }),
          pendingLpos: vendor.lines.filter(function (entry) { return entry.lpoPending; }),
          lpos: vendor.lines.filter(function (entry) { return entry.isLpo; }),
          invoices: vendor.invoices,
          pendingInvoices: vendor.invoices.filter(function (item) { return item.isPending; }),
          contracts: vendor.lines.filter(function (entry) { return entry.isActiveContract; }),
        };
      }
      vm.openVendor360 = function (vendor) {
        if (!vendor) return;
        vm.selectedVendorKey = vendor.key;
        vm.vendor360Tab = "projects";
        refreshVendor360();
        redraw();
        scrollToReportElement("vendor-spend");
      };
      vm.closeVendor360 = function () {
        vm.selectedVendorKey = "";
        vm.vendor360 = null;
        redraw();
        scrollToReportElement("vendor-spend");
      };
      vm.setVendor360Tab = function (tab) {
        vm.vendor360Tab = tab;
        redraw();
      };
      vm.editVendorLine = function (entry) {
        if (entry) vm.editApprovalMonitorLine({ project: entry.project, line: entry.line });
      };
      vm.openVendorInvoice = function (item) {
        if (!item) return;
        var entry = item.entry;
        function openLine() {
          var pet = projectPetById(entry.project, entry.line.petId);
          var line = pet && (pet.budgetLines || []).filter(function (candidate) { return Number(candidate.budgetLineId) === Number(entry.line.budgetLineId); })[0];
          if (!line) { noticeError("This invoice is no longer available. Refresh to see the latest records."); return; }
          vm.openInvoiceView(line);
        }
        if (!vm.demo) return refreshProjectPets(entry.project.projectId, false, true).then(openLine);
        openLine();
      };
      function loadVendorInvoices() {
        return $http.get("api/portfolio/vendor-invoices", { params: { allStatuses: true, _: Date.now() } }).then(function (response) {
          vm.vendorInvoiceSource = angular.isArray(response.data) ? response.data : [];
          vm.vendorInvoiceError = "";
        }, function (response) {
          vm.vendorInvoiceSource = [];
          vm.vendorInvoiceError = responseMessage(response, "Unable to load vendor invoices.");
        }).then(function () {
          vm.vendorInvoicesLoaded = true;
        });
      }
      function loadVendor360Lines() {
        return $http.get("api/portfolio/approval-monitoring", { params: { allStatuses: true, _: Date.now() } }).then(function (response) {
          vm.vendor360LineSource = angular.isArray(response.data) ? response.data : [];
          vm.vendor360LineError = "";
        }, function (response) {
          vm.vendor360LineSource = [];
          vm.vendor360LineError = responseMessage(response, "Unable to load vendor history.");
        }).then(function () {
          vm.vendor360LinesLoaded = true;
        });
      }
      function projectHasStatus(project, pets, status) {
        if (!status) return true;
        if (sameStatus(status, "Active")) return projectIsActive(project);
        if (sameStatus(status, "Registered")) return sameStatus(project && project.status, status);
        if ((pets || []).some(function (pet) { return sameStatus(pet.status, status); })) return true;
        if (sameStatus(status, "Approved")) return Number(project && project.approvedPetCount) > 0;
        if (sameStatus(status, "Pending Review")) return Number(project && project.pendingReviewPetCount) > 0;
        if (sameStatus(status, "Pending Approval")) return Number(project && project.pendingApprovalPetCount) > 0;
        if (sameStatus(status, "Rejected")) return Number(project && project.rejectedPetCount) > 0;
        if (sameStatus(status, "Sent Back")) return Number(project && project.sentBackPetCount) > 0;
        return false;
      }
      function createdByCurrentUser(record) {
        var currentEmail = (vm.session && vm.session.email || "").trim().toLowerCase();
        return !!currentEmail && String(record && record.createdBy || "").trim().toLowerCase() === currentEmail;
      }
      function spendItemCreatedByCurrentUser(item, pet) {
        if (createdByCurrentUser(item)) return true;
        return !String(item && item.createdBy || "").trim() && createdByCurrentUser(pet);
      }
      function projectRequestorMatchesCurrentUser(project) {
        var currentEmail = (vm.session && vm.session.email || "").trim().toLowerCase();
        var currentName = (vm.session && vm.session.displayName || "").trim().toLowerCase();
        return (project.requestorEmail || "").trim().toLowerCase() === currentEmail || (project.requestorName || "").trim().toLowerCase() === currentName;
      }
      function projectHasCurrentUserCreatedRecord(project) {
        if (projectRequestorMatchesCurrentUser(project) || project.hasMyCreatedRecord === true || project.hasMyCreatedRecord === 1) return true;
        return (project.pets || []).some(function (pet) {
          return createdByCurrentUser(pet) || (pet.spendItems || []).some(function (item) { return spendItemCreatedByCurrentUser(item, pet); });
        }) || (project.budgetLines || []).some(function (line) {
          return createdByCurrentUser(line) || (line.invoices || []).some(createdByCurrentUser);
        });
      }
      vm.visiblePets = function (project) {
        return (project && project.pets || []).filter(function (pet) {
          return vm.viewFilter !== "my" || createdByCurrentUser(pet) || (pet.spendItems || []).some(function (item) { return spendItemCreatedByCurrentUser(item, pet); });
        });
      };
      vm.visibleSpendItems = function (pet) {
        return (pet && pet.spendItems || []).filter(function (item) {
          return vm.viewFilter !== "my" || spendItemCreatedByCurrentUser(item, pet);
        });
      };
      vm.visibleBudgetLines = function (project) {
        return (project && project.budgetLines || []).filter(function (line) {
          return vm.viewFilter !== "my" || createdByCurrentUser(line) || (line.invoices || []).some(createdByCurrentUser);
        });
      };
      vm.visibleInvoices = function (line) {
        return (line && line.invoices || []).filter(function (invoice) {
          return vm.viewFilter !== "my" || createdByCurrentUser(invoice);
        });
      };
      vm.updateView = function (keepPage) {
        var query = vm.search.toLowerCase();
        var currentEmail = (vm.session && vm.session.email || "").toLowerCase();
        var filtered = vm.projects.filter(function (p) {
          var pets = p.pets || [];
          var statusMatch = projectHasStatus(p, pets, vm.statusFilter);
          var isMine = projectRequestorMatchesCurrentUser(p);
          var viewMatch = vm.viewFilter !== "nonProject" && (vm.viewFilter === "all" ||
            (vm.viewFilter === "my" && projectHasCurrentUserCreatedRecord(p)) ||
            (vm.viewFilter === "jira" && !!p.jiraKey) ||
            (vm.viewFilter === "nonJira" && !p.jiraKey) ||
            (vm.viewFilter === "pendingReview" && pets.some(function (pet) { return pet.status === "Pending Review"; })) ||
            (vm.viewFilter === "pendingApproval" && pets.some(function (pet) { return pet.status === "Pending Approval"; })) ||
            (vm.viewFilter === "approved" && pets.some(function (pet) { return pet.status === "Approved" && (isMine || (pet.approverEmail || "").toLowerCase() === currentEmail); })) ||
            (vm.viewFilter === "reviewed" && pets.some(function (pet) { return !!pet.reviewedUtc; })));
          return (
            viewMatch &&
            statusMatch &&
            (!query ||
              [
                p.projectCode,
                p.jiraKey,
                p.projectName,
                p.accountableExecLead,
                p.requestorEmail,
              ]
                .join(" ")
                .toLowerCase()
                .indexOf(query) >= 0)
          );
        });
        vm.filteredCount = filtered.length;
        vm.pageCount = Math.max(1, Math.ceil(filtered.length / vm.pageSize));
        if (!keepPage || vm.page > vm.pageCount) vm.page = 1;
        var start = (vm.page - 1) * vm.pageSize;
        vm.visibleProjects = filtered.slice(start, start + vm.pageSize);
        vm.visibleNonProjectOpex = (vm.nonProjectOpex || []).filter(function (row) {
          return vm.viewFilter !== "nonProject" || !query || [row.initiative, row.platform, row.lineItem, row.opexReference, row.vendor, row.createdBy]
            .join(" ").toLowerCase().indexOf(query) >= 0;
        });
        vm.approvalItems = buildApprovalItems();
        vm.updateApprovalView(keepPage);
        vm.updateBudgetView(keepPage);
        vm.updateCurrencyView(keepPage);
        vm.updateVendorView(keepPage);
        vm.updateGlView(keepPage);
        vm.updateReportView();
        vm.updateReportProjectView(keepPage);
        vm.updateApprovalMonitorView(keepPage);
        vm.updateVendorSpendView(keepPage);
      };
      vm.changePage = function (page) { vm.page = Math.max(1, Math.min(vm.pageCount, page)); vm.updateView(true); redraw(); };
      vm.changeApprovalPage = function (page) { vm.approvalPage = Math.max(1, Math.min(vm.approvalPageCount, page)); vm.updateApprovalView(true); redraw(); };
      vm.changeBudgetPage = function (page) { vm.budgetPage = Math.max(1, Math.min(vm.budgetPageCount, page)); vm.updateBudgetView(true); redraw(); };
      vm.changeCurrencyPage = function (page) { vm.currencyPage = Math.max(1, Math.min(vm.currencyPageCount, page)); vm.updateCurrencyView(true); redraw(); };
      vm.changeVendorPage = function (page) { vm.vendorPage = Math.max(1, Math.min(vm.vendorPageCount, page)); vm.updateVendorView(true); redraw(); };
      vm.changeGlPage = function (page) { vm.glPage = Math.max(1, Math.min(vm.glPageCount, page)); vm.updateGlView(true); redraw(); };
      vm.changeReportProjectPage = function (page) { vm.reportProjectPage = Math.max(1, Math.min(vm.reportProjectPageCount, page)); vm.updateReportProjectView(true); redraw(); };
      vm.changeRolePage = function (page) { vm.rolePage = Math.max(1, Math.min(vm.rolePageCount, page)); vm.updateRoleView(true); redraw(); };
      function buildApprovalItems() {
        var result = [];
        var canReview = vm.hasRole("Reviewer");
        var canApprove = vm.hasRole("Approver");
        vm.projects.forEach(function (p) {
          var reviewPets = [];
          var approvePets = [];
          p.pets.forEach(function (pet) {
            if (pet.status === "Pending Review" && canReview && vm.isReviewerForPet(p, pet)) reviewPets.push(pet);
            if (pet.status === "Pending Approval" && canApprove && vm.isApproverForPet(p, pet)) approvePets.push(pet);
          });
          if (reviewPets.length) result.push({ project: p, pet: reviewPets[0], pets: reviewPets, petCount: reviewPets.length, requestedAmount: reviewPets.reduce(function (total, pet) { return total + (Number(pet.requestedAmount) || 0); }, 0), stage: "review", action: "Review" });
          if (approvePets.length) result.push({ project: p, pet: approvePets[0], pets: approvePets, petCount: approvePets.length, requestedAmount: approvePets.reduce(function (total, pet) { return total + (Number(pet.requestedAmount) || 0); }, 0), stage: "approve", action: "Approve" });
        });
        return result;
      }
      vm.updateApprovalView = function (keepPage) {
        var query = (vm.approvalSearch || "").toLowerCase();
        var filtered = (vm.approvalItems || []).filter(function (item) {
          return !query || [item.project.projectCode, item.project.jiraKey, item.project.projectName, item.project.projectType, (item.pets || []).map(function (pet) { return pet.code; }).join(" "), item.pet.status, item.project.budgetSource, item.project.requestorEmail, item.project.requestorName, item.pet.reviewerEmail, item.pet.approverEmail].join(" ").toLowerCase().indexOf(query) >= 0;
        });
        vm.approvalFilteredCount = filtered.length;
        vm.approvalPageCount = Math.max(1, Math.ceil(filtered.length / vm.approvalPageSize));
        if (!keepPage || vm.approvalPage > vm.approvalPageCount) vm.approvalPage = 1;
        var start = (vm.approvalPage - 1) * vm.approvalPageSize;
        vm.visibleApprovalItems = filtered.slice(start, start + vm.approvalPageSize);
      };
      function approvalSelectionKey(item) { return item && item.pet ? String(item.pet.petId) : ""; }
      vm.isApprovalSelected = function (item) { return !!vm.approvalSelection[approvalSelectionKey(item)]; };
      vm.toggleApprovalSelection = function (item) {
        var key = approvalSelectionKey(item);
        if (!key) return;
        if (vm.approvalSelection[key]) delete vm.approvalSelection[key];
        else vm.approvalSelection[key] = item.stage;
      };
      vm.selectedApprovalItems = function (stage) {
        return (vm.approvalItems || []).filter(function (item) {
          return vm.approvalSelection[approvalSelectionKey(item)] && (!stage || item.stage === stage);
        });
      };
      vm.selectedApprovalCount = function (stage) { return vm.selectedApprovalItems(stage).length; };
      vm.clearApprovalSelection = function () { vm.approvalSelection = {}; };
      function canSelectDecisionPet(project, pet, stage) {
        if (!project || !pet) return false;
        if (stage === "review") return pet.status === "Pending Review" && vm.isReviewerForPet(project, pet);
        return pet.status === "Pending Approval" && vm.isApproverForPet(project, pet);
      }
      function decisionSelectionKey(pet) { return pet ? String(pet.petId) : ""; }
      function rebuildBulkDecisionItems(stage) {
        var decisionStage = stage || (vm.modal && vm.modal.stage);
        vm.bulkDecisionItems = (vm.decisionPetRows || []).filter(function (item) {
          return vm.decisionSelection[decisionSelectionKey(item.pet)] && canSelectDecisionPet(item.project, item.pet, decisionStage);
        });
        if (vm.form) {
          vm.form.requestedAmount = vm.bulkDecisionItems.reduce(function (total, item) { return total + (Number(item.pet.requestedAmount) || 0); }, 0);
          vm.form.code = vm.bulkDecisionItems.length + " PET" + (vm.bulkDecisionItems.length === 1 ? "" : "s") + " selected";
        }
      }
      function buildDecisionPetRows(project, selectedPet, stage) {
        vm.decisionSelection = {};
        vm.decisionPetRows = ((project && project.pets) || []).map(function (pet) {
          if (selectedPet && pet.petId === selectedPet.petId && canSelectDecisionPet(project, pet, stage)) vm.decisionSelection[decisionSelectionKey(pet)] = true;
          return { project: project, pet: pet };
        });
        rebuildBulkDecisionItems(stage);
      }
      vm.canSelectDecisionPet = function (item) { return item && canSelectDecisionPet(item.project, item.pet, vm.modal && vm.modal.stage); };
      vm.isDecisionPetSelected = function (item) { return !!vm.decisionSelection[decisionSelectionKey(item && item.pet)]; };
      vm.toggleDecisionPet = function (item) {
        if (!vm.canSelectDecisionPet(item)) return;
        var key = decisionSelectionKey(item.pet);
        if (vm.decisionSelection[key]) delete vm.decisionSelection[key];
        else vm.decisionSelection[key] = true;
        rebuildBulkDecisionItems();
      };
      function decisionSelectableItems() {
        return (vm.decisionPetRows || []).filter(function (item) { return vm.canSelectDecisionPet(item); });
      }
      vm.decisionSelectableCount = function () { return decisionSelectableItems().length; };
      vm.allDecisionPetsSelected = function () {
        var items = decisionSelectableItems();
        return !!items.length && items.every(function (item) { return vm.isDecisionPetSelected(item); });
      };
      vm.toggleAllDecisionPets = function () {
        var items = decisionSelectableItems();
        if (!items.length) return;
        var selectAll = !vm.allDecisionPetsSelected();
        items.forEach(function (item) {
          var key = decisionSelectionKey(item.pet);
          if (selectAll) vm.decisionSelection[key] = true;
          else delete vm.decisionSelection[key];
        });
        rebuildBulkDecisionItems();
      };
      vm.selectedDecisionCount = function () { return vm.bulkDecisionItems.length; };
      vm.updateBudgetView = function (keepPage) {
        var query = (vm.budgetSearch || "").toLowerCase();
        var filtered = (vm.budgets || []).filter(function (budget) {
          return !query || [budget.budgetType, budget.externalId, budget.description].join(" ").toLowerCase().indexOf(query) >= 0;
        });
        vm.budgetFilteredCount = filtered.length;
        vm.budgetPageCount = Math.max(1, Math.ceil(filtered.length / vm.budgetPageSize));
        if (!keepPage || vm.budgetPage > vm.budgetPageCount) vm.budgetPage = 1;
        var start = (vm.budgetPage - 1) * vm.budgetPageSize;
        vm.visibleBudgets = filtered.slice(start, start + vm.budgetPageSize);
      };
      vm.updateCurrencyView = function (keepPage) {
        var query = (vm.currencySearch || "").toLowerCase();
        var filtered = (vm.currencies || []).filter(function (currency) {
          return !query || [currency.code, currency.name, currency.rateToLocal, currency.isActive ? "active" : "inactive"].join(" ").toLowerCase().indexOf(query) >= 0;
        });
        vm.currencyFilteredCount = filtered.length;
        vm.currencyPageCount = Math.max(1, Math.ceil(filtered.length / vm.currencyPageSize));
        if (!keepPage || vm.currencyPage > vm.currencyPageCount) vm.currencyPage = 1;
        var start = (vm.currencyPage - 1) * vm.currencyPageSize;
        vm.visibleCurrencies = filtered.slice(start, start + vm.currencyPageSize);
      };
      vm.updateVendorView = function (keepPage) {
        var query = (vm.vendorSearch || "").toLowerCase();
        var filtered = (vm.vendors || []).filter(function (vendor) {
          return !query || [vendor.name, vendor.isActive ? "active" : "inactive"].join(" ").toLowerCase().indexOf(query) >= 0;
        });
        vm.vendorFilteredCount = filtered.length;
        vm.vendorPageCount = Math.max(1, Math.ceil(filtered.length / vm.vendorPageSize));
        if (!keepPage || vm.vendorPage > vm.vendorPageCount) vm.vendorPage = 1;
        var start = (vm.vendorPage - 1) * vm.vendorPageSize;
        vm.visibleVendors = filtered.slice(start, start + vm.vendorPageSize);
      };
      vm.updateGlView = function (keepPage) {
        var query = (vm.glSearch || "").toLowerCase();
        var filtered = (vm.glFunds || []).filter(function (gl) {
          return !query || [gl.glNumber, gl.glName, gl.fundAmount, gl.availableBalance, gl.isActive ? "active" : "inactive"].join(" ").toLowerCase().indexOf(query) >= 0;
        });
        vm.glFilteredCount = filtered.length;
        vm.glPageCount = Math.max(1, Math.ceil(filtered.length / vm.glPageSize));
        if (!keepPage || vm.glPage > vm.glPageCount) vm.glPage = 1;
        var start = (vm.glPage - 1) * vm.glPageSize;
        vm.visibleGlFunds = filtered.slice(start, start + vm.glPageSize);
      };
      vm.updateRoleView = function (keepPage) {
        var query = (vm.roleSearch || "").toLowerCase();
        vm.roleSummary = { reviewer: 0, approver: 0, admin: 0 };
        (vm.roleUsers || []).forEach(function (user) {
          if (user.elevatedRole === "Reviewer") vm.roleSummary.reviewer++;
          if (user.elevatedRole === "Approver") vm.roleSummary.approver++;
          if (user.elevatedRole === "Admin") vm.roleSummary.admin++;
        });
        var filtered = (vm.roleUsers || []).filter(function (user) {
          var queryMatch = !query || [user.displayName, user.email, user.roleList, user.isActive ? "active" : "inactive", user.portalAccess ? "portal enabled" : "portal disabled"].join(" ").toLowerCase().indexOf(query) >= 0;
          var roleMatch = !vm.roleFilter || user.elevatedRole === vm.roleFilter || (vm.roleFilter === "Requestor" && !user.elevatedRole);
          var statusMatch = !vm.roleStatusFilter || (vm.roleStatusFilter === "active" && user.isActive) || (vm.roleStatusFilter === "inactive" && !user.isActive);
          return queryMatch && roleMatch && statusMatch;
        });
        var sortKey = vm.roleSort.key;
        filtered.sort(function (left, right) {
          var leftValue = sortKey === "roles" ? left.roleList : left[sortKey];
          var rightValue = sortKey === "roles" ? right.roleList : right[sortKey];
          if (typeof leftValue === "boolean") return (leftValue === rightValue ? 0 : leftValue ? -1 : 1) * (vm.roleSort.desc ? -1 : 1);
          return String(leftValue || "").localeCompare(String(rightValue || ""), undefined, { sensitivity: "base" }) * (vm.roleSort.desc ? -1 : 1);
        });
        vm.roleFilteredCount = filtered.length;
        vm.rolePageCount = Math.max(1, Math.ceil(filtered.length / vm.rolePageSize));
        if (!keepPage || vm.rolePage > vm.rolePageCount) vm.rolePage = 1;
        var start = (vm.rolePage - 1) * vm.rolePageSize;
        vm.visibleRoleUsers = filtered.slice(start, start + vm.rolePageSize);
        redraw();
      };
      vm.sortRoleUsers = function (key) {
        if (vm.roleSort.key === key) vm.roleSort.desc = !vm.roleSort.desc;
        else vm.roleSort = { key: key, desc: false };
        vm.updateRoleView(true);
      };
      function prepareProjects() {
        if (vm.demo) vm.budgetUsage = [];
        vm.projects.forEach(function (project) {
          normalizeProjectSizing(project);
          if (typeof project.petsLoaded === "undefined") project.petsLoaded = angular.isArray(project.pets);
          project.pets = project.pets || [];
          project.budgetLines = project.budgetLines || [];
          project.petCount = project.petsLoaded ? project.pets.length : Number(project.petCount) || 0;
          project.approvedPetCount = project.petsLoaded ? project.pets.filter(function (pet) { return pet.status === "Approved"; }).length : Number(project.approvedPetCount) || 0;
          project.pendingReviewPetCount = project.petsLoaded ? project.pets.filter(function (pet) { return pet.status === "Pending Review"; }).length : Number(project.pendingReviewPetCount) || 0;
          project.pendingApprovalPetCount = project.petsLoaded ? project.pets.filter(function (pet) { return pet.status === "Pending Approval"; }).length : Number(project.pendingApprovalPetCount) || 0;
          project.rejectedPetCount = project.petsLoaded ? project.pets.filter(function (pet) { return pet.status === "Rejected"; }).length : Number(project.rejectedPetCount) || 0;
          project.sentBackPetCount = project.petsLoaded ? project.pets.filter(function (pet) { return pet.status === "Sent Back"; }).length : Number(project.sentBackPetCount) || 0;
          project.spendRequestCount = Number(project.spendRequestCount) || 0;
          project.budgetLineCount = Number(project.budgetLineCount) || 0;
          project.invoiceCount = Number(project.invoiceCount) || 0;
          if (!project.petsLoaded) return;
          project.spendRequestCount = 0;
          project.budgetLineCount = 0;
          project.invoiceCount = 0;
          project.budgetLines = [];
          project.pets.forEach(function (pet) {
            pet.spendItems = pet.spendItems || [];
            pet.budgetLines = pet.budgetLines || [];
            if (pet.spendItems.length) pet.requestedAmount = vm.petFinalAed(pet);
            project.spendRequestCount += pet.spendItems.length;
            project.budgetLineCount += pet.budgetLines.length;
            pet.budgetLines.forEach(function (line) { line.invoices = line.invoices || []; line.petCode = pet.code; project.budgetLines.push(line); project.invoiceCount += line.invoices.length; });
            if (vm.demo && pet.status === "Approved") vm.budgetUsage.push({ budgetType: project.budgetType, budgetSource: project.budgetSource, projectId: project.projectId, projectName: project.projectName, petCode: pet.code, petStatus: pet.status, amount: pet.requestedAmount });
          });
        });
      }
      vm.petForBudgetLine = function (project, line) {
        return ((project && project.pets) || []).filter(function (pet) { return pet.petId === line.petId; })[0];
      };
      function projectPetById(project, petId) {
        var id = Number(petId);
        return ((project && project.pets) || []).filter(function (pet) { return Number(pet.petId) === id; })[0];
      }
      vm.canExpandProject = function (project) {
        return !!project && ((project.petsLoaded && project.pets && project.pets.length) || Number(project.petCount) > 0 || Number(project.spendRequestCount) > 0 || Number(project.budgetLineCount) > 0 || Number(project.invoiceCount) > 0);
      };
      vm.toggleProject = function (project) {
        if (project.expanded) { project.expanded = false; redraw(); return; }
        if (project.petsLoaded || vm.demo) { project.expanded = true; redraw(); return; }
        loadProjectPets(project, true);
      };
      function loadProjectPets(project, expandRegardless, keepExpandedState) {
        project.loading = true;
        return $http.get("api/portfolio/projects/" + project.projectId).then(function (response) {
          var data = response.data;
          if (data.project) angular.extend(project, normalizeProjectSizing(data.project));
          project.pets = data.pets || [];
          var budgetLineAttachmentTypes = budgetLineDocumentEntityTypes();
          project.pets.forEach(function (pet) {
            pet.spendItems = (data.spendItems || []).filter(function (item) { return item.petId === pet.petId; }).map(normalizeSpendItem);
            pet.budgetLines = (data.budgetLines || []).filter(function (line) { return line.petId === pet.petId; });
            pet.budgetLines.forEach(function (line) {
              line.invoices = (data.invoices || []).filter(function (invoice) { return invoice.budgetLineId === line.budgetLineId; });
              line.attachments = (data.attachments || []).filter(function (attachment) { return Number(attachment.entityId) === Number(line.budgetLineId) && budgetLineAttachmentTypes.indexOf(String(attachment.entityType || "").toLowerCase()) >= 0; });
              line.invoices.forEach(function (invoice) { invoice.attachments = (data.attachments || []).filter(function (attachment) { return Number(attachment.entityId) === Number(invoice.invoiceId) && String(attachment.entityType || "").toLowerCase() === "invoicedocument"; }); });
            });
          });
          project.petsLoaded = true;
          project.loading = false;
          project.expanded = keepExpandedState ? !!project.expanded : expandRegardless || project.pets.length > 0;
          prepareProjects();
          vm.updateView(true);
          redraw();
        }, function () { project.loading = false; noticeError("Unable to load project details."); });
      }
      vm.openProject = function (project) {
        vm.modal = {
          type: "project",
          kicker: "PROJECT REGISTRATION",
          title: project ? "Edit project" : "Register a new project",
          submit: project ? "Save changes" : "Register project",
        };
        vm.form = angular.copy(
          project || {
            isJira: true,
            projectType: "Project",
            projectSize: "",
            budgetType: "",
            budgetSourceId: null,
            requiresPet: true,
          },
        );
        vm.form.isEdit = !!project;
        normalizeProjectSizing(vm.form);
        vm.form.projectSizingScores = parseProjectSizingScores(vm.form.projectSizingScores);
        vm.form.isJira = project ? !!project.jiraKey : true;
        validateProjectRegistration(false);
        redraw();
      };
      function normalizedRegistrationValue(value) {
        return String(value || "").trim().toLowerCase();
      }
      function existingProjectRegistration() {
        if (!vm.form) return null;
        var currentProjectId = vm.form.projectId;
        var jiraKey = normalizedRegistrationValue(vm.form.isJira ? vm.form.jiraKey : "");
        var projectName = normalizedRegistrationValue(vm.form.projectName);
        if (!jiraKey && !projectName) return null;
        return (vm.projects || []).filter(function (project) {
          if (!project) return false;
          if (currentProjectId && String(project.projectId) === String(currentProjectId)) return false;
          var existingJiraKey = normalizedRegistrationValue(project.jiraKey);
          var existingProjectName = normalizedRegistrationValue(project.projectName);
          return (jiraKey && existingJiraKey === jiraKey) || (projectName && existingProjectName === projectName);
        })[0] || null;
      }
      function validateProjectRegistration(showToast) {
        if (!vm.form) return true;
        vm.form.registrationError = existingProjectRegistration() ? "Project Already Registered!" : "";
        if (vm.form.registrationError && showToast) noticeError(vm.form.registrationError);
        return !vm.form.registrationError;
      }
      vm.validateProjectRegistration = validateProjectRegistration;
      vm.pickJira = function () {
        if (vm.form && vm.form.isEdit) return;
        var jira = vm.jira.filter(function (j) {
          return j.jiraKey === vm.form.jiraKey;
        })[0];
        if (!jira) { validateProjectRegistration(true); return; }
        vm.form.projectName = jira.summary;
        vm.form.projectType = jira.projectType;
        vm.form.accountableExecLead = jira.accountableExecLead;
        vm.form.accountableExec = jira.accountableExec;
        vm.form.smeLead = jira.smeLead;
        vm.form.projectSizingScores = {};
        vm.form.projectSize = "";
        vm.form.budgetType = "";
        vm.form.budgetSourceId = null;
        vm.form.projectManager = jira.assignedProjectManager;
        validateProjectRegistration(true);
      };
      vm.openJira = function (project) {
        var jira =
          vm.jira.filter(function (j) {
            return j.jiraKey === project.jiraKey;
          })[0] || project;
        normalizeProjectSizing(project);
        vm.form = angular.extend({}, project, jira, {
          projectName: jira.summary || project.projectName,
          projectSize: project.projectSize || jira.projectSize || jira.size || "",
          projectSizingScores: parseProjectSizingScores(project.projectSizingScores || jira.projectSizingScores || jira.ProjectSizingScores),
        });
        vm.modal = {
          type: "jira",
          kicker: "SYNCHRONIZED JIRA DETAIL",
          title: project.jiraKey || project.projectCode,
        };
        redraw();
      };
      vm.openBudgetUsageProject = function (row) {
        var project = (vm.projects || []).filter(function (item) { return item.projectId === row.projectId || item.projectCode === row.projectCode || item.projectName === row.projectName; })[0];
        vm.openJira(project || row);
      };
      function budgetSourceId(value) {
        return value && (value.budgetSourceId || value.BudgetSourceId);
      }
      function budgetUsageRowsForSource(budget) {
        var id = String(budgetSourceId(budget) || "");
        if (!id) return [];
        var projectRows = (vm.budgetUsage || []).filter(function (row) { return String(budgetSourceId(row) || "") === id; });
        var nonProjectRows = (vm.nonProjectBudgetUsage || []).filter(function (row) { return String(budgetSourceId(row) || "") === id; }).map(function (row) {
          return {
            isNonProject: true,
            budgetType: row.budgetType,
            projectDisplayId: "Non Project",
            projectName: [row.initiative, row.lineItem, row.vendor].filter(Boolean).join(" · "),
            petCode: row.memoCamId || row.invoiceNumber || "",
            petStatus: row.invoiceStatus || "Recorded",
            petAmount: row.amountApprovedAed
          };
        });
        return projectRows.concat(nonProjectRows);
      }
      function refreshSelectedBudgetUsageRows() {
        vm.selectedBudgetUsageRows = vm.selectedBudgetUsageSource ? budgetUsageRowsForSource(vm.selectedBudgetUsageSource) : [];
      }
      vm.openBudgetSourceUsage = function (budget) {
        vm.selectedBudgetUsageSource = budget;
        refreshSelectedBudgetUsageRows();
        vm.modal = {
          type: "budgetUtilization",
          kicker: "CAPEX/OPEX UTILIZATION",
          title: "Utilization for " + budget.externalId,
        };
        redraw();
      };
      vm.closeBudgetSourceUsage = function () {
        vm.selectedBudgetUsageSource = null;
        vm.selectedBudgetUsageRows = [];
      };
      vm.isBudgetSourceUsageOpen = function (budget) {
        return !!vm.selectedBudgetUsageSource && String(budgetSourceId(vm.selectedBudgetUsageSource) || "") === String(budgetSourceId(budget) || "");
      };
      vm.openReportProjectDetails = function (project) {
        if (!project) return;
        function showReportDetails() {
          var metrics = emptyReportMetrics();
          var rows = (vm.budgetUsage || []).filter(function (row) { return String(row.projectId) === String(project.projectId); });
          addProjectReportMetrics(metrics, project);
          vm.reportDetailProject = project;
          vm.reportDetailBudgetUsage = rows;
          vm.reportDetailSummary = buildReportSummary(project, metrics, rows);
          vm.modal = { type: "reportDetail", kicker: "MANAGEMENT REPORT", title: vm.projectDisplayId(project) + " · " + project.projectName };
          redraw();
        }
        if (!vm.demo && !project.petsLoaded) return refreshProjectPets(project.projectId, true, true).then(showReportDetails);
        showReportDetails();
      };
      vm.openPet = function (project, pet) {
        if (!vm.demo && project) {
          return refreshProjectPets(project.projectId, false, true).then(function () {
            var refreshedPet = pet && projectPetById(project, pet.petId || pet.PetId);
            openPetModal(project, refreshedPet || pet);
          });
        }
        openPetModal(project, pet);
      };
      function openPetModal(project, pet) {
        vm.selectedProject = project;
        vm.selectedPet = pet;
        if (pet && !sameStatus(pet.status || pet.Status, "Pending Review") && !sameStatus(pet.status || pet.Status, "Sent Back")) {
          noticeError("PET requests can be edited only while Pending Review or Sent Back.");
          return;
        }
        vm.uploadFile = null;
        vm.petLineUploadFile = null;
        vm.uploadPreview = [];
        vm.form = angular.copy(pet || {
            projectId: project.projectId,
          code: generatedPetReference(),
            currency: "AED",
            requestedAmount: 0,
            reviewRequired: !project.skipReview,
          });
        if (pet) {
          vm.form.petId = vm.form.petId || pet.petId || pet.PetId;
          vm.form.projectId = vm.form.projectId || project.projectId;
          vm.form.code = vm.form.code || pet.code || pet.Code;
          vm.form.currency = vm.form.currency || pet.currency || pet.Currency || "AED";
          vm.form.requestedAmount = parseNumericInput(vm.form.requestedAmount || pet.requestedAmount || pet.RequestedAmount);
          vm.form.status = vm.form.status || pet.status || pet.Status;
          if (vm.form.status === "Sent Back" && angular.isUndefined(vm.form.reviewRequired)) vm.form.reviewRequired = angular.isDefined(vm.form.ReviewRequired) ? !!vm.form.ReviewRequired : !project.skipReview;
          if (vm.form.status === "Sent Back") vm.form.comments = "";
        }
        vm.form.budgetType = vm.form.budgetType || project.budgetType || "";
        vm.form.budgetSourceId = vm.form.budgetSourceId || project.budgetSourceId || null;
        vm.uploadPreview = ((pet && pet.spendItems) || []).map(function (item) { return preparePetUploadRow(angular.extend({ petReference: vm.form.code, projectId: vm.projectDisplayId(project), finalAed: spendItemFinalAed(item) }, item)); });
        vm.recalculateUploadPreview();
        vm.modal = {
          type: "pet",
          kicker: "PET REQUEST",
          title: pet ? "Edit " + vm.form.code : "Create PET for " + vm.projectDisplayId(project),
          submit: pet && vm.form.status === "Sent Back" ? "Resubmit for approval" : pet ? "Save PET" : "Submit for review",
        };
        redraw();
      }
      vm.petVendorOnly = function () { return false; };
      vm.openSpend = function (pet) {
        vm.selectedPet = pet;
        vm.selectedProject = vm.projects.filter(function (project) { return project.pets.indexOf(pet) >= 0; })[0];
        vm.selectedPet.spendItems = vm.selectedPet.spendItems || [];
        vm.spendEditable = vm.can("request") && (pet.status === "Pending Review" || pet.status === "Sent Back");
        vm.spendFormVisible = false;
        vm.form = { petId: pet.petId, serialNo: "", lineDate: null, lineId: "", department: "", head: petProjectExpenseHead(vm.selectedProject), units: 1, currency: "AED", foreignAmount: 0, exchangeRate: 1, aedAmount: 0, contingencyPercent: 0 };
        vm.modal = { type: "spend", kicker: "PET COST DETAIL", title: "PET line items · " + pet.code, submit: "Save PET line item" };
        redraw();
      };
      vm.addSpend = function () {
        vm.form = { petId: vm.selectedPet.petId, serialNo: "", lineDate: null, lineId: "", department: "", head: petProjectExpenseHead(vm.selectedProject), units: 1, currency: "AED", foreignAmount: 0, exchangeRate: 1, aedAmount: 0, contingencyPercent: 0 };
        assignUniqueLineId(vm.form);
        vm.spendFormVisible = true;
        redraw();
      };
      vm.editSpend = function (item) {
        vm.form = angular.copy(item);
        if (vm.form.lineDate && !angular.isDate(vm.form.lineDate)) vm.form.lineDate = new Date(vm.form.lineDate);
        vm.form.head = petProjectExpenseHead(vm.selectedProject) || vm.form.head;
        vm.form.exchangeRate = parseNumericInput(vm.form.exchangeRate) || (parseNumericInput(vm.form.foreignAmount) ? parseNumericInput(vm.form.aedAmount) / parseNumericInput(vm.form.foreignAmount) : 1);
        vm.spendFormVisible = true;
        redraw();
      };
      vm.openDecision = function (pet, stage) {
        vm.bulkDecisionItems = [];
        vm.decisionPetRows = [];
        vm.decisionSelection = {};
        vm.decisionLinePet = null;
        var project = vm.projects.filter(function (p) {
          return p.pets.indexOf(pet) >= 0;
        })[0];
        if (project && !vm.demo) {
          project.petsLoaded = false;
          loadProjectPets(project, false, true).then(function () {
            openDecisionModal(projectPetById(project, pet.petId) || pet, stage, project);
          });
          return;
        }
        openDecisionModal(pet, stage, project);
      };
      vm.openBulkDecision = function (stage) {
        var items = vm.selectedApprovalItems(stage);
        if (!items.length) { noticeError("Select at least one PET to " + (stage === "approve" ? "approve" : "review") + "."); return; }
        vm.bulkDecisionItems = items;
        vm.decisionLinePet = null;
        vm.selectedProject = items[0].project;
        vm.selectedPet = items[0].pet;
        vm.form = {
          decision: "Approve",
          comments: "",
          budgetSourceId: vm.selectedProject && vm.selectedProject.budgetSourceId,
          requestedAmount: items.reduce(function (total, item) { return total + (Number(item.pet.requestedAmount) || 0); }, 0),
          code: items.length + " PETs selected",
        };
        vm.modal = {
          type: "decision",
          stage: stage,
          bulk: true,
          kicker: stage === "review" ? "REVIEWER DECISION" : "APPROVER DECISION",
          title: stage === "review" ? "Review selected PETs" : "Approve selected PETs",
          submit: "Record decisions",
        };
        redraw();
      };
      function openDecisionModal(pet, stage, project) {
        vm.bulkDecisionItems = [];
        vm.decisionLinePet = null;
        vm.selectedProject = project;
        vm.selectedPet = pet;
        vm.selectedPet.spendItems = vm.selectedPet.spendItems || [];
        vm.form = angular.copy(pet);
        vm.form.decision = "Approve";
        vm.form.comments = "";
        vm.form.budgetSourceId = vm.selectedProject && vm.selectedProject.budgetSourceId;
        vm.modal = {
          type: "decision",
          stage: stage,
          bulk: true,
          kicker:
            stage === "review" ? "REVIEWER DECISION" : "APPROVER DECISION",
          title: stage === "review" ? "Review PET" : "Approve PET",
          submit: "Record decision",
        };
        buildDecisionPetRows(project, pet, stage);
        redraw();
      }
      vm.viewDecisionPetLines = function (item) {
        vm.decisionLinePet = item && item.pet;
        redraw();
      };
      vm.closeDecisionPetLines = function () {
        vm.decisionLinePet = null;
        redraw();
      };
      vm.openHistory = function (project, pet) {
        vm.selectedProject = project;
        vm.selectedPet = pet;
        vm.history = [];
        vm.modal = { type: "history", kicker: "WORKFLOW HISTORY", title: "History · " + pet.code };
        redraw();
        if (vm.demo) return;
        $http.get("api/portfolio/pets/" + pet.petId + "/history").then(function (response) {
          vm.history = response.data || [];
          redraw();
        }, function () { noticeError("Unable to load workflow history."); });
      };
      vm.openBudgetLine = function (pet, line) {
        vm.selectedPet = pet;
        vm.selectedProject = vm.projects.filter(function (p) { return p.pets.indexOf(pet) >= 0; })[0];
        vm.budgetLineDocumentFiles = {};
        vm.form = angular.copy(
          line || {
            petId: pet.petId,
            currency: "AED",
            camStatus: "Raised to Vendor",
          },
        );
        vm.form.petId = vm.form.petId || pet.petId;
        vm.selectedPet = projectPetById(vm.selectedProject, vm.form.petId) || pet;
        vm.form.petReference = vm.form.petReference || vm.selectedPet.code;
        vm.form.sourceSpendItemIds = normalizeBudgetLineSourceIds(vm.form.sourceSpendItemIds || vm.form.SourceSpendItemIds || vm.form.spendItemIds || vm.form.SpendItemIds || vm.form.sourceSpendItemId || vm.form.SourceSpendItemId || vm.form.spendItemId || vm.form.SpendItemId);
        if (!line) vm.form.vendor = "";
        applyBudgetLinePetValues();
        if (vm.form.camCreatedDate) vm.form.camCreatedDate = new Date(vm.form.camCreatedDate);
        if (vm.form.camApprovedDate) vm.form.camApprovedDate = new Date(vm.form.camApprovedDate);
        if (vm.form.lpoIssueDate) vm.form.lpoIssueDate = new Date(vm.form.lpoIssueDate);
        if (!line && !vm.form.glNumber) vm.form.glNumber = "";
        vm.modal = {
          type: "budgetLine",
          kicker: "APPROVED PET",
          title: line ? "Edit budget line" : "Add budget line",
          submit: "Save budget line",
        };
        redraw();
      };
      vm.onBudgetLinePetChange = function (skipAutoFill) {
        var pet = projectPetById(vm.selectedProject, vm.form && vm.form.petId);
        if (!pet) { vm.selectedPet = null; vm.budgetLineSpendDetails = []; vm.budgetLineVendorOptions = []; vm.budgetLineSelectedSpendItems = {}; if (vm.form) vm.form.petReference = null; return; }
        var petChanged = !vm.selectedPet || Number(vm.selectedPet.petId) !== Number(pet.petId);
        vm.selectedPet = pet;
        vm.form.petReference = pet.code;
        if (petChanged && !vm.form.budgetLineId) { vm.form.vendor = ""; vm.form.sourceSpendItemIds = []; vm.form.cost = null; }
        if (vm.form.budgetLineId) { refreshBudgetLineSpendDetails(); return; }
        if (skipAutoFill) { refreshBudgetLineSpendDetails(); return; }
        applyBudgetLinePetValues();
      };
      vm.openProjectBudgetLine = function (project) {
        var pet = vm.petForNewBudgetLine(project);
        if (!pet && project && !project.petsLoaded && Number(project.approvedPetCount) > 0) {
          loadProjectPets(project, true).then(function () {
            var loadedPet = vm.petForNewBudgetLine(project);
            if (loadedPet) vm.openBudgetLine(loadedPet);
          });
          return;
        }
        if (!pet) return;
        vm.openBudgetLine(pet);
      };
      vm.openInvoice = function (line, invoice) {
        vm.selectedLine = line;
        vm.invoiceDocumentFile = null;
        vm.selectedProject = vm.projects.filter(function (p) {
          return p.pets.some(function (pet) { return pet.budgetLines && pet.budgetLines.indexOf(line) >= 0; });
        })[0];
        vm.form = angular.copy(
          invoice || {
            budgetLineId: line.budgetLineId,
            vendorName: line.vendor,
            glNumber: line.glNumber,
            invoiceStatus: "Raised",
          },
        );
        if (vm.form.paymentDate)
          vm.form.paymentDate = new Date(vm.form.paymentDate);
        vm.modal = {
          type: "invoice",
          kicker: "INVOICE REGISTER",
          title: invoice ? "Update invoice" : "Add invoice",
          submit: "Save invoice",
        };
        redraw();
      };
      vm.openBudgetLineDocuments = function (line) {
        vm.selectedLine = line;
        vm.selectedProject = vm.projects.filter(function (p) {
          return p.pets.some(function (pet) { return pet.budgetLines && pet.budgetLines.indexOf(line) >= 0; });
        })[0];
        vm.modal = { type: "budgetLineDocuments", kicker: "BUDGET LINE DOCUMENTS", title: "Documents · " + (line.petReference || line.petCode || line.camId || "Budget Line") };
        redraw();
      };
      vm.openInvoiceView = function (line) {
        vm.selectedLine = line;
        vm.selectedProject = vm.projects.filter(function (p) {
          return p.pets.some(function (pet) { return pet.budgetLines && pet.budgetLines.indexOf(line) >= 0; });
        })[0];
        function showInvoices(sourceLine) {
          vm.selectedLine = sourceLine || line;
          vm.invoices = (vm.selectedLine && vm.selectedLine.invoices) || [];
          vm.modal = { type: "invoiceView", kicker: "INVOICE VIEW", title: "Invoices · " + (vm.selectedLine.petReference || vm.selectedLine.petCode || vm.selectedLine.camId || "Budget Line") };
          redraw();
        }
        if (vm.selectedProject && !vm.demo) {
          refreshProjectPets(vm.selectedProject.projectId, true).then(function () {
            var refreshedLine = null;
            (vm.selectedProject.budgetLines || []).forEach(function (candidate) {
              if (Number(candidate.budgetLineId) === Number(line.budgetLineId)) refreshedLine = candidate;
            });
            showInvoices(refreshedLine);
          });
          return;
        }
        showInvoices(line);
      };
      vm.openBudget = function (budget) {
        vm.selectedBudget = budget;
        vm.form = angular.copy(budget);
        vm.modal = {
          type: "budget",
          kicker: "MASTER CONTROL",
          title: "Edit " + budget.externalId,
          submit: "Update budget",
        };
        redraw();
      };
      vm.openCurrency = function (currency) {
        vm.selectedCurrency = currency || null;
        vm.form = angular.copy(currency || { code: "", name: "", rateToLocal: 1, isActive: true });
        vm.modal = {
          type: "currency",
          kicker: "MASTER CONTROL",
          title: currency ? "Edit " + currency.code : "Add currency",
          submit: currency ? "Update currency" : "Add currency",
        };
        redraw();
      };
      vm.openVendor = function (vendor) {
        vm.selectedVendor = vendor || null;
        vm.form = angular.copy(vendor || { name: "", isActive: true });
        vm.modal = {
          type: "vendor",
          kicker: "MASTER CONTROL",
          title: vendor ? "Edit " + vendor.name : "Add vendor",
          submit: vendor ? "Update vendor" : "Add vendor",
        };
        redraw();
      };
      vm.openGlFund = function (gl) {
        vm.selectedGlFundItem = gl || null;
        vm.form = angular.copy(gl || { glNumber: "", glName: "", fundAmount: 0, isActive: true });
        vm.modal = {
          type: "gl",
          kicker: "MASTER CONTROL",
          title: gl ? "Edit " + gl.glNumber : "Add GL funding",
          submit: gl ? "Update GL" : "Add GL",
        };
        redraw();
      };
      vm.openGlUtilization = function (gl) {
        if (!gl || !gl.glNumber) return;
        vm.selectedGlUtilization = gl;
        vm.glUtilizationRows = [];
        vm.modal = {
          type: "glUtilization",
          kicker: "GL UTILIZATION",
          title: "Utilization for " + gl.glNumber,
        };
        redraw();
        if (vm.demo) {
          (vm.projects || []).forEach(function (project) {
            ((project && project.pets) || []).forEach(function (pet) {
              ((pet && pet.budgetLines) || []).forEach(function (line) {
                if (normalizedGlNumber(line.glNumber) !== normalizedGlNumber(gl.glNumber)) return;
                vm.glUtilizationRows.push({ demandId: vm.projectDisplayId(project), projectCode: project.projectCode, projectName: project.projectName, projectType: project.projectType, budgetType: project.budgetType, budgetSource: project.budgetSource, petCode: pet.code, petStatus: pet.status, petAmount: pet.requestedAmount, petCurrency: pet.currency, budgetLineId: line.budgetLineId, petReference: line.petReference, vendor: line.vendor, justification: line.justification, budgetLineCost: line.cost, glAmount: line.cost, budgetLineCurrency: line.currency, camId: line.camId, camStatus: line.camStatus, lpoRequest: line.lpoRequest, lpoStatus: line.lpoStatus });
              });
            });
          });
          redraw();
          return;
        }
        $http.get("api/portfolio/gl-funds/utilization", { params: { glNumber: gl.glNumber } }).then(function (response) {
          vm.glUtilizationRows = response.data || [];
          redraw();
        }, function (response) {
          noticeError(responseMessage(response, "Unable to load GL utilization details."));
        });
      };
      vm.toggleGlFund = function (gl) {
        if (!gl) return;
        var previous = !!gl.isActive;
        vm.selectedGlFundItem = gl;
        vm.form = angular.copy(gl);
        vm.form.isActive = !previous;
        if (vm.demo) {
          angular.extend(gl, vm.form);
          vm.updateGlView(true);
          notice(gl.isActive ? "GL activated" : "GL deactivated");
          redraw();
          return;
        }
        $http.post("api/portfolio/gl-funds", vm.form).then(function (response) {
          angular.extend(gl, response.data || vm.form);
          vm.updateGlView(true);
          notice(gl.isActive ? "GL activated" : "GL deactivated");
          redraw();
        }, function (response) {
          gl.isActive = previous;
          noticeError(responseMessage(response, "Unable to update GL status."));
        });
      };
      vm.openUpload = function (kind, item) {
        var templates = {
          pet: "templates/pet-upload-template.csv",
          budget: "templates/budget-upload-template.csv",
          invoice: "templates/invoice-upload-template.csv",
          sources: "templates/sources-upload-template.csv",
          nonProject: "templates/non-project-opex-upload-template.csv",
        };
        vm.modal = {
          type: "upload",
          kind: kind,
          kicker: kind === "nonProject" ? "NON PROJECT" : "BULK IMPORT",
          title:
            kind === "attachment"
              ? "Attach supporting files"
              : kind === "nonProject"
                ? "Non Project"
              : kind === "sources"
                ? "Synchronize CAPEX / OPEX"
                : "Upload " + kind + " records",
          submit: kind === "pet" ? "Save PET rows" : kind === "nonProject" ? "Import OPEX rows" : "Upload files",
          template: templates[kind],
          help:
            kind === "attachment"
              ? "PDF, spreadsheet and image files up to 50 MB."
              : kind === "sources"
                ? "Columns: Type (Capex/Opex), ID, Description, Budget, Utilization, Available Budget, Locked Amt, Budget after Locked Amt, Claim Amt, Net Balance. Existing sources are updated by Type + ID."
                : kind === "nonProject"
                  ? "Add a single Non Project OPEX record manually by selecting an OPEX source from CAPEX / OPEX, or import multiple rows from the template. Supporting documents are optional."
              : kind === "pet"
                ? "Upload the Excel or CSV, review the rows below, edit any fields, or add PET rows manually before saving."
                : "Use the supplied columns in CSV, XLSX, or XLSM format. Invalid rows are rejected with a row-level reason.",
        };
        vm.uploadFile = null;
        vm.uploadFiles = [];
        vm.uploadPreview = [];
        vm.nonProjectSupportingFile = null;
        vm.nonProjectEditId = null;
        vm.nonProjectEntryMode = kind === "nonProject" ? "manual" : "upload";
        vm.form = kind === "nonProject" ? {
          budgetType: "OPEX", amountApprovedAed: null,
          initiative: "", platform: "", lineItem: "", epmId: "", opexReference: "", glNumber: "", budgetApprovedAed: null,
          memoCamId: "", vendor: "", dateRaised: null, lpoSoNumber: "", poDate: null, amsNumber: "", camStatus: "", description: "",
          invoiceMemoNumber: "", invoiceNumber: "", invoiceAmountAed: null, invoiceDate: null, invoiceEntryProcessDate: null,
          invoiceStatus: "", invoiceDescription: "", folder: "", handledBy: "", column1: ""
        } : { item: item };
        if (kind === "pet") {
          vm.form.budgetType = (item && item.budgetType) || "";
          vm.form.budgetSourceId = (item && item.budgetSourceId) || null;
          ensurePetReferenceNo();
        }
        redraw();
      };
      vm.download = function (kind) {
        window.location.href = "templates/" + kind + "-upload-template.csv";
      };
      vm.canChangeNonProjectOpex = function (row) {
        return vm.can("request") && (vm.hasRole("Master") || createdByCurrentUser(row));
      };
      vm.editNonProjectOpex = function (row) {
        vm.openUpload("nonProject");
        vm.modal.title = "Edit Non Project";
        vm.nonProjectEditId = row.nonProjectOpexLineId;
        Object.keys(vm.form).forEach(function (key) {
          if (row[key] !== undefined) vm.form[key] = row[key];
        });
        ["dateRaised", "poDate", "invoiceDate", "invoiceEntryProcessDate"].forEach(function (key) {
          vm.form[key] = vm.form[key] ? new Date(vm.form[key]) : null;
        });
        redraw();
      };
      vm.deleteNonProjectOpex = function (row) {
        if (!window.confirm("Delete Non Project record \"" + (row.lineItem || row.nonProjectOpexLineId) + "\"? This cannot be undone.")) return;
        $http.post("api/portfolio/non-project-opex/" + row.nonProjectOpexLineId + "/delete").then(function () {
          notice("Non Project record deleted.");
          loadDashboard();
        }, function (response) { noticeError(responseMessage(response, "Unable to delete the Non Project record.")); });
      };
      vm.close = function () {
        vm.modal = null;
        vm.form = {};
        vm.uploadFile = null;
        vm.nonProjectSupportingFile = null;
        vm.nonProjectEditId = null;
        vm.uploadPreview = [];
        vm.bulkDecisionItems = [];
        vm.decisionPetRows = [];
        vm.decisionSelection = {};
        vm.budgetLineSpendDetails = [];
        vm.budgetLineSelectedSpendItems = {};
        vm.glUtilizationRows = [];
        vm.selectedGlUtilization = null;
        vm.selectedBudgetUsageSource = null;
        vm.selectedBudgetUsageRows = [];
        vm.budgetLineDocumentFiles = {};
        vm.invoiceDocumentFile = null;
        redraw();
      };
      function runBulkImport(kind, parentId, onDone) {
        if (!vm.uploadFile) { noticeError("Choose a CSV or Excel file first."); return; }
        var formData = new FormData();
        formData.append("file", vm.uploadFile);
        $http.post("api/portfolio/bulk/" + kind + "/" + parentId, formData, { transformRequest: angular.identity, headers: { "Content-Type": undefined } }).then(function (response) {
          notice((response.data.imported || 0) + " row(s) imported.");
          vm.uploadFile = null;
          vm.close();
          loadDashboard().then(function () { if (onDone) onDone(); });
        }, function (response) {
          noticeError(responseMessage(response, "Import failed."));
        });
      }
      function saveNonProjectOpexUpload() {
        if (vm.nonProjectEntryMode === "manual") {
          var payload = angular.extend({}, vm.form, { budgetType: "OPEX" });
          var badNumber = ["budgetApprovedAed", "amountApprovedAed", "invoiceAmountAed"].some(function (key) {
            var text = String(payload[key] == null ? "" : payload[key]).replace(/,/g, "").trim();
            payload[key] = text === "" ? null : Number(text);
            return text !== "" && !isFinite(payload[key]);
          });
          if (badNumber) { noticeError("Amounts must be valid numbers."); return; }
          if (!String(payload.initiative || "").trim() || !String(payload.lineItem || "").trim() || !String(payload.vendor || "").trim() || !(payload.amountApprovedAed > 0)) {
            noticeError("Initiative, Line Item, Vendor, and a positive Amount Apprd(AED) are required."); return;
          }
          if (!payload.opexReference) { noticeError("Select the OPEX source from CAPEX / OPEX."); return; }
          var isEdit = !!vm.nonProjectEditId;
          var url = isEdit ? "api/portfolio/non-project-opex/" + vm.nonProjectEditId : "api/portfolio/non-project-opex";
          $http.post(url, payload).then(function (response) {
            var batchId = response.data && response.data.batchId;
            var savedMessage = isEdit ? "Non Project record updated." : "Non Project record saved.";
            if (!vm.nonProjectSupportingFile) {
              notice(savedMessage);
              vm.close();
              loadDashboard();
              return;
            }
            uploadAttachment("NonProjectOpexBatch", batchId, vm.nonProjectSupportingFile).then(function () {
              notice(savedMessage + " Supporting document saved.");
              vm.close();
              loadDashboard();
            }, function (uploadResponse) {
              noticeError("Record saved, but supporting document upload failed. " + responseMessage(uploadResponse, "Retry the document upload."));
              loadDashboard();
            });
          }, function (response) { noticeError(responseMessage(response, "Unable to save the Non-Project OPEX record.")); });
          return;
        }
        if (!vm.uploadFile) { noticeError("Choose the Non-Project OPEX CSV or Excel file first."); return; }
        var formData = new FormData();
        formData.append("dataFile", vm.uploadFile);
        if (vm.nonProjectSupportingFile) formData.append("supportingFile", vm.nonProjectSupportingFile);
        $http.post("api/portfolio/non-project-opex/import", formData, { transformRequest: angular.identity, headers: { "Content-Type": undefined } }).then(function (response) {
          notice(((response.data && response.data.imported) || 0) + " non-project OPEX row(s) imported.");
          vm.close();
          loadDashboard();
        }, function (response) {
          noticeError(responseMessage(response, "Unable to import Non-Project OPEX rows."));
        });
      }
      function uploadAttachment(entityType, entityId, file) {
        if (!file || !entityId || vm.demo) return $q.when();
        if (!validateUploadFileSize(file)) return $q.reject({ data: { message: uploadFileSizeMessage(file) } });
        var formData = new FormData();
        formData.append("file", file);
        return $http.post("api/portfolio/attachments/" + entityType + "/" + entityId, formData, { transformRequest: angular.identity, headers: { "Content-Type": undefined } });
      }
      function validateUploadFiles(files) {
        for (var index = 0; index < files.length; index++) if (!validateUploadFileSize(files[index])) return false;
        return true;
      }
      function validateUploadFileSize(file) {
        if (!file || !file.size || file.size <= maxUploadBytes) return true;
        noticeError(uploadFileSizeMessage(file));
        return false;
      }
      function uploadFileSizeMessage(file) {
        return (file && file.name || "Selected file") + " is larger than 50 MB. Please upload a smaller file.";
      }
      function uploadAttachments(entityType, entityId, files) {
        var uploads = [];
        (files || []).forEach(function (file) {
          if (file) uploads.push(uploadAttachment(entityType, entityId, file));
        });
        return uploads.length ? $q.all(uploads) : $q.when();
      }
      function uploadBudgetLineDocuments(budgetLineId) {
        if (vm.demo) return $q.when();
        var documents = [];
        vm.budgetLineDocumentTypes.forEach(function (type) {
          var file = vm.budgetLineDocumentFiles && vm.budgetLineDocumentFiles[type.key];
          if (file) documents.push({ type: type, file: file });
        });
        if (!documents.length) return $q.when();
        if (!budgetLineId) return $q.reject({ data: { message: "Budget Line was saved but the saved Budget Line ID was not returned for document upload." } });
        var chain = $q.when();
        documents.forEach(function (document) {
          chain = chain.then(function () {
            return uploadAttachment(document.type.entityType, budgetLineId, document.file).then(null, function (response) {
              return $q.reject({ data: { message: document.type.label + " document upload failed. " + responseMessage(response, "The server returned a generic upload error. Apply Database/034_Attachment_Upload_Reliability.sql and rebuild/restart the web app.") } });
            });
          });
        });
        return chain;
      }
      function uploadInvoiceDocument(invoiceId) {
        if (!invoiceId || !vm.invoiceDocumentFile || vm.demo) return $q.when();
        return uploadAttachment("InvoiceDocument", invoiceId, vm.invoiceDocumentFile);
      }
      vm.downloadAttachment = function (attachment, viewInline) {
        if (!attachment || !attachment.attachmentId) return;
        var viewer = viewInline ? window.open("", "_blank") : null;
        var urlPath = "api/portfolio/attachments/" + attachment.attachmentId + (viewInline ? "?inline=true" : "");
        $http.get(urlPath, { responseType: "blob" }).then(function (response) {
          var type = response.headers("Content-Type") || attachment.contentType || "application/octet-stream";
          var blob = new Blob([response.data], { type: type });
          var url = window.URL.createObjectURL(blob);
          if (viewInline) {
            if (viewer) viewer.location.href = url;
            else window.open(url, "_blank");
          }
          else {
            var link = document.createElement("a");
            link.href = url;
            link.download = attachment.originalName || "attachment";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
          }
          setTimeout(function () { window.URL.revokeObjectURL(url); }, 60000);
        }, function (response) {
          if (viewer) viewer.close();
          noticeError(responseMessage(response, "Unable to download the document."));
        });
      };
      function savePreviewItems(petId) {
        if ((vm.uploadPreview || []).length && !petId) return $q.reject({ data: { message: "PET was saved, but the PET id was not returned." } });
        var chain = $q.when();
        (vm.uploadPreview || []).forEach(function (row) {
          chain = chain.then(function () {
            var payload = angular.extend({}, row, { petId: petId });
            applyPetProjectDefaults(payload);
            calculatePetUploadRow(payload, true);
            payload.units = parseNumericInput(payload.units);
            payload.unitPrice = parseNumericInput(payload.unitPrice);
            payload.foreignAmount = parseNumericInput(payload.foreignAmount);
            payload.exchangeRate = currencyRateToLocal(payload.currency, payload.exchangeRate);
            payload.aedAmount = parseNumericInput(payload.aedAmount);
            payload.contingencyPercent = parseNumericInput(payload.contingencyPercent);
            payload.yearlyRecurrence = blankNumericInput(payload.yearlyRecurrence) ? null : parseNumericInput(payload.yearlyRecurrence);
            return $http.post("api/portfolio/spend-items", payload);
          });
        });
        return chain;
      }
      function responseMessage(response, fallback) {
        if (!response || response.data == null) return fallback;
        if (response.status === 401) { vm.signOut(); return "Your session has expired or is not authenticated. Please sign in again before saving."; }
        if (response.status === 403) return "Your account does not have permission to save this item. Ask an admin to assign the required role.";
        if (typeof response.data === "string") return /<html|<!doctype/i.test(response.data) ? fallback : response.data;
        var message = response.data.message || response.data.Message;
        var detail = response.data.exceptionMessage || response.data.ExceptionMessage;
        if (message && !/^An error has occurred\.?$/i.test(message)) return message;
        return detail || fallback || message;
      }
      function authResponseMessage(response, fallback) {
        if (response && response.status === 401) return vm.auth && vm.auth.mode === "login" ? "Invalid email ID or password." : "Invalid email ID, security question, or security answer.";
        if (!response || response.data == null) return fallback;
        if (typeof response.data === "string") return /<html|<!doctype/i.test(response.data) ? fallback : response.data;
        return response.data.message || response.data.Message || fallback;
      }
      vm.saveModal = function () {
        var type = vm.modal.type;
        if (type === "user") { vm.saveManagedUser(); return; }
        if (type === "upload" && vm.modal.kind === "nonProject") { saveNonProjectOpexUpload(); return; }
        if (type === "project" && !validateProjectRegistration(true)) return;
        if (type === "project" && !vm.form.isEdit && !vm.projectSizingComplete()) { noticeError("Project sizing is required."); return; }
        if (type === "project" && !vm.demo) {
          // Registration is one-time (no projectId -> insert); every save after that is an
          // update against the same projectId, so a project can be edited any number of times.
          updateProjectSizeFromScores();
          var payload = {
            projectId: vm.form.projectId || null,
            isJira: !!vm.form.isJira,
            jiraKey: vm.form.isJira ? vm.form.jiraKey : null,
            projectName: vm.form.projectName,
            projectType: vm.form.projectType,
            accountableExecLead: vm.form.accountableExecLead,
            accountableExec: vm.form.accountableExec,
            smeLead: vm.form.smeLead,
            projectSize: vm.form.projectSize,
            projectSizingScores: projectSizingPayload(),
            projectManager: vm.form.projectManager,
            budgetType: vm.form.budgetType || null,
            budgetSourceId: vm.form.budgetType ? vm.form.budgetSourceId : null,
          };
          $http.post("api/portfolio/projects", payload).then(function (response) {
            notice(payload.projectId ? "Project updated" : "Project registered");
            var responseProject = response && response.data || {};
            var savedProject = normalizeProjectSizing(angular.extend({}, vm.form, responseProject, payload));
            if (savedProject) savedProject.projectId = savedProject.projectId || responseProject.projectId || responseProject.ProjectId || vm.form.projectId;
            if (payload.projectId) {
              var existing = vm.projects.filter(function (project) { return Number(project.projectId) === Number(payload.projectId); })[0];
              if (existing) angular.extend(existing, savedProject);
            } else if (savedProject) {
              vm.projects.unshift(savedProject);
            }
            vm.close();
            loadDashboard();
          }, function (response) {
            noticeError(responseMessage(response, "Unable to save the project."));
          });
          return;
        }
        if (type === "project") {
          var existing =
            vm.form.projectId &&
            vm.projects.filter(function (p) {
              return p.projectId === vm.form.projectId;
            })[0];
          var budget = vm.budgets.filter(function (b) {
            return String(b.budgetSourceId) === String(vm.form.budgetSourceId);
          })[0];
          if (existing) angular.extend(existing, vm.form);
          else {
            vm.form.projectId = vm.projects.length + 1;
            vm.form.projectCode =
              "PRJ-" + ("000000" + vm.form.projectId).slice(-6);
            vm.form.jiraKey = vm.form.isJira ? vm.form.jiraKey : null;
            vm.form.requestorEmail = vm.session.email;
            vm.form.requestorName = vm.session.displayName;
            vm.form.status = "Active";
            vm.form.createdUtc = new Date();
            vm.form.pets = [];
            vm.form.petsLoaded = true;
            vm.form.budgetSource = budget ? budget.externalId : "Not required";
            vm.form.availableBudget = budget ? budget.availableBudget : 0;
            vm.projects.unshift(vm.form);
            vm.metrics.projectsRegistered++;
          }
          prepareProjects();
          vm.updateView();
          notice("Project saved");
        }
        if (type === "pet" && !vm.demo) {
          if (vm.petVendorOnly()) {
            if (!validatePetLineVendors()) return;
            var vendorPayload = {
              petId: vm.form.petId,
              projectId: vm.form.projectId || vm.selectedProject.projectId,
              code: vm.form.code,
                requestedAmount: parseNumericInput(vm.form.requestedAmount),
              currency: vm.form.currency || "AED",
              vendorName: vm.form.vendorName,
              vendorNameOnly: true,
              budgetType: vm.form.budgetType || vm.selectedProject.budgetType,
              budgetSourceId: vm.form.budgetSourceId || vm.selectedProject.budgetSourceId,
              spendItems: petLineVendorPayloads(vm.form.petId),
            };
            $http.post("api/portfolio/pets", vendorPayload).then(function () {
              (vm.uploadPreview || []).forEach(function (row) {
                var item = (vm.selectedPet.spendItems || []).filter(function (candidate) { return Number(candidate.spendItemId) === Number(row.spendItemId); })[0];
                if (item) item.vendor = row.vendor;
              });
              notice("PET vendor name updated");
              vm.close();
            }, function (response) {
              noticeError(responseMessage(response, "Unable to update the PET vendor name."));
            });
            return;
          }
          if (vm.form.status === "Sent Back" && !String(vm.form.comments || "").trim()) { noticeError("Requester comments / amendment notes are required before resubmitting."); return; }
          if (!vm.selectedPet && (vm.uploadPreview || []).length) {
            if (!validatePetBudgetSelection()) return;
            var bulkPetProjectId = vm.selectedProject.projectId;
            saveProjectBudgetSelectionIfNeeded(vm.selectedProject).then(function () {
              savePetUploadRows(bulkPetProjectId, function () { refreshProjectPets(bulkPetProjectId, true); }, vm.form.reviewRequired);
            }, function (response) { if (!response || !response.handled) noticeError(responseMessage(response, "Unable to save the project budget selection.")); });
            return;
          }
          if (!vm.selectedPet && !(vm.uploadPreview || []).length) { noticeError("Upload Excel rows or add a PET row before saving."); return; }
          if ((vm.uploadPreview || []).length && !validatePetUploadRows()) return;
          if ((vm.uploadPreview || []).length) vm.form.requestedAmount = vm.petUploadTotal;
          if (!validatePetRequestAmount(vm.selectedProject, vm.selectedPet, vm.form.requestedAmount)) return;
          var supportingDocument = vm.uploadFile;
          var petPayload = {
            petId: vm.form.petId || null,
            projectId: vm.selectedProject.projectId,
            code: vm.form.code,
            requestedAmount: (vm.uploadPreview || []).length ? vm.petUploadTotal : parseNumericInput(vm.form.requestedAmount),
            currency: vm.form.currency,
            vendorName: vm.form.vendorName,
            comments: vm.form.comments,
            reviewRequired: vm.form.reviewRequired,
            budgetType: vm.form.budgetType || vm.selectedProject.budgetType,
            budgetSourceId: vm.form.budgetSourceId || vm.selectedProject.budgetSourceId,
          };
          if ((vm.uploadPreview || []).length) petPayload.spendItems = petLinePayloads(vm.form.petId || 0);
          if (!validatePetBudgetSelection()) return;
          $http.post("api/portfolio/pets", petPayload).then(function (response) {
            applyProjectBudgetSelection(vm.selectedProject);
            var savedPetId = petPayload.petId || response.data && (response.data.petId || response.data.PetId);
            uploadAttachment("PET", savedPetId, supportingDocument).then(function () {
              notice(vm.form.status === "Sent Back" ? "PET resubmitted for approval" : petPayload.petId ? "PET updated" : "PET submitted for review");
              vm.close();
              refreshProjectPets(petPayload.projectId, true);
              loadVendors(false);
              loadDashboard();
            }, function (attachmentResponse) {
              noticeError(responseMessage(attachmentResponse, "PET was saved, but the supporting document upload failed."));
            });
          }, function (response) {
            noticeError(responseMessage(response, "Unable to save the PET."));
          });
          return;
        }
        if (type === "pet") {
          if (vm.petVendorOnly()) {
            if (!validatePetLineVendors()) return;
            (vm.uploadPreview || []).forEach(function (row) {
              var item = (vm.selectedPet.spendItems || []).filter(function (candidate) { return Number(candidate.spendItemId) === Number(row.spendItemId); })[0];
              if (item) item.vendor = row.vendor;
            });
            notice("PET vendor name updated");
            vm.close();
            return;
          }
          if (vm.form.status === "Sent Back" && !String(vm.form.comments || "").trim()) { noticeError("Requester comments / amendment notes are required before resubmitting."); return; }
          if ((vm.uploadPreview || []).length && !validatePetUploadRows()) return;
          if ((vm.uploadPreview || []).length) vm.form.requestedAmount = vm.petUploadTotal;
          else vm.form.requestedAmount = parseNumericInput(vm.form.requestedAmount);
          if (!validatePetRequestAmount(vm.selectedProject, vm.selectedPet, vm.form.requestedAmount)) return;
          var wasSentBack = vm.selectedPet && vm.selectedPet.status === "Sent Back";
          var demoPetId = vm.form.petId || Date.now();
          vm.form.spendItems = (vm.uploadPreview || []).length ? petLinePayloads(demoPetId) : (vm.form.spendItems || []);
          if (vm.selectedPet) angular.extend(vm.selectedPet, vm.form);
          else {
            vm.form.petId = demoPetId;
            vm.form.status = vm.form.reviewRequired ? "Pending Review" : "Pending Approval";
            vm.form.createdUtc = new Date();
            vm.form.spendItems = vm.form.spendItems || [];
            vm.form.budgetLines = [];
            vm.selectedProject.pets.push(vm.form);
            vm.metrics.petsOnTrack++;
          }
          if (wasSentBack) vm.selectedPet.status = vm.form.reviewRequired ? "Pending Review" : "Pending Approval";
          vm.selectedProject.status = wasSentBack ? vm.selectedPet.status : vm.form.reviewRequired ? "Pending Review" : "Pending Approval";
          prepareProjects();
          vm.updateView();
          notice(wasSentBack ? "PET resubmitted for approval" : vm.selectedPet ? "PET updated" : vm.form.reviewRequired ? "PET submitted to the Accountable Executive Lead" : "PET sent directly to the Accountable Executive");
        }
        if (type === "spend" && !vm.demo) {
          if (!validateSpendFormAmounts(vm.form)) return;
          vm.recalculateSpendForm();
          var spendPayload = angular.extend({}, vm.form, { petId: vm.selectedPet.petId });
          spendPayload.head = petProjectExpenseHead(vm.selectedProject) || spendPayload.head;
          assignUniqueLineId(spendPayload, vm.form);
          spendPayload.units = parseNumericInput(spendPayload.units);
          spendPayload.unitPrice = parseNumericInput(spendPayload.unitPrice);
          spendPayload.foreignAmount = spendForeignAmount(spendPayload);
          spendPayload.exchangeRate = currencyRateToLocal(spendPayload.currency, spendPayload.exchangeRate);
          spendPayload.aedAmount = spendAedAmount(spendPayload);
          spendPayload.contingencyPercent = parseNumericInput(spendPayload.contingencyPercent);
          if (!validatePetRequestAmount(vm.selectedProject, vm.selectedPet, petFinalAedWithSpend(vm.selectedPet, spendPayload))) return;
          var isNewSpend = !spendPayload.spendItemId;
          $http.post("api/portfolio/spend-items", spendPayload).then(function (response) {
            var saved = response.data || {};
            spendPayload.spendItemId = saved.spendItemId || spendPayload.spendItemId;
            spendPayload.foreignAmount = spendPayload.foreignAmount || spendPayload.units * spendPayload.unitPrice;
            spendPayload.aedAmount = spendPayload.aedAmount || spendPayload.foreignAmount;
            if (isNewSpend) vm.selectedPet.spendItems.push(spendPayload);
            else angular.extend(vm.selectedPet.spendItems.filter(function (item) { return item.spendItemId === spendPayload.spendItemId; })[0] || {}, spendPayload);
            if (saved.finalRequestAedAmount != null) vm.selectedPet.requestedAmount = saved.finalRequestAedAmount;
            notice("PET line item saved");
            loadVendors(false);
            vm.spendFormVisible = false;
            prepareProjects();
            vm.updateView(true);
            redraw();
          }, function (response) {
            noticeError(responseMessage(response, "Unable to save the PET line item."));
          });
          return;
        }
        if (type === "spend") {
          if (!validateSpendFormAmounts(vm.form)) return;
          vm.recalculateSpendForm();
          var demoSpendPayload = angular.extend({}, vm.form);
          demoSpendPayload.head = petProjectExpenseHead(vm.selectedProject) || demoSpendPayload.head;
          assignUniqueLineId(demoSpendPayload, vm.form);
          demoSpendPayload.units = parseNumericInput(demoSpendPayload.units);
          demoSpendPayload.unitPrice = parseNumericInput(demoSpendPayload.unitPrice);
          demoSpendPayload.foreignAmount = spendForeignAmount(demoSpendPayload);
          demoSpendPayload.exchangeRate = currencyRateToLocal(demoSpendPayload.currency, demoSpendPayload.exchangeRate);
          demoSpendPayload.aedAmount = spendAedAmount(demoSpendPayload);
          demoSpendPayload.contingencyPercent = parseNumericInput(demoSpendPayload.contingencyPercent);
          var oldSpend = demoSpendPayload.spendItemId && vm.selectedPet.spendItems.filter(function (item) { return item.spendItemId === demoSpendPayload.spendItemId; })[0];
          if (!validatePetRequestAmount(vm.selectedProject, vm.selectedPet, petFinalAedWithSpend(vm.selectedPet, demoSpendPayload))) return;
          if (oldSpend) angular.extend(oldSpend, demoSpendPayload);
          else { demoSpendPayload.spendItemId = Date.now(); vm.selectedPet.spendItems.push(demoSpendPayload); }
          vm.selectedPet.requestedAmount = vm.petFinalAed(vm.selectedPet);
          prepareProjects();
          vm.updateView();
          notice("PET line item saved");
        }
        if (type === "decision" && !vm.demo) {
          var decisionRoute = vm.modal.stage === "review" ? "review" : "approve";
          if (!vm.form.decision) { noticeError("Select a decision before recording this request."); return; }
          if ((vm.form.decision === "SendBack" || vm.form.decision === "RejectCancel") && !String(vm.form.comments || "").trim()) { noticeError("Comments / reason is required for this decision."); return; }
          if (vm.decisionCapexEditable() && !vm.form.budgetSourceId) { noticeError("Select a CapEx source before approval."); return; }
          var decisionPayload = { comments: vm.form.comments, decision: vm.form.decision, approve: vm.form.decision === "Approve" };
          if (vm.decisionCapexEditable()) decisionPayload.budgetSourceId = vm.form.budgetSourceId;
          var decisionItems = vm.modal.bulk ? vm.bulkDecisionItems.slice(0) : [{ project: vm.selectedProject, pet: vm.form }];
          if (!decisionItems.length) { noticeError("Select at least one PET before recording this decision."); return; }
          var projectIds = decisionItems.map(function (item) { return item.project && item.project.projectId; });
          $q.all(decisionItems.map(function (item) {
            return $http.post("api/portfolio/pets/" + item.pet.petId + "/" + decisionRoute, angular.copy(decisionPayload));
          })).then(function () {
            notice(vm.modal.bulk ? decisionItems.length + " PET decision(s) recorded" : "Decision recorded");
            vm.clearApprovalSelection();
            vm.close();
            refreshProjectsFromDatabase(projectIds);
          }, function (response) {
            noticeError(responseMessage(response, "Unable to record this decision."));
            refreshProjectsFromDatabase(projectIds);
          });
          return;
        }
        if (type === "decision") {
          if (!vm.form.decision) { noticeError("Select a decision before recording this request."); return; }
          if ((vm.form.decision === "SendBack" || vm.form.decision === "RejectCancel") && !String(vm.form.comments || "").trim()) { noticeError("Comments / reason is required for this decision."); return; }
          if (vm.decisionCapexEditable() && !vm.form.budgetSourceId) { noticeError("Select a CapEx source before approval."); return; }
          var demoDecisionItems = vm.modal.bulk ? vm.bulkDecisionItems.slice(0) : [{ project: vm.selectedProject, pet: vm.form }];
          if (!demoDecisionItems.length) { noticeError("Select at least one PET before recording this decision."); return; }
          demoDecisionItems.forEach(function (item) {
            var project = item.project || vm.selectedProject;
            var target = project.pets.filter(function (p) { return p.petId === item.pet.petId; })[0];
            if (!target) return;
            target.status = vm.form.decision === "SendBack" ? "Sent Back" : vm.form.decision === "RejectCancel" ? "Rejected" : vm.modal.stage === "review" ? "Pending Approval" : "Approved";
            project.status = target.status;
            if (target.status === "Pending Approval" && vm.form.budgetSourceId) {
              var reviewBudget = vm.selectedBudgetSource();
              project.budgetSourceId = vm.form.budgetSourceId;
              project.budgetType = "CAPEX";
              if (reviewBudget) project.budgetSource = reviewBudget.externalId;
            }
            if (target.status === "Approved") {
              if (vm.form.budgetSourceId) {
                var selectedBudget = vm.selectedBudgetSource();
                project.budgetSourceId = vm.form.budgetSourceId;
                project.budgetType = "CAPEX";
                if (selectedBudget) project.budgetSource = selectedBudget.externalId;
              }
              vm.metrics.petsApproved++;
              vm.metrics.petsOnTrack--;
              project.availableBudget -= target.requestedAmount;
            } else if (target.status === "Rejected") {
              vm.metrics.petsRejected++;
              vm.metrics.petsOnTrack--;
            }
            if (vm.modal.stage === "review") { target.reviewerEmail = vm.session.email; target.reviewedUtc = new Date(); }
            if (vm.modal.stage === "approve") target.approverEmail = vm.session.email;
          });
          prepareProjects();
          vm.updateView();
          notice(demoDecisionItems.length + " PET decision(s) recorded");
        }
        if (type === "budgetLine" && !vm.demo) {
          vm.onBudgetLinePetChange(true);
          if (!vm.selectedPet) { noticeError("Select a PET reference before saving the budget line."); return; }
          if (!validateBudgetLineVendorSelection()) return;
          if (!validateBudgetLineAmount()) return;
          var budgetLinePayload = angular.extend({}, vm.form, { petId: vm.selectedPet.petId, petReference: vm.form.petReference || vm.selectedPet.code, sourceSpendItemIds: collectSelectedBudgetLineSpendItemIds() });
          var budgetLineProjectId = vm.selectedProject && vm.selectedProject.projectId;
          $http.post("api/portfolio/budget-lines", budgetLinePayload).then(function (response) {
            var saved = response.data || {};
            var budgetLineId = budgetLinePayload.budgetLineId || saved.budgetLineId || saved.BudgetLineId;
            uploadBudgetLineDocuments(budgetLineId).then(function () {
              notice("Budget line saved");
              vm.close();
              loadDashboard().then(function () { return loadGlFunds(false); }).then(function () { if (budgetLineProjectId) refreshProjectPets(budgetLineProjectId, true); });
            }, function (uploadResponse) {
              noticeError(responseMessage(uploadResponse, "Budget line was saved, but document upload failed."));
            });
          }, function (response) {
            noticeError(responseMessage(response, "Unable to save the budget line."));
          });
          return;
        }
        if (type === "budgetLine") {
          vm.onBudgetLinePetChange(true);
          if (!vm.selectedPet) { noticeError("Select a PET reference before saving the budget line."); return; }
          if (!validateBudgetLineVendorSelection()) return;
          if (!validateBudgetLineAmount()) return;
          vm.form.petReference = vm.form.petReference || vm.selectedPet.code;
          vm.form.sourceSpendItemIds = collectSelectedBudgetLineSpendItemIds();
          var old =
            vm.form.budgetLineId &&
            vm.selectedPet.budgetLines.filter(function (x) {
              return x.budgetLineId === vm.form.budgetLineId;
            })[0];
          if (old) angular.extend(old, vm.form);
          else {
            vm.form.budgetLineId = Date.now();
            vm.form.invoices = [];
            vm.selectedPet.budgetLines.push(vm.form);
          }
          prepareProjects();
          vm.updateView();
          notice("Budget line saved");
        }
        if (type === "invoice" && !vm.demo) {
          if (!validateNumericInput(vm.form && vm.form.invoiceAmount, "Invoice amount", false)) return;
          var invoicePayload = angular.extend({}, vm.form, { budgetLineId: vm.selectedLine.budgetLineId });
          invoicePayload.invoiceAmount = parseNumericInput(invoicePayload.invoiceAmount);
          var invoiceProjectId = vm.selectedProject && vm.selectedProject.projectId;
          $http.post("api/portfolio/invoices", invoicePayload).then(function (response) {
            var saved = response.data || {};
            var invoiceId = invoicePayload.invoiceId || saved.invoiceId || saved.InvoiceId;
            uploadInvoiceDocument(invoiceId).then(function () {
              notice("Invoice saved");
              vm.close();
              loadDashboard().then(function () { if (invoiceProjectId) refreshProjectPets(invoiceProjectId, true); });
            }, function (uploadResponse) {
              noticeError(responseMessage(uploadResponse, "Invoice was saved, but document upload failed."));
            });
          }, function (response) {
            noticeError(responseMessage(response, "Unable to save the invoice."));
          });
          return;
        }
        if (type === "invoice") {
          if (!validateNumericInput(vm.form && vm.form.invoiceAmount, "Invoice amount", false)) return;
          vm.form.invoiceAmount = parseNumericInput(vm.form.invoiceAmount);
          var oldInvoice =
            vm.form.invoiceId &&
            vm.selectedLine.invoices.filter(function (x) {
              return x.invoiceId === vm.form.invoiceId;
            })[0];
          if (oldInvoice) angular.extend(oldInvoice, vm.form);
          else {
            vm.form.invoiceId = Date.now();
            vm.selectedLine.invoices.push(vm.form);
            vm.metrics.invoicesRaised++;
            vm.metrics.invoicesOutstanding++;
          }
          prepareProjects();
          vm.updateView();
          notice("Invoice saved");
        }
        if (type === "budget") {
          if (!validateBudgetSourceAmounts(vm.form)) return;
          vm.form.description = String(vm.form.description || "").trim();
          if (!vm.form.description) { noticeError("Description is required."); return; }
          var currentBudget = vm.selectedBudget ? parseNumericInput(vm.selectedBudget.budget) : parseNumericInput(vm.form.budget);
          var currentAvailable = vm.selectedBudget ? parseNumericInput(vm.selectedBudget.availableBudget) : parseNumericInput(vm.form.availableBudget);
          vm.form.budget = parseNumericInput(vm.form.budget);
          vm.form.utilization = parseNumericInput(vm.form.utilization);
          vm.form.availableBudget = parseNumericInput(vm.form.availableBudget);
          var savedBudget = angular.copy(vm.form);
          savedBudget.availableBudget = currentAvailable + (savedBudget.budget - currentBudget);
          if (savedBudget.availableBudget < 0) { noticeError("Budget cannot be below the amount already utilized or reserved."); return; }
          if (vm.demo) {
            angular.extend(vm.selectedBudget, savedBudget);
            vm.updateBudgetView(true);
            notice("Budget source updated");
          } else {
            $http.put("api/portfolio/budgets/" + vm.form.budgetSourceId, vm.form).then(function () {
              angular.extend(vm.selectedBudget, savedBudget);
              vm.updateBudgetView(true);
              notice("Budget source updated");
              vm.close();
              redraw();
            }, function (response) { noticeError(responseMessage(response, "Unable to update budget source.")); });
            return;
          }
        }
        if (type === "currency") {
          if (!vm.form || !String(vm.form.code || "").trim()) { noticeError("Currency code is required."); return; }
          if (!String(vm.form.name || "").trim()) { noticeError("Currency name is required."); return; }
          if (!validateNumericInput(vm.form.rateToLocal, "Rate to local", false)) return;
          vm.form.code = String(vm.form.code || "").trim().toUpperCase();
          vm.form.name = String(vm.form.name || "").trim();
          vm.form.rateToLocal = parseNumericInput(vm.form.rateToLocal);
          if (vm.demo) {
            if (vm.selectedCurrency) angular.extend(vm.selectedCurrency, vm.form);
            else { vm.form.currencyId = Date.now(); vm.currencies.push(vm.form); }
            vm.updateCurrencyView(true);
            notice("Currency saved");
          } else {
            $http.post("api/portfolio/currencies", vm.form).then(function (response) {
              var saved = response.data || vm.form;
              if (vm.selectedCurrency) angular.extend(vm.selectedCurrency, saved);
              else vm.currencies.push(saved);
              vm.updateCurrencyView(true);
              notice("Currency saved");
              vm.close();
              redraw();
            }, function (response) { noticeError(responseMessage(response, "Unable to save currency.")); });
            return;
          }
        }
        if (type === "vendor") {
          if (!vm.form || !String(vm.form.name || "").trim()) { noticeError("Vendor name is required."); return; }
          vm.form.name = String(vm.form.name || "").trim();
          if (!validateVendorDuplicate(vm.form)) return;
          if (vm.demo) {
            if (vm.selectedVendor) angular.extend(vm.selectedVendor, vm.form);
            else { vm.form.vendorId = Date.now(); vm.vendors.push(vm.form); }
            vm.updateVendorView(true);
            notice("Vendor saved");
          } else {
            $http.post("api/portfolio/vendors", vm.form).then(function (response) {
              var saved = response.data || vm.form;
              if (vm.selectedVendor) angular.extend(vm.selectedVendor, saved);
              else vm.vendors.push(saved);
              vm.updateVendorView(true);
              notice("Vendor saved");
              vm.close();
              redraw();
            }, function (response) { noticeError(responseMessage(response, "Unable to save vendor.")); });
            return;
          }
        }
        if (type === "gl") {
          if (!vm.form || !String(vm.form.glNumber || "").trim()) { noticeError("GL Number is required."); return; }
          if (!String(vm.form.glName || "").trim()) { noticeError("GL Description/Name is required."); return; }
          if (!validateNumericInput(vm.form.fundAmount, "Fund Amount", false)) return;
          vm.form.glNumber = normalizedGlNumber(vm.form.glNumber);
          vm.form.glName = String(vm.form.glName || "").trim();
          vm.form.fundAmount = parseNumericInput(vm.form.fundAmount);
          if (!validateGlDuplicate(vm.form)) return;
          if (vm.demo) {
            vm.form.reservedAmount = vm.form.reservedAmount || 0;
            vm.form.availableBalance = Math.max(vm.form.fundAmount - vm.form.reservedAmount, 0);
            if (vm.selectedGlFundItem) angular.extend(vm.selectedGlFundItem, vm.form);
            else { vm.form.glFundId = Date.now(); vm.form.createdUtc = new Date(); vm.form.createdBy = vm.session.email; vm.glFunds.push(vm.form); }
            vm.updateGlView(true);
            notice("GL saved");
          } else {
            $http.post("api/portfolio/gl-funds", vm.form).then(function (response) {
              var saved = response.data || vm.form;
              if (vm.selectedGlFundItem) angular.extend(vm.selectedGlFundItem, saved);
              else vm.glFunds.push(saved);
              vm.updateGlView(true);
              notice("GL saved");
              vm.close();
              redraw();
            }, function (response) { noticeError(responseMessage(response, "Unable to save GL.")); });
            return;
          }
        }
        if (type === "upload" && vm.modal.kind !== "attachment" && vm.modal.kind !== "sources" && !vm.demo) {
          var item = vm.form.item;
          var kind = vm.modal.kind;
          var parentId = kind === "pet" ? item.projectId : kind === "budget" ? item.petId : kind === "invoice" ? item.budgetLineId : null;
          if (!parentId) { noticeError("Unable to determine where to import these rows."); return; }
          if (kind === "pet") {
            if (!validatePetUploadRows(true)) return;
            saveProjectBudgetSelectionIfNeeded(item).then(function () {
              savePetUploadRows(parentId, function () { refreshProjectPets(parentId, true); });
            }, function (response) { if (!response || !response.handled) noticeError(responseMessage(response, "Unable to save the project budget selection.")); });
            return;
          }
          runBulkImport(kind, parentId, function () {
            if (vm.selectedProject) refreshProjectPets(vm.selectedProject.projectId, true);
          });
          return;
        }
        if (type === "upload" && vm.modal.kind === "sources" && !vm.demo) {
          var sourceFiles = vm.uploadFiles || (vm.uploadFile ? [vm.uploadFile] : []);
          if (!sourceFiles.length) { noticeError("Choose the CAPEX/OPEX CSV or Excel file first."); return; }
          var sourceData = new FormData();
          sourceFiles.forEach(function (file) { sourceData.append("file", file); });
          $http.post("api/portfolio/budgets/sync", sourceData, { transformRequest: angular.identity, headers: { "Content-Type": undefined } }).then(function (response) {
            notice(((response.data && response.data.imported) || 0) + " budget source(s) synchronized.");
            vm.close();
            loadDashboard();
          }, function (response) {
            noticeError(responseMessage(response, "Unable to synchronize the CAPEX/OPEX file."));
          });
          return;
        }
        if (type === "upload" && vm.modal.kind === "attachment" && !vm.demo) {
          var pet = vm.form.item;
          var files = vm.uploadFiles || (vm.uploadFile ? [vm.uploadFile] : []);
          if (!pet || !pet.petId) { noticeError("Unable to determine the PET request for this document."); return; }
          if (!files.length) { noticeError("Choose at least one supporting document first."); return; }
          uploadAttachments("PET", pet.petId, files).then(function () {
            notice(files.length + " supporting document(s) uploaded.");
            vm.close();
            if (vm.selectedProject) refreshProjectPets(vm.selectedProject.projectId, true);
            else loadDashboard();
          }, function (response) {
            noticeError(responseMessage(response, "Unable to upload the supporting document."));
          });
          return;
        }
        if (type === "upload") notice("File accepted for validation");
        vm.close();
        redraw();
      };
      var toastTimer;
      function notice(message) {
        if (toastTimer) $timeout.cancel(toastTimer);
        vm.toast = message;
        vm.toastIsError = false;
        toastTimer = $timeout(function () {
          vm.toast = "";
        }, 3000);
      }
      function noticeError(message) {
        if (toastTimer) $timeout.cancel(toastTimer);
        vm.toast = message;
        vm.toastIsError = true;
        toastTimer = $timeout(function () {
          vm.toast = "";
          vm.toastIsError = false;
        }, 5000);
      }
      vm.dismissToast = function () {
        if (toastTimer) $timeout.cancel(toastTimer);
        vm.toast = "";
        vm.toastIsError = false;
      };
      var iconTimer;
      function redraw() {
        if (iconTimer) $timeout.cancel(iconTimer);
        iconTimer = $timeout(function () {
          angular.element(document.querySelectorAll('select[ng-model$="yearlyRecurrence"]')).removeAttr("required");
          Array.prototype.forEach.call(document.querySelectorAll('input[ng-model="row.vendor"], input[ng-model="vm.form.vendor"], input[ng-model="vm.form.vendorName"], input[ng-model="vm.petRowEditor.row.vendor"]'), function (input) { input.setAttribute("list", input.getAttribute("data-vendor-list") || "vendor-suggestions"); });
          Array.prototype.forEach.call(document.querySelectorAll('input[ng-model="item.budgetLineVendor"]'), function (input) { input.readOnly = true; input.setAttribute("tabindex", "-1"); });
          refreshIcons();
          $timeout(refreshIcons, 60, false);
        }, 0, false);
      }
      function refreshIcons() {
        if (window.lucide) window.lucide.createIcons({ attrs: { "stroke-width": 1.8 } });
      }
      function loadDashboard() {
        return $http.get("api/portfolio/dashboard", { params: { _: Date.now() } }).then(function (response) {
          var data = response.data || {};
          vm.demo = false;
          vm.metrics = (data.metrics && data.metrics[0]) || vm.metrics;
          mergeProjects(data.projects || []);
          mergeApprovalPets(data.approvalPets || []);
          vm.budgets = data.budgets || [];
          vm.jira = data.jira || [];
          vm.budgetUsage = data.budgetUsage || [];
          vm.nonProjectBudgetUsage = data.nonProjectBudgetUsage || [];
          vm.nonProjectOpex = data.nonProjectOpex || [];
          refreshSelectedBudgetUsageRows();
          prepareProjects();
          vm.updateView(true);
          vm.updateReportView();
          $q.all([loadApprovalMonitoring(), loadVendor360Lines(), loadVendorInvoices()]).then(function () { vm.updateVendorSpendView(true); redraw(); });
          redraw();
        }, function (response) {
          if (response && response.status === 401) vm.signOut();
          else noticeError("Unable to refresh transactions.");
          redraw();
          return $q.reject(response);
        });
      }
      // Preserves existing project objects (and their expanded/pets/petsLoaded state) instead of
      // replacing the whole array, so re-loading the dashboard after a save doesn't collapse rows
      // the user already had open.
      function mergeProjects(freshList) {
        var existingById = {};
        vm.projects.forEach(function (p) { existingById[p.projectId] = p; });
        vm.projects = freshList.map(function (fresh) {
          var existing = existingById[fresh.projectId];
          if (existing) { angular.extend(existing, fresh); return existing; }
          return fresh;
        });
      }
      function mergeApprovalPets(pets) {
        var projectsById = {};
        vm.projects.forEach(function (project) { projectsById[project.projectId] = project; });
        (pets || []).forEach(function (pet) {
          var project = projectsById[pet.projectId];
          if (!project) return;
          if (typeof project.petsLoaded === "undefined") project.petsLoaded = false;
          project.pets = project.pets || [];
          var existing = project.pets.filter(function (item) { return item.petId === pet.petId; })[0];
          if (existing) angular.extend(existing, pet);
          else project.pets.push(pet);
        });
      }
      function loadRoles(showError) {
        if (!vm.hasRole("Admin") || vm.demo) return $q.when();
        return $http.get("api/portfolio/roles").then(function (response) {
          var data = response.data || {};
          vm.availableManagedRoles = (data.roles || vm.availableManagedRoles).filter(function (role) { return role !== "Master"; });
          vm.roleUsers = normalizeRoleUsers(data.users || []);
          vm.updateRoleView();
          redraw();
        }, function (response) {
          if (showError || vm.tab === "roles") noticeError(responseMessage(response, "Unable to load role management."));
        });
      }
      function loadCurrencies(showError) {
        if (vm.demo) { vm.updateCurrencyView(true); return $q.when(); }
        return $http.get("api/portfolio/currencies").then(function (response) {
          vm.currencies = response.data || [];
          vm.updateCurrencyView(true);
          redraw();
        }, function (response) {
          if (showError || vm.tab === "currencies") noticeError(responseMessage(response, "Unable to load currencies."));
        });
      }
      function loadVendors(showError) {
        if (vm.demo) { vm.updateVendorView(true); return $q.when(); }
        return $http.get("api/portfolio/vendors").then(function (response) {
          vm.vendors = response.data || [];
          vm.updateVendorView(true);
          redraw();
        }, function (response) {
          if (showError || vm.tab === "vendors") noticeError(responseMessage(response, "Unable to load vendors."));
        });
      }
      function loadGlFunds(showError) {
        if (vm.demo) { vm.updateGlView(true); return $q.when(); }
        return $http.get("api/portfolio/gl-funds").then(function (response) {
          vm.glFunds = response.data || [];
          vm.updateGlView(true);
          redraw();
        }, function (response) {
          if (showError || vm.tab === "gl") noticeError(responseMessage(response, "Unable to load GL funding."));
        });
      }
      function normalizedVendorName(value) {
        return String(value || "").trim().toLowerCase();
      }
      function validateVendorDuplicate(vendor) {
        var name = normalizedVendorName(vendor && vendor.name);
        var vendorId = vendor && vendor.vendorId;
        var duplicate = (vm.vendors || []).filter(function (item) {
          return item && normalizedVendorName(item.name) === name && (!vendorId || String(item.vendorId) !== String(vendorId));
        })[0];
        if (duplicate) { noticeError("Vendor already exists."); return false; }
        return true;
      }
      function normalizedGlNumber(value) {
        value = String(value || "").trim();
        return value === "__NO_GL__" ? "" : value.toUpperCase();
      }
      function validateGlDuplicate(gl) {
        var glNumber = normalizedGlNumber(gl && gl.glNumber);
        var glFundId = gl && gl.glFundId;
        var duplicate = (vm.glFunds || []).filter(function (item) {
          return item && normalizedGlNumber(item.glNumber) === glNumber && (!glFundId || String(item.glFundId) !== String(glFundId));
        })[0];
        if (duplicate) { noticeError("GL Number already exists."); return false; }
        return true;
      }
      vm.activeGlFunds = function () {
        var selected = normalizedGlNumber(vm.form && vm.form.glNumber);
        return (vm.glFunds || []).filter(function (gl) { return gl && (gl.isActive || normalizedGlNumber(gl.glNumber) === selected); });
      };
      vm.selectedGlFund = function () {
        var glNumber = normalizedGlNumber(vm.form && vm.form.glNumber);
        return (vm.glFunds || []).filter(function (gl) { return normalizedGlNumber(gl.glNumber) === glNumber; })[0] || null;
      };
      function normalizeRoleUsers(users) {
        return users.map(function (user) {
          var roles = String(user.roles || user.Roles || "").split(",").filter(Boolean);
          user.userId = user.userId || user.UserId;
          user.email = user.email || user.Email || "";
          user.displayName = user.displayName || user.DisplayName || "";
          user.isActive = typeof user.isActive === "boolean" ? user.isActive : !!user.IsActive;
          user.portalAccess = typeof user.portalAccess === "boolean" ? user.portalAccess : !!user.PortalAccess;
          user.roleNames = roles.slice();
          user.roleMap = {};
          roles.forEach(function (role) { user.roleMap[role] = true; if (role === "Master") user.roleMap.Admin = true; });
          user.elevatedRole = ["Reviewer", "Approver", "Admin"].filter(function (role) { return user.roleMap[role]; })[0] || "";
          user.roleList = roles.join(", ") || "Requestor";
          return user;
        });
      }
      function previewRoleUsers() {
        return normalizeRoleUsers([]);
      }
      vm.saveUserRoles = function (user) {
        var selected = user.elevatedRole ? [user.elevatedRole] : [];
        if (vm.demo) { user.roleList = selected.length ? "Requestor, " + selected.join(", ") : "Requestor"; vm.updateRoleView(true); notice("Roles updated"); return; }
        $http.post("api/portfolio/roles", { userId: user.userId, roles: selected }).then(function () {
          user.roleList = selected.length ? "Requestor, " + selected.join(", ") : "Requestor";
          vm.updateRoleView(true);
          notice("Roles updated");
        }, function (response) { noticeError(responseMessage(response, "Unable to update roles.")); });
      };
      vm.openUser = function (user) {
        var roles = user ? (user.roleNames || []) : [];
        vm.form = angular.copy(user || { isActive: true, portalAccess: true });
        vm.form.role = roles.indexOf("Master") >= 0 ? "Master" : (user && user.elevatedRole || "");
        vm.form.password = "";
        vm.form.securityQuestionId = null;
        vm.form.securityAnswer = "";
        vm.form.resetSecurityQuestion = false;
        vm.modal = { type: "user", kicker: "ADMINISTRATION", title: user ? "Edit user" : "Add user", submit: user ? "Save changes" : "Create user" };
        redraw();
      };
      vm.changeCredentialReset = function () {
        if (vm.form && vm.form.resetSecurityQuestion) {
          vm.form.securityQuestionId = null;
          vm.form.securityAnswer = "";
        }
      };
      vm.saveManagedUser = function () {
        var form = vm.form || {};
        var payload = {
          userId: form.userId || null,
          email: String(form.email || "").trim(),
          displayName: String(form.displayName || "").trim(),
          roles: form.role ? [form.role] : [],
          isActive: !!form.isActive,
          portalAccess: !!form.portalAccess,
          password: form.password || "",
          securityQuestionId: form.securityQuestionId || null,
          securityAnswer: form.securityAnswer || "",
          resetSecurityQuestion: !!form.resetSecurityQuestion,
        };
        if (payload.resetSecurityQuestion && !window.confirm("Require this user to sign in with the temporary password and choose a new password and recovery question?")) return;
        if (payload.userId && payload.password && !window.confirm("Set a new password for " + payload.displayName + "?")) return;
        if (vm.demo) {
          var demoUser = (vm.roleUsers || []).filter(function (item) { return Number(item.userId) === Number(payload.userId); })[0];
          if (!demoUser) { payload.userId = Date.now(); demoUser = {}; vm.roleUsers.push(demoUser); }
          angular.extend(demoUser, payload, { roles: payload.roles.join(","), userId: payload.userId });
          normalizeRoleUsers([demoUser]);
          vm.roleUsers = normalizeRoleUsers(vm.roleUsers);
          vm.updateRoleView(true);
          vm.close();
          notice(payload.userId === form.userId ? "User updated" : "User created");
          return;
        }
        $http.post("api/portfolio/users", payload).then(function () {
          vm.close();
          notice(payload.userId ? "User updated" : "User created");
          loadRoles(true);
        }, function (response) { noticeError(responseMessage(response, "Unable to save user.")); });
      };
      function saveManagedUserState(user, nextActive, nextPortalAccess) {
        var payload = {
          userId: user.userId,
          email: user.email,
          displayName: user.displayName,
          roles: user.roleNames && user.roleNames.indexOf("Master") >= 0 ? ["Master"] : (user.elevatedRole ? [user.elevatedRole] : []),
          isActive: nextActive,
          portalAccess: nextPortalAccess,
          password: "",
          resetSecurityQuestion: false,
        };
        if (vm.demo) {
          user.isActive = nextActive;
          user.portalAccess = nextPortalAccess;
          vm.updateRoleView(true);
          notice("User access updated");
          return;
        }
        $http.post("api/portfolio/users", payload).then(function () {
          notice("User access updated");
          loadRoles(true);
        }, function (response) { noticeError(responseMessage(response, "Unable to update user access.")); });
      }
      vm.toggleUserActive = function (user) {
        if (!user) return;
        var next = !user.isActive;
        if (!next && !window.confirm("Disable " + user.displayName + "? Their active sessions will be revoked.")) return;
        saveManagedUserState(user, next, user.portalAccess);
      };
      vm.togglePortalAccess = function (user) {
        if (!user) return;
        var next = !user.portalAccess;
        if (!next && !window.confirm("Disable portal access for " + user.displayName + "? Their active sessions will be revoked.")) return;
        saveManagedUserState(user, user.isActive, next);
      };
      vm.deleteManagedUser = function (user) {
        if (!user || !window.confirm("Permanently delete " + user.displayName + " (" + user.email + ")? Linked business records prevent deletion. This cannot be undone.")) return;
        if (vm.demo) {
          vm.roleUsers = vm.roleUsers.filter(function (item) { return Number(item.userId) !== Number(user.userId); });
          vm.updateRoleView(true);
          notice("User deleted");
          return;
        }
        $http.delete("api/portfolio/users/" + user.userId).then(function () {
          notice("User deleted");
          loadRoles(true);
        }, function (response) { noticeError(responseMessage(response, "Unable to delete user.")); });
      };
      vm.refreshTransactions = function () {
        if (vm.refreshing) return;
        vm.refreshing = true;
        var loadedProjectIds = (vm.projects || []).filter(function (project) { return project.expanded || project.petsLoaded; }).map(function (project) { return project.projectId; });
        if (vm.demo) {
          prepareProjects();
          vm.updateView(true);
          vm.refreshing = false;
          notice("Transactions refreshed");
          redraw();
          return;
        }
        loadDashboard().then(function () {
          return $q.all(loadedProjectIds.map(function (projectId) { return refreshProjectPets(projectId, true, true); }));
        }).then(function () {
          return $q.all([loadRoles(vm.tab === "roles"), loadCurrencies(vm.tab === "currencies"), loadVendors(vm.tab === "vendors"), loadGlFunds(vm.tab === "gl")]);
        }).then(function () {
          notice("Transactions refreshed");
          vm.refreshing = false;
          redraw();
        }, function () {
          vm.refreshing = false;
          redraw();
        });
      };
      if (!restoreSession()) {
        prepareProjects();
        vm.updateView();
        redraw();
      }
    });
})();
