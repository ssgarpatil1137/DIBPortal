using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using DFM.Web.Models;

namespace DFM.Web.Infrastructure
{
    public static class CsvBulkImporter
    {
        private static readonly string[] DepartmentOptions = { "Business", "CET", "CIO Office", "Core", "CRM", "CTO", "Data", "EA&I", "EIS", "Governance", "Risk", "RTB", "Test Gov." };
        private static readonly string[] UnitTypeOptions = { "Nos", "Man Days", "Man Months", "Calender Months", "Fixed Scope" };
        private static readonly string[] CostTypeOptions = {
            "Hardware Purchase", "Hardware Rental", "Hardware AMC", "Software License Purchase", "Software License Subscription", "Software License AMC", "Escrow Agreement",
            "Project Management Services", "Business Analysis", "Architecture /Design", "SME Consulting Services", "Training", "in Months", "Application/Interface Development",
            "Software Customization", "Software Installation & Configuration", "Hardware Installation & Configuration", "Annual Support Operations", "QA Functional Testing",
            "QA Integration Testing", "QA Performance Testing", "QA Load Testing", "QA Test Automation", "SEC Penetration Testing", "UAT Functional Testing",
            "Professional Certification", "Quality Assurance (External)", "Travel & Accommodation", "Premises Rent", "Premises Fit out"
        };

        public static int Import(string kind, int parentId, string csv, string user)
        {
            return ImportRows(kind, parentId, Parse(csv), user, "CSV");
        }

        public static int ImportRows(string kind, int parentId, List<List<string>> rows, string user, string sourceName)
        {
            if (rows.Count < 2) throw new ArgumentException("The " + sourceName + " has no data rows.");
            rows = TableFromHeader(rows, RequiredColumns(kind), sourceName);
            var headers = HeaderMap(rows[0]);
            if (kind.Equals("pet", StringComparison.OrdinalIgnoreCase)) return ImportPets(parentId, rows, headers, user);
            if (kind.Equals("budget", StringComparison.OrdinalIgnoreCase)) return ImportBudgetLines(parentId, rows, headers, user);
            if (kind.Equals("invoice", StringComparison.OrdinalIgnoreCase)) return ImportInvoices(parentId, rows, headers, user);
            throw new ArgumentException("Unknown import kind.");
        }

        private static int ImportPets(int projectId, List<List<string>> rows, Dictionary<string, int> headers, string user)
        {
            return ImportPetRows(projectId, PetRows(rows.Skip(1), headers, true), user);
        }

        public static List<PetUploadRowRequest> PreviewPetRows(List<List<string>> rows, string sourceName)
        {
            rows = TableFromHeader(rows, RequiredColumns("pet"), sourceName);
            return PetRows(rows.Skip(1), HeaderMap(rows[0]), false);
        }

        public static int ImportPetRows(int projectId, IEnumerable<PetUploadRowRequest> rows, string user)
        {
            var sourceRows = (rows ?? Enumerable.Empty<PetUploadRowRequest>()).Where(row => row != null && HasPetUploadData(row)).ToList();
            var petReference = sourceRows.Select(row => row.PetReference).FirstOrDefault(reference => !string.IsNullOrWhiteSpace(reference));
            if (string.IsNullOrWhiteSpace(petReference)) petReference = GeneratedPetReference();
            var uploadRows = sourceRows.Select(row => { row.PetReference = petReference; return CalculatePetRow(row, true); }).ToList();
            EnsurePetLineIds(uploadRows, true);
            if (uploadRows.Count == 0) throw new ArgumentException("Add at least one PET row before saving.");
            VendorMaintenance.EnsureVendors(uploadRows, row => row.Vendor);
            var imported = 0;
            foreach (var group in uploadRows.GroupBy(row => row.PetReference, StringComparer.OrdinalIgnoreCase))
            {
                var existing = Db.Query("SELECT PetId,Status FROM dbo.PETRequests WHERE ProjectId=@project AND Code=@code", P("@project", projectId), P("@code", group.Key));
                var uploadedTotal = group.Sum(row => row.FinalAed); var petId = 0; var firstRow = group.First();
                if (existing.Count > 0)
                {
                    var existingStatus = Convert.ToString(existing[0]["Status"]);
                    if (!EditablePetStatus(existingStatus)) throw new ArgumentException("PET requests can be edited only while Pending Review or Sent Back.");
                    petId = Convert.ToInt32(existing[0]["PetId"]);
                    var existingSpend = Db.Query("SELECT ISNULL(SUM(FinalAedAmount),0) Amount FROM dbo.SpendItems WHERE PetId=@pet", P("@pet", petId)).FirstOrDefault();
                    uploadedTotal += existingSpend == null ? 0 : Convert.ToDecimal(existingSpend["Amount"], CultureInfo.InvariantCulture);
                }
                AmountValidation.ValidatePetRequestAmount(projectId, petId == 0 ? (int?)null : petId, uploadedTotal);
                List<Dictionary<string, object>> result;
                try
                {
                    result = Db.Query("EXEC dbo.sp_SavePet @PetId,@project,@code,@amount,@currency,@user,NULL,NULL,@reviewRequired", P("@PetId", petId == 0 ? (object)null : petId), P("@project", projectId), P("@code", group.Key), P("@amount", uploadedTotal), P("@currency", firstRow.Currency), P("@user", user), P("@reviewRequired", firstRow.ReviewRequired));
                }
                catch (SqlException ex)
                {
                    if (!ProcedureParameterError(ex)) throw;
                    result = Db.Query("EXEC dbo.sp_SavePet @PetId,@project,@code,@amount,@currency,@user", P("@PetId", petId == 0 ? (object)null : petId), P("@project", projectId), P("@code", group.Key), P("@amount", uploadedTotal), P("@currency", firstRow.Currency), P("@user", user));
                }
                if (petId == 0) petId = Convert.ToInt32(result[0]["PetId"]);
                foreach (var item in group)
                {
                    try
                    {
                        Db.Query("EXEC dbo.sp_SaveSpendItem NULL,@pet,@head,@topic,@vendor,@costType,@unitType,@units,@unitPrice,@currency,@foreign,@aed,@contingency,@gl,@department,@description,@yearlyRecurrence,@lineId,@srNo,@lineDate", P("@pet", petId), P("@head", item.Head), P("@topic", item.Topic), P("@vendor", item.Vendor), P("@costType", item.CostType), P("@unitType", item.UnitType), P("@units", item.Units), P("@unitPrice", item.UnitPrice), P("@currency", item.Currency), P("@foreign", item.ForeignAmount), P("@aed", item.AedAmount), P("@contingency", item.ContingencyPercent), P("@gl", item.GlNumber), P("@department", item.Department), P("@description", item.Description), P("@yearlyRecurrence", item.YearlyRecurrence), P("@lineId", item.LineId), P("@srNo", item.SerialNo), P("@lineDate", item.LineDate)); imported++;
                    }
                    catch (SqlException ex)
                    {
                        if (!ProcedureParameterError(ex)) throw;
                        Db.Query("EXEC dbo.sp_SaveSpendItem NULL,@pet,@head,@topic,@vendor,@costType,@unitType,@units,@unitPrice,@currency,@foreign,@aed,@contingency,@gl", P("@pet", petId), P("@head", item.Head), P("@topic", item.Topic), P("@vendor", item.Vendor), P("@costType", item.CostType), P("@unitType", item.UnitType), P("@units", item.Units), P("@unitPrice", item.UnitPrice), P("@currency", item.Currency), P("@foreign", item.ForeignAmount), P("@aed", item.AedAmount), P("@contingency", item.ContingencyPercent), P("@gl", item.GlNumber)); imported++;
                    }
                }
            }
            return imported;
        }

        private static List<PetUploadRowRequest> PetRows(IEnumerable<List<string>> rows, Dictionary<string, int> headers, bool strict)
        {
            RequireAny(headers, "vendor", new[] { "vendor", "vendorname", "supplier", "vendorsupplier" });
            RequireAny(headers, "unitprice", new[] { "unitprice", "price" });
            var petRows = rows.Where(row => !Empty(row) && HasPetLineData(row, headers)).Select(row => CalculatePetRow(new PetUploadRowRequest { ProjectId = GetAny(row, headers, "", "projectid"), PetReference = GetAny(row, headers, "", "petreference", "petreferenceno", "petreferencenumber"), SerialNo = GetAny(row, headers, "", "srno", "serialno", "serialnumber", "sr", "sno", "slno"), LineDate = DateNullable(row, headers, "date", "linedate"), LineId = "", Department = GetAny(row, headers, ValueAt(row, 2), "department", "dept", "division", "businessunit"), Currency = GetAny(row, headers, "AED", "currency", "basecy"), Head = GetAny(row, headers, "", "head", "exphead", "expensehead"), Topic = GetAny(row, headers, "", "topic", "subject", "particulars", "scope", "projectscope"), Vendor = GetAny(row, headers, "", "vendor", "vendorname", "supplier", "vendorsupplier", "suppliervendor"), Description = Get(row, headers, "description"), CostType = Get(row, headers, "costtype"), UnitType = Get(row, headers, "unittype"), Units = Decimal(row, headers, "units", 1), UnitPrice = DecimalAny(row, headers, 0, "unitprice", "price"), ForeignAmount = DecimalAny(row, headers, 0, "fcyamount", "amtfcy"), ExchangeRate = DecimalAny(row, headers, 0, "exchangerate", "conversionrate", "fxrate", "aedrate"), AedAmount = DecimalAny(row, headers, 0, "aedamount", "amtlcy"), ContingencyPercent = DecimalAny(row, headers, 0, "contingency", "cont"), FinalAed = DecimalAny(row, headers, 0, "finalaed", "finalamtlcy"), YearlyRecurrence = IntNullable(row, headers, "yearlyrecurrence"), GlNumber = Get(row, headers, "glnumber") }, strict)).ToList();
            EnsurePetLineIds(petRows, true);
            return petRows;
        }

        private static bool HasPetLineData(List<string> row, Dictionary<string, int> headers)
        {
            return HasAnyValue(row, headers, "vendor", "vendorname", "supplier", "vendorsupplier", "suppliervendor", "unitprice", "price", "topic", "description", "glnumber", "fcyamount", "amtfcy", "aedamount", "amtlcy", "finalaed", "finalamtlcy");
        }

        private static bool HasPetUploadData(PetUploadRowRequest row)
        {
            return !string.IsNullOrWhiteSpace(row.Topic) || !string.IsNullOrWhiteSpace(row.Vendor) || !string.IsNullOrWhiteSpace(row.Description) || !string.IsNullOrWhiteSpace(row.GlNumber) || row.UnitPrice > 0 || row.ForeignAmount > 0 || row.AedAmount > 0 || row.FinalAed > 0;
        }

        private static PetUploadRowRequest CalculatePetRow(PetUploadRowRequest row, bool strict)
        {
            if (strict && string.IsNullOrWhiteSpace(row.PetReference)) row.PetReference = GeneratedPetReference();
            if (strict && string.IsNullOrWhiteSpace(row.Vendor)) throw new ArgumentException("Vendor is required for every PET row.");
            NormalizePetDropdowns(row);
            if (strict) ValidatePetRequiredDropdowns(row);
            if (strict && row.UnitPrice <= 0) throw new ArgumentException("Unit Price is required for every PET row.");
            row.Currency = string.IsNullOrWhiteSpace(row.Currency) ? "AED" : row.Currency.Trim().ToUpperInvariant();
            row.Units = row.Units == 0 ? 1 : row.Units;
            var foreignAmount = row.Units * row.UnitPrice;
            var rate = CurrencyRateToLocal(row.Currency, row.ExchangeRate);
            row.ExchangeRate = rate;
            row.ForeignAmount = decimal.Round(foreignAmount, 2, MidpointRounding.AwayFromZero);
            row.AedAmount = decimal.Round(foreignAmount * rate, 2, MidpointRounding.AwayFromZero);
            row.FinalAed = decimal.Round(row.AedAmount * (1 + row.ContingencyPercent / 100), 2, MidpointRounding.AwayFromZero);
            return row;
        }

        private static void NormalizePetDropdowns(PetUploadRowRequest row)
        {
            var department = NormalizeDepartment(row.Department);
            var unitType = MatchOption(row.UnitType, UnitTypeOptions);
            var costType = MatchOption(row.CostType, CostTypeOptions);
            if (department != null) row.Department = department;
            if (unitType != null) row.UnitType = unitType;
            if (costType != null) row.CostType = costType;
        }

        private static void ValidatePetRequiredDropdowns(PetUploadRowRequest row)
        {
            var department = NormalizeDepartment(row.Department);
            if (department == null) throw new ArgumentException("Department is required for every PET row.");
            var unitType = MatchOption(row.UnitType, UnitTypeOptions);
            if (unitType == null) throw new ArgumentException("Unit Type is required for every PET row.");
            var costType = MatchOption(row.CostType, CostTypeOptions);
            if (costType == null) throw new ArgumentException("Cost Type is required for every PET row.");
            if (row.YearlyRecurrence.HasValue && (row.YearlyRecurrence.Value < 1 || row.YearlyRecurrence.Value > 5)) row.YearlyRecurrence = null;
            row.Department = department;
            row.UnitType = unitType;
            row.CostType = costType;
        }

        private static string NormalizeDepartment(string value)
        {
            var department = MatchOption(value, DepartmentOptions);
            var trimmed = (value ?? "").Trim();
            return department ?? (string.IsNullOrWhiteSpace(trimmed) ? null : trimmed);
        }

        private static decimal CurrencyRateToLocal(string code, decimal fallbackRate)
        {
            var currencyCode = string.IsNullOrWhiteSpace(code) ? "AED" : code.Trim().ToUpperInvariant();
            var row = Db.Query("SELECT RateToLocal FROM dbo.Currencies WHERE UPPER(Code)=@Code", P("@Code", currencyCode)).FirstOrDefault();
            if (row != null && row["RateToLocal"] != null)
            {
                var rate = Convert.ToDecimal(row["RateToLocal"], CultureInfo.InvariantCulture);
                if (rate > 0) return rate;
            }
            return fallbackRate > 0 ? fallbackRate : 1;
        }

        private static string MatchOption(string value, IEnumerable<string> options)
        {
            var key = OptionKey(value);
            return options.FirstOrDefault(option => OptionKey(option) == key);
        }

        private static string OptionKey(string value)
        {
            var key = new string((value ?? "").Trim().ToLowerInvariant().Where(char.IsLetterOrDigit).ToArray());
            return key == "eal" ? "eai" : key;
        }

        private static string GeneratedPetReference()
        {
            return "PET-" + DateTime.UtcNow.Year + "-" + Guid.NewGuid().ToString("N").Substring(0, 8).ToUpperInvariant();
        }

        private static bool EditablePetStatus(string status)
        {
            return string.Equals(status, "Pending Review", StringComparison.OrdinalIgnoreCase) || string.Equals(status, "Sent Back", StringComparison.OrdinalIgnoreCase);
        }

        private static void EnsurePetLineIds(IEnumerable<PetUploadRowRequest> rows, bool forceNew)
        {
            var usedLineIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var row in rows.Where(row => row != null))
            {
                var lineId = (row.LineId ?? "").Trim();
                if (forceNew || string.IsNullOrWhiteSpace(lineId) || usedLineIds.Contains(lineId)) lineId = GeneratedLineId(usedLineIds);
                row.LineId = lineId;
                usedLineIds.Add(lineId);
            }
        }

        private static string GeneratedLineId(HashSet<string> usedLineIds)
        {
            string lineId;
            do
            {
                lineId = "LINE-" + DateTime.UtcNow.ToString("yyyyMMddHHmmssfff") + "-" + Guid.NewGuid().ToString("N").Substring(0, 6).ToUpperInvariant();
            } while (usedLineIds.Contains(lineId));
            return lineId;
        }

        private static int ImportBudgetLines(int petId, List<List<string>> rows, Dictionary<string, int> headers, string user)
        {
            Require(headers, "vendor", "cost", "currency"); var imported = 0;
            for (var index = 1; index < rows.Count; index++)
            {
                var row = rows[index]; if (Empty(row)) continue;
                var cost = Decimal(row, headers, "cost");
                AmountValidation.ValidateBudgetLineAmount(petId, null, cost);
                Db.Query("EXEC dbo.sp_SaveBudgetLine NULL,@pet,@vendor,@justification,@cost,@currency,@gl,@petRef,@camId,@camStatus,@camComments,@lpoRequest,@lpoStatus,@lpoComments,@user", P("@pet", petId), P("@vendor", Get(row, headers, "vendor")), P("@justification", Get(row, headers, "justification")), P("@cost", cost), P("@currency", Get(row, headers, "currency", "AED")), P("@gl", Get(row, headers, "gl")), P("@petRef", Get(row, headers, "petreference")), P("@camId", Get(row, headers, "camid")), P("@camStatus", Get(row, headers, "camstatus")), P("@camComments", Get(row, headers, "camcomments")), P("@lpoRequest", Get(row, headers, "lporequest")), P("@lpoStatus", Get(row, headers, "lpostatus")), P("@lpoComments", Get(row, headers, "lpocomments")), P("@user", user)); imported++;
            }
            return imported;
        }

        private static int ImportInvoices(int defaultBudgetLineId, List<List<string>> rows, Dictionary<string, int> headers, string user)
        {
            RequireAny(headers, "vendorname", new[] { "vendorname", "vendor", "supplier" });
            RequireAny(headers, "invoicenumber", new[] { "invoicenumber", "invoice", "number" });
            RequireAny(headers, "invoiceamount", new[] { "invoiceamount", "amount" });
            var imported = 0;
            for (var index = 1; index < rows.Count; index++)
            {
                var row = rows[index]; if (Empty(row) || !HasInvoiceData(row, headers)) continue; var lineId = defaultBudgetLineId > 0 ? defaultBudgetLineId : IntAny(row, headers, 0, "budgetlineid", "budgetline", "lineid"); if (lineId <= 0) throw new ArgumentException("Budget Line ID is required for every Invoice row."); var amount = DecimalAny(row, headers, 0, "invoiceamount", "amount"); DateTime paymentDate; object date = DateTime.TryParse(GetAny(row, headers, "", "paymentdate", "date"), CultureInfo.InvariantCulture, DateTimeStyles.None, out paymentDate) ? (object)paymentDate : null;
                AmountValidation.ValidateInvoiceAmount(lineId, null, amount);
                Db.Query("EXEC dbo.sp_SaveInvoice NULL,@line,@vendor,@justification,@gl,@number,@amount,@status,@paymentDate,@user", P("@line", lineId), P("@vendor", GetAny(row, headers, "", "vendorname", "vendor", "supplier")), P("@justification", GetAny(row, headers, "", "justification", "description")), P("@gl", GetAny(row, headers, "", "glnumber", "gl")), P("@number", GetAny(row, headers, "", "invoicenumber", "invoice", "number")), P("@amount", amount), P("@status", GetAny(row, headers, "Raised", "invoicestatus", "status")), P("@paymentDate", date), P("@user", user)); imported++;
            }
            return imported;
        }

        private static readonly string[] SourceIdAliases = { "externalid", "budgetsource", "sourceid", "source", "budgetcode", "budgetid", "code", "id" };
        private static readonly string[] SourceBudgetAliases = { "budget", "budgetamount", "approvedbudget", "totalbudget", "amount" };

        public static int ImportBudgetSources(List<List<string>> rows, string fileName, string user)
        {
            var headerIndex = rows.FindIndex(row => { var map = HeaderMap(row); return FirstHeader(map, SourceIdAliases) != null && FirstHeader(map, SourceBudgetAliases) != null; });
            if (headerIndex < 0) throw new ArgumentException("Missing columns in " + fileName + ": Budget Type, External Id, Description, Budget.");
            var headers = HeaderMap(rows[headerIndex]);
            var idColumn = FirstHeader(headers, SourceIdAliases);
            var budgetColumn = FirstHeader(headers, SourceBudgetAliases);
            var typeColumn = FirstHeader(headers, "budgettype", "type", "category");
            var descriptionColumn = FirstHeader(headers, "description", "budgetdescription", "details", "name");
            var utilizationColumn = FirstHeader(headers, "utilization", "utilisation", "utilized", "utilizedamount");
            var availableColumn = FirstHeader(headers, "availablebudget", "available");
            var lockedColumn = FirstHeader(headers, "lockedamt", "lockedamount", "locked");
            var afterLockedColumn = FirstHeader(headers, "budgetafterlockedamt", "budgetafterlockedamount", "budgetafterlocked");
            var claimColumn = FirstHeader(headers, "claimamt", "claimamount", "claim");
            var netColumn = FirstHeader(headers, "netbalance", "net");
            var lowerName = (fileName ?? "").ToLowerInvariant();
            var fileType = lowerName.Contains("capex") ? "CAPEX" : lowerName.Contains("opex") ? "OPEX" : null;

            var items = new List<BudgetSourceRow>();
            for (var index = headerIndex + 1; index < rows.Count; index++)
            {
                var row = rows[index]; if (Empty(row)) continue;
                var line = "Row " + (index + 1) + " of " + fileName + ": ";
                var externalId = Get(row, headers, idColumn);
                if (externalId.Length == 0) continue;
                if (externalId.Length > 100) throw new ArgumentException(line + "External Id cannot exceed 100 characters.");
                var type = (typeColumn == null ? "" : Get(row, headers, typeColumn)).ToUpperInvariant();
                if (type.Length == 0) type = fileType;
                if (type != "CAPEX" && type != "OPEX") throw new ArgumentException(line + "Budget Type must be CAPEX or OPEX.");
                var budget = SourceAmount(row, headers, budgetColumn);
                if (!budget.HasValue || budget.Value < 0) throw new ArgumentException(line + "Budget must be a number zero or greater.");
                var description = descriptionColumn == null ? "" : Get(row, headers, descriptionColumn);
                if (description.Length > 1000) description = description.Substring(0, 1000);
                items.Add(new BudgetSourceRow
                {
                    Type = type, ExternalId = externalId, Description = description, Budget = budget.Value,
                    Utilization = SourceAmount(row, headers, utilizationColumn), Available = SourceAmount(row, headers, availableColumn),
                    Locked = SourceAmount(row, headers, lockedColumn), AfterLocked = SourceAmount(row, headers, afterLockedColumn),
                    Claim = SourceAmount(row, headers, claimColumn), Net = SourceAmount(row, headers, netColumn)
                });
            }
            if (items.Count == 0) throw new ArgumentException(fileName + " has no budget source rows.");

            var sourceFile = (fileName ?? "").Length > 500 ? fileName.Substring(0, 500) : fileName;
            foreach (var item in items)
            {
                Db.Execute(@"MERGE dbo.BudgetSources AS t
USING (SELECT @Type BudgetType,@ExternalId ExternalId) AS s ON t.BudgetType=s.BudgetType AND t.ExternalId=s.ExternalId
WHEN MATCHED THEN UPDATE SET Description=NULLIF(@Description,N''),
 Utilization=ISNULL(@Utilization,t.Utilization),
 AvailableBudget=ISNULL(@Available,t.AvailableBudget+(@Budget-t.Budget)),
 LockedAmount=ISNULL(@Locked,t.LockedAmount),
 BudgetAfterLocked=ISNULL(@AfterLocked,@Budget-ISNULL(@Locked,t.LockedAmount)),
 ClaimAmount=ISNULL(@Claim,t.ClaimAmount),
 NetBalance=ISNULL(@Net,t.NetBalance+(@Budget-t.Budget)),
 Budget=@Budget, SourceFile=@File, LastSyncUtc=SYSUTCDATETIME(), UpdatedUtc=SYSUTCDATETIME()
WHEN NOT MATCHED THEN INSERT(BudgetType,ExternalId,Description,Budget,Utilization,AvailableBudget,LockedAmount,BudgetAfterLocked,ClaimAmount,NetBalance,SourceFile,LastSyncUtc)
 VALUES(@Type,@ExternalId,NULLIF(@Description,N''),@Budget,ISNULL(@Utilization,0),ISNULL(@Available,@Budget-ISNULL(@Utilization,0)),ISNULL(@Locked,0),
  ISNULL(@AfterLocked,@Budget-ISNULL(@Utilization,0)-ISNULL(@Locked,0)),ISNULL(@Claim,0),ISNULL(@Net,@Budget-ISNULL(@Utilization,0)-ISNULL(@Locked,0)),@File,SYSUTCDATETIME());",
                    P("@Type", item.Type), P("@ExternalId", item.ExternalId), P("@Description", item.Description), P("@Budget", item.Budget),
                    P("@Utilization", item.Utilization), P("@Available", item.Available), P("@Locked", item.Locked), P("@AfterLocked", item.AfterLocked),
                    P("@Claim", item.Claim), P("@Net", item.Net), P("@File", sourceFile));
            }
            Db.Execute("INSERT dbo.AuditLog(EntityType,EntityId,ActionName,UserEmail,Detail) VALUES('BudgetSource',NULL,'CsvSync',@User,@Detail)", P("@User", user ?? "system"), P("@Detail", sourceFile + ": " + items.Count + " row(s)"));
            return items.Count;
        }

        private class BudgetSourceRow
        {
            public string Type, ExternalId, Description;
            public decimal Budget;
            public decimal? Utilization, Available, Locked, AfterLocked, Claim, Net;
        }

        private static string FirstHeader(Dictionary<string, int> headers, params string[] names) { return names.FirstOrDefault(headers.ContainsKey); }

        private static decimal? SourceAmount(List<string> row, Dictionary<string, int> headers, string column)
        {
            if (column == null) return null;
            var text = Get(row, headers, column);
            if (text.Length == 0) return null;
            decimal value;
            return decimal.TryParse(NumericText(text), NumberStyles.Number, CultureInfo.InvariantCulture, out value) ? (decimal?)value : null;
        }

        private static bool HasInvoiceData(List<string> row, Dictionary<string, int> headers)
        {
            return HasAnyValue(row, headers, "vendorname", "vendor", "supplier", "invoicenumber", "invoice", "number", "invoiceamount", "amount");
        }

        public static List<List<string>> Parse(string text)
        {
            var result = new List<List<string>>(); var row = new List<string>(); var field = new StringBuilder(); var quoted = false; text = text ?? "";
            for (var index = 0; index < text.Length; index++)
            {
                var character = text[index];
                if (character == '"') { if (quoted && index + 1 < text.Length && text[index + 1] == '"') { field.Append('"'); index++; } else quoted = !quoted; }
                else if (character == ',' && !quoted) { row.Add(field.ToString()); field.Length = 0; }
                else if ((character == '\r' || character == '\n') && !quoted) { if (character == '\r' && index + 1 < text.Length && text[index + 1] == '\n') index++; row.Add(field.ToString()); field.Length = 0; result.Add(row); row = new List<string>(); }
                else field.Append(character);
            }
            if (field.Length > 0 || row.Count > 0) { row.Add(field.ToString()); result.Add(row); } return result;
        }

        private static string Normalize(string value) { return new string((value ?? "").Where(char.IsLetterOrDigit).Select(char.ToLowerInvariant).ToArray()); }
        private static string[] RequiredColumns(string kind) { return kind.Equals("pet", StringComparison.OrdinalIgnoreCase) ? new[] { "vendor", "unitprice" } : kind.Equals("budget", StringComparison.OrdinalIgnoreCase) ? new[] { "vendor", "cost", "currency" } : kind.Equals("invoice", StringComparison.OrdinalIgnoreCase) ? new[] { "vendorname", "invoicenumber", "invoiceamount" } : new string[0]; }
        private static List<List<string>> TableFromHeader(List<List<string>> rows, string[] required, string sourceName)
        {
            for (var index = 0; index < rows.Count; index++)
            {
                var headers = HeaderMap(rows[index]);
                if (required.All(name => HasRequiredHeader(headers, name))) return rows.Skip(index).ToList();
            }
            throw new ArgumentException("Missing upload columns in " + sourceName + ": " + string.Join(", ", required));
        }
        private static Dictionary<string, int> HeaderMap(List<string> row) { var headers = new Dictionary<string, int>(); row.Select((name, index) => new { name = Normalize(name), index }).Where(item => !string.IsNullOrWhiteSpace(item.name)).ToList().ForEach(item => { if (!headers.ContainsKey(item.name)) headers.Add(item.name, item.index); }); return headers; }
        private static string Get(List<string> row, Dictionary<string, int> headers, string name, string fallback = "") { int index; return headers.TryGetValue(name, out index) && index < row.Count && !string.IsNullOrWhiteSpace(row[index]) ? row[index].Trim() : fallback; }
        private static string GetAny(List<string> row, Dictionary<string, int> headers, string fallback, params string[] names) { foreach (var name in names) { var value = Get(row, headers, name); if (!string.IsNullOrWhiteSpace(value)) return value; var key = headers.Keys.FirstOrDefault(item => item.Contains(name)); if (key != null) { value = Get(row, headers, key); if (!string.IsNullOrWhiteSpace(value)) return value; } } return fallback; }
        private static string ValueAt(List<string> row, int index) { return index >= 0 && index < row.Count ? (row[index] ?? "").Trim() : ""; }
        private static decimal Decimal(List<string> row, Dictionary<string, int> headers, string name, decimal fallback = 0) { decimal value; return decimal.TryParse(NumericText(Get(row, headers, name)), NumberStyles.Number, CultureInfo.InvariantCulture, out value) ? value : fallback; }
        private static string NumericText(string value)
        {
            var text = (value ?? "").Trim();
            if (text.Length == 0) return text;
            var negative = text.StartsWith("(") && text.EndsWith(")");
            var characters = text.Where(character => char.IsDigit(character) || character == '.' || character == '-').ToArray();
            var numeric = new string(characters).Replace(",", "");
            if (negative && numeric.Length > 0 && numeric[0] != '-') numeric = "-" + numeric;
            return numeric;
        }
        private static decimal DecimalAny(List<string> row, Dictionary<string, int> headers, decimal fallback, params string[] names) { foreach (var name in names) { var value = Decimal(row, headers, name, decimal.MinValue); if (value != decimal.MinValue) return value; var key = headers.Keys.FirstOrDefault(item => item.Contains(name)); if (key != null) { value = Decimal(row, headers, key, decimal.MinValue); if (value != decimal.MinValue) return value; } } return fallback; }
        private static bool Has(List<string> row, Dictionary<string, int> headers, string name) { int index; return headers.TryGetValue(name, out index) && index < row.Count && !string.IsNullOrWhiteSpace(row[index]); }
        private static bool HasAny(List<string> row, Dictionary<string, int> headers, params string[] names) { return names.Any(name => Has(row, headers, name)); }
        private static bool HasAnyValue(List<string> row, Dictionary<string, int> headers, params string[] names) { return names.Any(name => Has(row, headers, name) || headers.Keys.Any(key => key.Contains(name) && Has(row, headers, key))); }
        private static int Int(List<string> row, Dictionary<string, int> headers, string name, int fallback) { int value; return int.TryParse(Get(row, headers, name), out value) ? value : fallback; }
        private static int IntAny(List<string> row, Dictionary<string, int> headers, int fallback, params string[] names) { foreach (var name in names) { int value; if (int.TryParse(Get(row, headers, name), out value)) return value; var key = headers.Keys.FirstOrDefault(item => item.Contains(name)); if (key != null && int.TryParse(Get(row, headers, key), out value)) return value; } return fallback; }
        private static int? IntNullable(List<string> row, Dictionary<string, int> headers, string name) { int value; return int.TryParse(Get(row, headers, name), out value) ? (int?)value : null; }
        private static DateTime? DateNullable(List<string> row, Dictionary<string, int> headers, params string[] names)
        {
            foreach (var name in names)
            {
                var value = Get(row, headers, name);
                DateTime date;
                if (DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.None, out date)) return date.Date;
                double serial;
                if (double.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out serial) && serial > 0)
                {
                    try { return DateTime.FromOADate(serial).Date; }
                    catch (ArgumentException) { }
                }
            }
            return null;
        }
        private static bool Empty(List<string> row) { return row.All(string.IsNullOrWhiteSpace); }
        private static void Require(Dictionary<string, int> headers, params string[] names) { var missing = names.Where(name => !headers.ContainsKey(name)).ToArray(); if (missing.Length > 0) throw new ArgumentException("Missing upload columns: " + string.Join(", ", missing)); }
        private static bool HasRequiredHeader(Dictionary<string, int> headers, string name) { return name == "vendor" ? HasAnyHeader(headers, "vendor", "vendorname", "supplier", "vendorsupplier", "suppliervendor") : name == "unitprice" ? HasAnyHeader(headers, "unitprice", "price") : name == "vendorname" ? HasAnyHeader(headers, "vendorname", "vendor", "supplier") : name == "invoicenumber" ? HasAnyHeader(headers, "invoicenumber", "invoice", "number") : name == "invoiceamount" ? HasAnyHeader(headers, "invoiceamount", "amount") : headers.ContainsKey(name); }
        private static bool HasAnyHeader(Dictionary<string, int> headers, params string[] names) { return names.Any(name => headers.ContainsKey(name) || headers.Keys.Any(key => key.Contains(name))); }
        private static void RequireAny(Dictionary<string, int> headers, string name, string[] aliases) { if (!HasAnyHeader(headers, aliases)) throw new ArgumentException("Missing upload columns: " + name); }
        private static bool ProcedureParameterError(SqlException ex) { return ex.Errors.Cast<SqlError>().Any(error => error.Number == 8144 || error.Number == 201 || error.Number == 207); }
        private static SqlParameter P(string name, object value) { return new SqlParameter(name, Db.Value(value)); }

    }
}
